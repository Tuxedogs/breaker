import {
  useState,
  useMemo,
  Fragment,
  useRef,
  useEffect,
  useCallback,
} from "react";
import type { ComponentRecipe } from "../utils/craftingTypes";
import { getComponentDisplayName } from "../utils/componentDisplayNames";
import {
  getModifiersAtQuality,
  summariseUnmatchedModifiers,
  formatProperty,
  formatModifierAtQuality,
} from "../utils/qualityModifiers";
import { getMaterialQualityKey } from "../utils/materialQuality";
import {
  getDirectionLabel,
  getModifierImpact,
} from "@/lib/gameplay/propertyUtils";
import {
  DEFAULT_BAND_INDEX,
  FALLBACK_QUALITY_BANDS,
  clampBandIndex,
  findNearestBandForQuality,
  getBandEffectiveQuality as getEffectiveQualityFromBands,
  type QualityBand,
} from "../utils/qualityBands";
import { MsbChip, MsbSection, MsbSidebar, ResourcesSection } from "../../shared/MsbSidebar";
import { buildResourceGroups } from "../../shared/msbResourceGroups";


const NO_VALUE = "__none__";
const QUALITY_QUANTIZATION_URL = "/api/crafting/quality_quantization.json";
const RECIPE_FILTER_STORAGE_KEY = "scintel:recipe:msb-sidebar:v1";

type RecipeSidebarState = {
  search: string;
  fps: string[];
  vehicles: string[];
  sizes: string[];
  grades: string[];
  classes: string[];
  resources: string[];
};

const EMPTY_RECIPE_SIDEBAR_STATE: RecipeSidebarState = {
  search: "",
  fps: [],
  vehicles: [],
  sizes: [],
  grades: [],
  classes: [],
  resources: [],
};

function readStoredSidebarState<T>(key: string, fallback: T): T {
  if (typeof window === "undefined" || !window.localStorage) return fallback;

  try {
    const raw = window.localStorage.getItem(key);
    return raw ? { ...fallback, ...JSON.parse(raw) } : fallback;
  } catch {
    return fallback;
  }
}

function writeStoredSidebarState<T>(key: string, state: T) {
  if (typeof window === "undefined" || !window.localStorage) return;
  window.localStorage.setItem(key, JSON.stringify(state));
}

const QUERY_ALIAS_MAP: Record<string, string> = {
  mil: "military",
  mili: "military",
  milit: "military",
  civ: "civilian",
  civi: "civilian",
  ind: "industrial",
  indu: "industrial",
  qt: "quantum",
  qd: "quantum",
};

function normalizeQueryToken(token: string): string {
  const t = token.toLowerCase();
  if (QUERY_ALIAS_MAP[t]) return QUERY_ALIAS_MAP[t];

  const rev = t.match(/^(\d+)s$/);
  if (rev) return `s${rev[1]}`;

  return t;
}

function buildRecipeSearchText(r: ComponentRecipe): string {
  const displayName =
    r.item_kind === "vehicle"
      ? r.component_name
      : getComponentDisplayName(r.component_name);

  const sizeStr = r.size ? `s${r.size} ${r.size}` : "no size";
  const kindExtra = r.item_kind === "fps" ? "fps" : "";

  const raw = [
    displayName,
    r.component_name,
    r.fallback_name,
    r.internal_name,
    r.manufacturer,
    r.class,
    r.grade,
    r.category,
    r.component_type,
    r.wiki_type,
    r.blueprint_id,
    sizeStr,
    kindExtra,
  ]
    .map((v) => String(v ?? "").toLowerCase())
    .join(" ");

  const compact = raw.replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, "");

  return `${raw} ${compact}`;
}

function matchesSearch(searchText: string, query: string): boolean {
  const trimmed = query.trim();
  if (!trimmed) return true;

  const tokens = trimmed.toLowerCase().split(/\s+/);
  return tokens.every((raw) => searchText.includes(normalizeQueryToken(raw)));
}

function getTypeBadges(recipe: ComponentRecipe): string[] {
  if (recipe.item_kind === "fps") {
    const cat = recipe.category ?? "";

    if (cat.toLowerCase().startsWith("fps ")) {
      return [cat.slice(4).toUpperCase(), "FPS"];
    }

    return cat ? [cat.toUpperCase(), "FPS"] : ["FPS"];
  }

  const ct = recipe.component_type ?? "";
  return ct ? [ct.toUpperCase()] : [];
}

function getSubtitle(recipe: ComponentRecipe): string {
  if (recipe.item_kind === "fps") {
    const parts = [recipe.category, recipe.wiki_type].filter(Boolean);
    return parts.join(" · ");
  }

  return recipe.component_type ?? "";
}

function formatSize(size: string | null | undefined): string | null {
  if (!size) return null;
  return `S${size}`;
}

function getImpactClass(impact: "good" | "bad" | "neutral"): string {
  if (impact === "good") return "craft-ok";
  if (impact === "bad") return "craft-shortage";
  return "";
}

function getImpactWord(impact: "good" | "bad" | "neutral"): string {
  if (impact === "good") return "better";
  if (impact === "bad") return "worse";
  return "";
}

type MaterialQuantization = {
  name?: string;
  recordName?: string;
  recordType?: string;
  displayName?: string;
  materialKey?: string;
  guid?: string;
  path?: string;
  bands: QualityBand[];
};

function normalizeMaterialLookup(value: string | null | undefined): string {
  return String(value ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function quantizationNameToMaterialKey(value: string | null | undefined): string | null {
  const raw = String(value ?? "").trim();
  if (!raw) return null;

  const withoutPrefix = raw.replace(/^Quantization[_\s-]*/i, "");
  const normalized = normalizeMaterialLookup(withoutPrefix);

  return normalized || null;
}

function getQuantizationLookupKeys(item: MaterialQuantization): string[] {
  const keys = new Set<string>();

  const add = (value: string | null | undefined) => {
    const normalized = normalizeMaterialLookup(value);
    if (normalized) keys.add(normalized);
  };

  add(item.materialKey);
  add(item.displayName);
  add(item.name);
  add(item.recordName);

  const fromName = quantizationNameToMaterialKey(item.name);
  const fromRecordName = quantizationNameToMaterialKey(item.recordName);

  if (fromName) keys.add(fromName);
  if (fromRecordName) keys.add(fromRecordName);

  const pathMatch = String(item.path ?? "").match(/quantization[_-]([^/.]+)\.xml$/i);
  if (pathMatch?.[1]) {
    keys.add(normalizeMaterialLookup(pathMatch[1]));
  }

  return Array.from(keys);
}

function getMaterialName(mat: ComponentRecipe["materials"][number]): string {
  return String(mat.material_name ?? "");
}

function useQualityQuantization() {
  const [data, setData] = useState<MaterialQuantization[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const res = await fetch(QUALITY_QUANTIZATION_URL);

        if (!res.ok) {
          throw new Error(
            `Failed to load ${QUALITY_QUANTIZATION_URL}: ${res.status}`,
          );
        }

        const json = (await res.json()) as MaterialQuantization[];

        if (!cancelled) {
          setData(Array.isArray(json) ? json : []);
        }
      } catch (err) {
        console.error(err);

        if (!cancelled) {
          setData([]);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    load();

    return () => {
      cancelled = true;
    };
  }, []);

  const byMaterial = useMemo(() => {
    const map = new Map<string, MaterialQuantization>();

    for (const item of data) {
      for (const key of getQuantizationLookupKeys(item)) {
        map.set(key, item);
      }
    }

    return map;
  }, [data]);

  const getMaterialQuantization = useCallback(
    (materialName: string): MaterialQuantization | undefined => {
      return byMaterial.get(normalizeMaterialLookup(materialName));
    },
    [byMaterial],
  );

  const getBandsForMaterial = useCallback(
    (materialName: string): QualityBand[] => {
      return (
        getMaterialQuantization(materialName)?.bands ?? FALLBACK_QUALITY_BANDS
      );
    },
    [getMaterialQuantization],
  );

  const getBandEffectiveQuality = useCallback(
    (materialName: string, bandIndex: number): number => {
      const bands = getBandsForMaterial(materialName);
      return getEffectiveQualityFromBands(bands, bandIndex);
    },
    [getBandsForMaterial],
  );

  const getBandLabel = useCallback(
    (materialName: string, bandIndex: number): string => {
      const bands = getBandsForMaterial(materialName);
      const safeIndex = clampBandIndex(bandIndex, bands);
      const band = bands[safeIndex];

      return band ? `${band.start}–${band.end}` : "Base 500";
    },
    [getBandsForMaterial],
  );

  return {
    loading,
    getMaterialQuantization,
    getBandsForMaterial,
    getBandEffectiveQuality,
    getBandLabel,
  };
}

export function UnmatchedModifierGroups({
  modifiers,
}: {
  modifiers: ReturnType<typeof summariseUnmatchedModifiers>;
}) {
  const bySlot = new Map<string, typeof modifiers>();

  for (const s of modifiers) {
    const arr = bySlot.get(s.slot) ?? [];
    arr.push(s);
    bySlot.set(s.slot, arr);
  }

  return (
    <>
      {Array.from(bySlot.entries()).map(([slot, props]) => (
        <div key={slot} className="craft-mod-group craft-mod-group--general">
          <div className="craft-mod-group-header">
            <span className="craft-drawer-mat-slot">{slot}</span>
            <span className="craft-mod-group-sep">/</span>
            <span className="craft-mod-group-mat craft-muted">general</span>
          </div>

          <div className="craft-drawer-modifier-list">
            {props.map(({ property, minPercent, maxPercent }, i) => (
              <div key={i} className="craft-drawer-modifier-row">
                <span className="craft-badge craft-badge--sm craft-badge--slot craft-drawer-modifier-slot">
                  {slot}
                </span>

                <span className="craft-drawer-modifier-prop">
                  {formatProperty(property)}
                </span>

                <span className="craft-drawer-modifier-val craft-mod-range">
                  {minPercent.toFixed(1)}% → {maxPercent >= 0 ? "+" : ""}
                  {maxPercent.toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </>
  );
}

function OverallModifierGroup({
  modifiers,
  quality,
}: {
  modifiers: NonNullable<ComponentRecipe["overallQualityModifiers"]>;
  quality?: number;
}) {
  if (modifiers.length === 0) return null;

  return (
    <div className="craft-mod-group craft-mod-group--general">
      <div className="craft-mod-group-header">
        <span className="craft-drawer-mat-slot">ASPECTS</span>
        <span className="craft-mod-group-sep">/</span>
        <span className="craft-mod-group-mat craft-muted">
          Component HP Modifier
        </span>
        {quality !== undefined && (
          <span className="craft-mod-group-q">{quality}</span>
        )}
      </div>

      {quality === undefined ? (
        <div className="craft-drawer-modifier-list">
          {summariseUnmatchedModifiers(modifiers).map(
            ({ property, minPercent, maxPercent }, i) => (
              <div key={i} className="craft-drawer-modifier-row">
                <span className="craft-badge craft-badge--sm craft-badge--slot craft-drawer-modifier-slot">
                  ASPECTS
                </span>

                <span className="craft-drawer-modifier-prop">
                  {formatProperty(property)}
                </span>

                <span className="craft-drawer-modifier-val craft-mod-range">
                  {minPercent.toFixed(1)}% → {maxPercent >= 0 ? "+" : ""}
                  {maxPercent.toFixed(1)}%
                </span>
              </div>
            ),
          )}
        </div>
      ) : (
        <div className="craft-drawer-modifier-list">
          {getModifiersAtQuality(modifiers, quality).map((m, i) => {
            const impact = getModifierImpact(m.property, m.value);
            const impactWord = getImpactWord(impact);

            return (
              <div key={i} className="craft-drawer-modifier-row">
                <span className="craft-badge craft-badge--sm craft-badge--slot craft-drawer-modifier-slot">
                  {m.slot}
                </span>

                <span className="craft-drawer-modifier-prop">
                  {formatProperty(m.property)}
                </span>

                <span
                  className={`craft-drawer-modifier-val ${getImpactClass(impact)}`}
                >
                  {formatModifierAtQuality(m)}
                  {impactWord ? ` ${impactWord}` : ""}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function MaterialQualityRow({
  mat,
  bandIndex,
  onBandChange,
  getBandsForMaterial,
  getBandEffectiveQuality,
}: {
  mat: ComponentRecipe["materials"][number];
  bandIndex: number;
  onBandChange: (bandIndex: number) => void;
  getBandsForMaterial: (materialName: string) => QualityBand[];
  getBandEffectiveQuality: (materialName: string, bandIndex: number) => number;
  getBandLabel: (materialName: string, bandIndex: number) => string;
}) {
  const modifiers = mat.qualityModifiers ?? [];
  const materialName = getMaterialName(mat);
  const bands = getBandsForMaterial(materialName);
  const safeBandIndex = clampBandIndex(bandIndex, bands);
  const quality = getBandEffectiveQuality(materialName, safeBandIndex);

  const atQuality = useMemo(() => {
    const mods = getModifiersAtQuality(modifiers, quality);
    // Weapon Recoil Kick must appear directly above Weapon Recoil Smoothness
    return [...mods].sort((a, b) => {
      const order = (p: string) =>
        p === 'WeaponRecoilKick' ? 0 : p === 'WeaponRecoilSmoothness' ? 1 : 2;
      return order(a.property) - order(b.property);
    });
  }, [modifiers, quality]);

  const railMarkers = useMemo(
    () =>
      bands.map((band, i) => {
        const mappedValue = Number(band.mappedValue ?? 0);
        const left = Math.max(0, Math.min(100, (mappedValue / 1000) * 100));
        const edge = left < 4 ? "start" : left > 96 ? "end" : "middle";

        return {
          index: i,
          mappedValue,
          left,
          edge,
        };
      }),
    [bands],
  );

  const findNearestBandForMappedValue = useCallback(
    (value: number) => {
      return findNearestBandForQuality(bands, value);
    },
    [bands],
  );

  const bandOnePct = Math.max(0, Math.min(100, railMarkers[0]?.left ?? 0));
  const selectedPct = Math.max(0, Math.min(100, (quality / 1000) * 100));
  const fillPct = Math.max(0, selectedPct - bandOnePct);



  

  return (
    <div className="craft-matq-card" data-band={safeBandIndex}>
      <div className="craft-matq-header">
        <div className="craft-matq-identity">
          <span className="craft-matq-slot">{mat.slot}</span>
          <span className="craft-matq-name">{mat.material_name}</span>
          <span className="craft-matq-qty">
            Required <strong>x{mat.quantity.toFixed(2)}</strong>
          </span>
        </div>

        <div className="craft-matq-quality-header">
          <span className="craft-matq-quality-label">
            Band {safeBandIndex + 1}
          </span>
          <span className="craft-matq-quality-value">{quality}</span>
        </div>
      </div>
      

      <div className="craft-matq-slider-wrap">
        <div className="craft-matq-rail-wrap">
          <input
            type="range"
            min={0}
            max={1000}
            step={1}
            value={quality}
            onChange={(e) => {
              const rawValue = Number(e.target.value);
              onBandChange(findNearestBandForMappedValue(rawValue));
            }}
            className="craft-matq-slider"
            aria-label={`Quality band for ${mat.material_name}`}
          />

<div
  className="craft-matq-rail"
  style={
    {
      "--band-one-pct": `${bandOnePct}%`,
    } as React.CSSProperties
  }
>
  <div
    className="craft-matq-rail-fill"
    style={
      {
        "--band-one-pct": `${bandOnePct}%`,
        "--fill-pct": `${fillPct}%`,
      } as React.CSSProperties
    }
  />

            {railMarkers.map((marker) => (
              <button
                type="button"
                key={`${marker.index}-${marker.mappedValue}`}
                className={`craft-matq-band-marker${marker.index === safeBandIndex ? " is-active" : ""}`}
                style={{ left: `${marker.left}%` }}
                data-edge={marker.edge}
                onClick={() => onBandChange(marker.index)}
                aria-label={`Use mapped quality ${marker.mappedValue}`}
              >
                <span className="craft-matq-dot" />
                <span className="craft-matq-marker-value">{marker.mappedValue}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {atQuality.length > 0 && (
        <div className="craft-matq-mods">
          {atQuality.map((m, i) => {
            const impact = getModifierImpact(m.property, m.value);
            const impactWord = getImpactWord(impact);
            const directionLabel = getDirectionLabel(m.property);

            return (
              <div key={i} className="craft-matq-mod-card">
                <div className="craft-matq-mod-top">
                  <span className="craft-matq-mod-prop">
                    {formatProperty(m.property)}
                  </span>

                  <span
                    className={`craft-matq-mod-val ${getImpactClass(impact)}`}
                  >
                    {formatModifierAtQuality(m)}
                    {impactWord ? ` ${impactWord}` : ""}
                  </span>
                </div>

                {directionLabel && (
                  <div className="craft-matq-mod-hint">{directionLabel}</div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

interface TotalModifierRow {
  property: string;
  totalValue: number;
  modifierMode?: string;
  contributions: { materialName: string; value: number }[];
}

function computeTotalModifiers(
  recipe: ComponentRecipe,
  getBandEffectiveQuality: (name: string, idx: number) => number,
  getBandIndex: (key: string) => number,
): TotalModifierRow[] {
  const map = new Map<string, TotalModifierRow>();

  for (const [inputIndex, mat] of recipe.materials.entries()) {
    const modifiers = mat.qualityModifiers ?? [];
    if (modifiers.length === 0) continue;

    const key = getMaterialQualityKey(recipe, mat, inputIndex);
    const quality = getBandEffectiveQuality(getMaterialName(mat), getBandIndex(key));
    const atQuality = getModifiersAtQuality(modifiers, quality);

    for (const m of atQuality) {
      // Group by property + modifierMode so same stat from different slots combine
      const rowKey = `${m.property}||${m.modifierMode ?? ""}`;
      const existing = map.get(rowKey);

      if (!existing) {
        map.set(rowKey, {
          property: m.property,
          totalValue: m.value,
          modifierMode: m.modifierMode,
          contributions: [{ materialName: getMaterialName(mat), value: m.value }],
        });
      } else {
        existing.totalValue += m.value;
        existing.contributions.push({ materialName: getMaterialName(mat), value: m.value });
      }
    }
  }

  return Array.from(map.values());
}

function formatTotalModifierValue(row: TotalModifierRow): string {
  if (row.modifierMode === "integerAdditive") {
    const v = Math.round(row.totalValue);
    const suffix =
      row.property === "GPP_ItemResource_PowerGeneration"
        ? ` ${Math.abs(v) === 1 ? "power pip" : "power pips"}`
        : "";
    return `${v >= 0 ? "+" : ""}${v}${suffix}`;
  }
  return `${row.totalValue >= 0 ? "+" : ""}${row.totalValue.toFixed(1)}%`;
}

function formatContributionValue(value: number, modifierMode?: string): string {
  if (modifierMode === "integerAdditive") {
    const v = Math.round(value);
    return `${v >= 0 ? "+" : ""}${v}`;
  }
  return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;
}

function CraftedItemSummaryPanel({
  recipe,
  displayName,
  totalModifiers,
  overallModifiers,
  overallQualitySource,
  rewardPools,
  onAddToQueue,
  getBandEffectiveQuality,
  getBandsForMaterial,
  materialQualities,
}: {
  recipe: ComponentRecipe;
  displayName: string;
  totalModifiers: TotalModifierRow[];
  overallModifiers: NonNullable<ComponentRecipe["overallQualityModifiers"]>;
  overallQualitySource: number | undefined;
  rewardPools: { displayName: string }[];
  onAddToQueue: (r: ComponentRecipe, selectedQualities: Record<string, { quality: number; bands: QualityBand[] }>) => void;
  getBandEffectiveQuality: (materialName: string, bandIndex: number) => number;
  getBandsForMaterial: (materialName: string) => QualityBand[];
  materialQualities: Record<string, number>;
}) {
  const typeBadges = getTypeBadges(recipe);
  const sizeLabel = formatSize(recipe.size);
  const hasMaterialModifiers = totalModifiers.length > 0;
  const hasOverallModifiers = overallModifiers.length > 0;
  const hasAnyModifiers = hasMaterialModifiers || hasOverallModifiers;

  return (
    <div className="craft-summary-panel">
      {/* Title + metadata chips */}
      <div className="craft-summary-head">
        <div className="craft-summary-title">{displayName}</div>
        <div className="craft-summary-chips">
          {typeBadges.map((b) => (
            <span
              key={b}
              className={`craft-badge craft-badge--type-chip${b === "FPS" ? " craft-badge--fps" : ""}`}
            >
              {b}
            </span>
          ))}
          {sizeLabel && (
            <span className="craft-badge craft-badge--size-chip">{sizeLabel}</span>
          )}
          {recipe.grade && (
            <span className={`craft-badge craft-badge--grade${recipe.grade === "A" ? " craft-badge--grade-a" : ""}`}>
              {recipe.grade}
            </span>
          )}
          {recipe.class && (
            <span className="craft-badge craft-badge--neutral">{recipe.class}</span>
          )}
        </div>
      </div>

      {/* Modifiers total */}
      {hasAnyModifiers && (
        <div className="craft-summary-section">
          <div className="craft-summary-section-label">Modifiers Total</div>

          {hasMaterialModifiers && (
            <div className="craft-summary-mod-list">
              {totalModifiers.map((row) => {
                const impact = getModifierImpact(row.property, row.totalValue);
                const impactWord = getImpactWord(impact);
                const impactClass = getImpactClass(impact);
                const hasBreakdown = row.contributions.length > 1;

                return (
                  <div key={row.property} className="craft-summary-mod-row">
                    <div className="craft-summary-mod-top">
                      <span className="craft-summary-mod-prop">
                        {formatProperty(row.property)}
                      </span>
                      <span className={`craft-summary-mod-val ${impactClass}`}>
                        {formatTotalModifierValue(row)}
                        {impactWord ? ` ${impactWord}` : ""}
                      </span>
                    </div>
                    {hasBreakdown && (
                      <div className="craft-summary-mod-breakdown">
                        {"("}
                        {row.contributions.map((c, i) => (
                          <span key={i} className="craft-summary-mod-contrib">
                            {i > 0 && " + "}
                            {formatContributionValue(c.value, row.modifierMode)} from {c.materialName}
                          </span>
                        ))}
                        {")"}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {hasOverallModifiers && (
            <div className="craft-summary-overall-mods">
              <OverallModifierGroup
                modifiers={overallModifiers}
                quality={overallQualitySource}
              />
            </div>
          )}
        </div>
      )}

      {/* Where to Find */}
      <div className="craft-summary-section craft-summary-section--grow">
        {rewardPools.length === 0 ? (
          <div className="craft-summary-empty">
            Blueprint source not found in parsed reward data
          </div>
        ) : (
          <div className="craft-drawer-sources">
            {rewardPools.map((pool, i) => (
              <div
                key={`${pool.displayName}-${i}`}
                className="craft-drawer-source-item"
              >
                <div className="craft-drawer-source-tag">Blueprint Source</div>
                <div className="craft-drawer-source-name">{pool.displayName}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add to Build Queue */}
      <button
        type="button"
        className="craft-summary-queue-btn"
        onClick={() => {
          const selectedQualities = Object.fromEntries(
            recipe.materials.map((mat, inputIndex) => {
              const key = getMaterialQualityKey(recipe, mat, inputIndex);
              const materialName = getMaterialName(mat);
              return [key, {
                quality: getBandEffectiveQuality(materialName, materialQualities[key] ?? DEFAULT_BAND_INDEX),
                bands: getBandsForMaterial(materialName),
              }];
            }),
          );
          onAddToQueue(recipe, selectedQualities);
        }}
      >
        <svg
          viewBox="0 0 24 24"
          width="16"
          height="16"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden
        >
          <circle cx="9" cy="21" r="1" />
          <circle cx="20" cy="21" r="1" />
          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
        </svg>
        Add to Build Queue
      </button>
    </div>
  );
}

function RecipeDrawer({
  recipe,
  onAddToQueue,
}: {
  recipe: ComponentRecipe;
  onAddToQueue: (r: ComponentRecipe, selectedQualities: Record<string, { quality: number; bands: QualityBand[] }>) => void;
}) {
  const {
    loading: quantizationLoading,
    getBandsForMaterial,
    getBandEffectiveQuality,
    getBandLabel,
  } = useQualityQuantization();

  const [materialQualities, setMaterialQualities] = useState<
    Record<string, number>
  >(() =>
    Object.fromEntries(
      recipe.materials.map((mat, inputIndex) => [
        getMaterialQualityKey(recipe, mat, inputIndex),
        DEFAULT_BAND_INDEX,
      ]),
    ),
  );

  function getBandIndex(key: string): number {
    return materialQualities[key] ?? DEFAULT_BAND_INDEX;
  }

  const overallModifiers = recipe.overallQualityModifiers ?? [];
  const overallQualityMaterial = recipe.materials[2];

  const overallQualitySource = overallQualityMaterial
    ? getBandEffectiveQuality(
        getMaterialName(overallQualityMaterial),
        getBandIndex(getMaterialQualityKey(recipe, overallQualityMaterial, 2)),
      )
    : undefined;

  const rewardPools = (recipe.rewardPools ?? []) as { displayName: string }[];

  const displayName =
    recipe.item_kind === "vehicle"
      ? recipe.component_name
      : getComponentDisplayName(recipe.component_name);

  const totalModifiers = useMemo(
    () => computeTotalModifiers(recipe, getBandEffectiveQuality, getBandIndex),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [recipe, getBandEffectiveQuality, materialQualities],
  );

  return (
    <div className="craft-expanded-content">
      <div className="craft-expanded-main">
        <div className="craft-detail-section">
          {quantizationLoading && (
            <div className="craft-empty-card">
              Loading local quality quantization bands...
            </div>
          )}

          <div className="craft-material-list">
            {recipe.materials.map((mat, inputIndex) => {
              const key = getMaterialQualityKey(recipe, mat, inputIndex);

              return (
                <MaterialQualityRow
                  key={`${mat.slot}:${key}`}
                  mat={mat}
                  bandIndex={getBandIndex(key)}
                  onBandChange={(bandIndex) =>
                    setMaterialQualities((prev) => ({
                      ...prev,
                      [key]: bandIndex,
                    }))
                  }
                  getBandsForMaterial={getBandsForMaterial}
                  getBandEffectiveQuality={getBandEffectiveQuality}
                  getBandLabel={getBandLabel}
                />
              );
            })}
          </div>
        </div>
      </div>

      <div className="craft-expanded-sidebar">
        <CraftedItemSummaryPanel
          recipe={recipe}
          displayName={displayName}
          totalModifiers={totalModifiers}
          overallModifiers={overallModifiers}
          overallQualitySource={overallQualitySource}
          rewardPools={rewardPools}
          onAddToQueue={onAddToQueue}
          getBandEffectiveQuality={getBandEffectiveQuality}
          getBandsForMaterial={getBandsForMaterial}
          materialQualities={materialQualities}
        />
      </div>
    </div>
  );
};

interface Props {
  recipes: ComponentRecipe[];
  onAddToQueue: (recipe: ComponentRecipe, selectedQualities: Record<string, { quality: number; bands: QualityBand[] }>) => void;
}

export default function ComponentRecipeTable({ recipes, onAddToQueue }: Props) {
  const initialSidebarState = useMemo(
    () => readStoredSidebarState(RECIPE_FILTER_STORAGE_KEY, EMPTY_RECIPE_SIDEBAR_STATE),
    [],
  );
  const [search, setSearch] = useState(initialSidebarState.search);
  const [fpsFilters, setFpsFilters] = useState<Set<string>>(() => new Set(initialSidebarState.fps));
  const [vehicleFilters, setVehicleFilters] = useState<Set<string>>(() => new Set(initialSidebarState.vehicles));
  const [sizeFilters, setSizeFilters] = useState<Set<string>>(() => new Set(initialSidebarState.sizes));
  const [gradeFilters, setGradeFilters] = useState<Set<string>>(() => new Set(initialSidebarState.grades));
  const [classFilters, setClassFilters] = useState<Set<string>>(() => new Set(initialSidebarState.classes));
  const [resourceFilters, setResourceFilters] = useState<Set<string>>(() => new Set(initialSidebarState.resources));
  const [expanded, setExpanded] = useState<string | null>(null);
  const [pageSize, setPageSize] = useState<number>(14);
  const [page, setPage] = useState(0);
  const expandedRowRef = useRef<HTMLTableRowElement>(null);

  useEffect(() => {
    if (!expanded) return;
    const el = expandedRowRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, [expanded]);

  const resetPage = useCallback(() => setPage(0), []);

  function resetAll() {
    setSearch("");
    setFpsFilters(new Set());
    setVehicleFilters(new Set());
    setSizeFilters(new Set());
    setGradeFilters(new Set());
    setClassFilters(new Set());
    setResourceFilters(new Set());
    resetPage();
  }

  const hasActiveFilters =
    search ||
    fpsFilters.size ||
    vehicleFilters.size ||
    sizeFilters.size ||
    gradeFilters.size ||
    classFilters.size ||
    resourceFilters.size;

  useEffect(() => {
    writeStoredSidebarState<RecipeSidebarState>(RECIPE_FILTER_STORAGE_KEY, {
      search,
      fps: [...fpsFilters],
      vehicles: [...vehicleFilters],
      sizes: [...sizeFilters],
      grades: [...gradeFilters],
      classes: [...classFilters],
      resources: [...resourceFilters],
    });
  }, [classFilters, fpsFilters, gradeFilters, resourceFilters, search, sizeFilters, vehicleFilters]);

  const fpsOptions = useMemo(
    () =>
      Array.from(new Set(recipes.filter((r) => r.item_kind === "fps").map((r) => r.component_type).filter(Boolean)))
        .sort()
        .map((t) => ({ value: t!, label: t! })),
    [recipes],
  );

  const vehicleOptions = useMemo(
    () =>
      Array.from(new Set(recipes.filter((r) => r.item_kind !== "fps").map((r) => r.component_type).filter(Boolean)))
        .filter((t) => t !== "salvage" && t !== "tractorbeam")
        .sort()
        .map((t) => ({ value: t!, label: t! })),
    [recipes],
  );

  const sizeOptions = useMemo(() => {
    const vals = Array.from(new Set(recipes.map((r) => r.size).filter(Boolean)))
      .sort((a, b) => Number(a) - Number(b))
      .map((s) => ({ value: s!, label: `S${s}` }));

    return vals;
  }, [recipes]);

  const classOptions = useMemo(
    () =>
      Array.from(new Set(recipes.map((r) => r.class).filter(Boolean)))
        .sort()
        .map((c) => ({ value: c!, label: c! })),
    [recipes],
  );

  const resourceGroups = useMemo(() => {
    const resources = recipes.flatMap((recipe) =>
      (recipe.materials ?? []).map((material) => ({
        id: material.cost_id || material.material_name,
        label: material.material_name,
        miningType: material.cost_type,
      })),
    ).filter((r) => r.label !== "Insulative Liner Material");
    return buildResourceGroups(resources);
  }, [recipes]);

  const recipeSearchTexts = useMemo(
    () =>
      new Map(recipes.map((r) => [r.blueprint_id, buildRecipeSearchText(r)])),
    [recipes],
  );

  const filtered = useMemo(() => {
    return recipes
      .filter((r) => {
        if (
          search &&
          !matchesSearch(recipeSearchTexts.get(r.blueprint_id) ?? "", search)
        ) {
          return false;
        }

        if (fpsFilters.size && (r.item_kind !== "fps" || !fpsFilters.has(r.component_type ?? ""))) return false;
        if (vehicleFilters.size && (r.item_kind === "fps" || !vehicleFilters.has(r.component_type ?? ""))) return false;

        if (sizeFilters.size) {
          const sv = r.size ? r.size : NO_VALUE;
          if (!sizeFilters.has(sv)) return false;
        }

        if (gradeFilters.size) {
          const gv = r.grade ? r.grade : NO_VALUE;
          if (!gradeFilters.has(gv)) return false;
        }

        if (classFilters.size && !classFilters.has(r.class ?? "")) return false;

        if (resourceFilters.size) {
          const recipeName = r.component_name.trim().toLowerCase();
          const usesSelectedInput = (r.materials ?? []).some((material) =>
            resourceFilters.has(material.cost_id || material.material_name) ||
            resourceFilters.has(material.material_name)
          );
          const isSelectedResourceItself = (r.materials ?? []).some((material) =>
            resourceFilters.has(material.cost_id || material.material_name) &&
            material.material_name.trim().toLowerCase() === recipeName
          );
          if (!usesSelectedInput || isSelectedResourceItself) return false;
        }

        return true;
      })
      .sort((a, b) => {
        const aName =
          a.item_kind === "vehicle"
            ? a.component_name
            : getComponentDisplayName(a.component_name);

        const bName =
          b.item_kind === "vehicle"
            ? b.component_name
            : getComponentDisplayName(b.component_name);

        const nd = aName.localeCompare(bName);

        return nd !== 0 ? nd : (a.size || "").localeCompare(b.size || "");
      });
  }, [
    recipes,
    search,
    fpsFilters,
    vehicleFilters,
    sizeFilters,
    gradeFilters,
    classFilters,
    resourceFilters,
    recipeSearchTexts,
  ]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages - 1);
  const startIdx = currentPage * pageSize;
  const endIdx = Math.min(startIdx + pageSize, filtered.length);
  const paginated = filtered.slice(startIdx, endIdx);
  const startItem = filtered.length === 0 ? 0 : startIdx + 1;

  return (
    <div className="craft-recipe-browser-layout">
      <MsbSidebar title="Recipe Filters" onClear={resetAll}>
        <MsbSection label="Search" onClear={hasActiveFilters ? resetAll : undefined} raw>
          <input
            type="search"
            className="msb-search-input"
            placeholder="Search recipes..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              resetPage();
            }}
          />
        </MsbSection>

        <MsbSection label="FPS">
          {fpsOptions.map((filter) => (
            <MsbChip
              key={filter.value}
              label={filter.label}
              active={fpsFilters.has(filter.value)}
              onClick={() => {
                setFpsFilters((prev) => {
                  const next = new Set(prev);
                  if (next.has(filter.value)) next.delete(filter.value);
                  else next.add(filter.value);
                  return next;
                });
                resetPage();
              }}
            />
          ))}
        </MsbSection>

        <MsbSection label="Vehicles">
          {vehicleOptions.map((filter) => (
            <MsbChip
              key={filter.value}
              label={filter.label}
              active={vehicleFilters.has(filter.value)}
              onClick={() => {
                setVehicleFilters((prev) => {
                  const next = new Set(prev);
                  if (next.has(filter.value)) next.delete(filter.value);
                  else next.add(filter.value);
                  return next;
                });
                resetPage();
              }}
            />
          ))}
        </MsbSection>

        <MsbSection label="Size">
          {sizeOptions.map((filter) => (
            <MsbChip key={filter.value} label={filter.label} active={sizeFilters.has(filter.value)} onClick={() => {
              setSizeFilters((prev) => {
                const next = new Set(prev);
                if (next.has(filter.value)) next.delete(filter.value);
                else next.add(filter.value);
                return next;
              });
              resetPage();
            }} />
          ))}
        </MsbSection>

        <MsbSection label="Class">
          {classOptions.map((filter) => (
            <MsbChip key={filter.value} label={filter.label} active={classFilters.has(filter.value)} onClick={() => {
              setClassFilters((prev) => {
                const next = new Set(prev);
                if (next.has(filter.value)) next.delete(filter.value);
                else next.add(filter.value);
                return next;
              });
              resetPage();
            }} />
          ))}
        </MsbSection>

        <ResourcesSection
          groups={resourceGroups}
          selectedIds={resourceFilters}
          onToggle={(id) => {
            setResourceFilters((prev) => {
              const next = new Set(prev);
              if (next.has(id)) next.delete(id);
              else next.add(id);
              return next;
            });
            resetPage();
          }}
        />
      </MsbSidebar>

      <div className="craft-section craft-recipe-results">


      {hasActiveFilters && <div className="craft-recipe-filter-note"></div>}

      <div className="craft-table-wrap">
        <table className="craft-table">
          <thead>
            <tr>
              <th className="craft-th-name">Name</th>
              <th>Type</th>
              <th>Size</th>
              <th>Grade</th>
              <th>Class</th>
              <th className="craft-th-action"></th>
            </tr>
          </thead>

          <tbody>
            {paginated.map((recipe) => {
              const isOpen = expanded === recipe.blueprint_id;

              const displayName =
                recipe.item_kind === "vehicle"
                  ? recipe.component_name
                  : getComponentDisplayName(recipe.component_name);

              const subtitle = getSubtitle(recipe);
              const typeBadges = getTypeBadges(recipe);
              const sizeLabel = formatSize(recipe.size);
              const grade = recipe.grade ?? null;
              const cls = recipe.class ?? null;

              return (
                <Fragment key={recipe.blueprint_id}>
                  <tr
                    ref={isOpen ? expandedRowRef : undefined}
                    className={`craft-table-row${isOpen ? " craft-table-row--open" : ""}`}
                    onClick={() => setExpanded(isOpen ? null : recipe.blueprint_id)}
                    style={{ cursor: "pointer" }}
                  >
                    <td className="craft-cell-name">
                      <div className="craft-name-wrap">
                        <div className="craft-thumb" aria-hidden>
                          <svg
                            viewBox="0 0 28 28"
                            width="20"
                            height="20"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="1.2"
                            opacity="0.3"
                          >
                            <rect x="4" y="4" width="20" height="20" rx="2" />
                            <path d="M9 14h10M14 9v10" strokeLinecap="round" />
                          </svg>
                        </div>

                        <div className="craft-name-info">
                          <span
                            className="craft-name-primary"
                            title={recipe.component_name}
                          >
                            {displayName}
                          </span>

                          {subtitle && (
                            <span className="craft-name-sub">{subtitle}</span>
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="craft-cell-type">
                      <div className="craft-badge-row">
                        {typeBadges.map((b) => (
                          <span
                            key={b}
                            className={`craft-badge craft-badge--type-chip${
                              b === "FPS" ? " craft-badge--fps" : ""
                            }`}
                          >
                            {b}
                          </span>
                        ))}
                      </div>
                    </td>

                    <td className="craft-cell-size">
                      {sizeLabel ? (
                        <span className="craft-badge craft-badge--size-chip">
                          {sizeLabel}
                        </span>
                      ) : (
                        <span className="craft-dash">—</span>
                      )}
                    </td>

                    <td className="craft-cell-grade">
                      {grade ? (
                        <span
                          className={`craft-badge craft-badge--grade${
                            grade === "A" ? " craft-badge--grade-a" : ""
                          }`}
                        >
                          {grade}
                        </span>
                      ) : (
                        <span className="craft-dash">—</span>
                      )}
                    </td>

                    <td className="craft-cell-class">
                      {cls ? (
                        <span className="craft-cell-subdued">{cls}</span>
                      ) : (
                        <span className="craft-dash">—</span>
                      )}
                    </td>

                    <td className="craft-cell-action">
                      <span
                        className={`craft-btn-chevron${isOpen ? " craft-btn-chevron--open" : ""}`}
                        aria-hidden
                      >
                        <svg
                          viewBox="0 0 10 6"
                          width="10"
                          height="6"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M1 1l4 4 4-4" />
                        </svg>
                      </span>
                    </td>
                  </tr>

                  {isOpen && (
                    <tr className="craft-detail-row">
                      <td colSpan={6}>
                        <RecipeDrawer
                          recipe={recipe}
                          onAddToQueue={onAddToQueue}
                        />
                      </td>
                    </tr>
                  )}
                </Fragment>
              );
            })}

            {paginated.length === 0 && (
              <tr>
                <td colSpan={6} className="craft-empty">
                  No recipes match filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="craft-pagination">
        <div className="craft-pagination-info">
          {filtered.length > 0
            ? `Showing ${startItem}–${endIdx} of ${filtered.length}`
            : "No results"}
        </div>

        <div className="craft-pagination-controls">
          <button
            type="button"
            className="craft-page-btn"
            disabled={currentPage === 0}
            onClick={() => setPage(currentPage - 1)}
          >
            Prev
          </button>

          <span className="craft-page-indicator">
            {currentPage + 1} / {totalPages}
          </span>

          <button
            type="button"
            className="craft-page-btn"
            disabled={currentPage >= totalPages - 1}
            onClick={() => setPage(currentPage + 1)}
          >
            Next
          </button>
        </div>

        
      </div>
    </div>
    </div>
  );
}
