import { Link } from "react-router-dom";
import { useState } from "react";
import DonutChart from "../components/dashboard/DonutChart";
import MaterialIcon from "../components/logistics/MaterialIcon";
import {
  mockStats,
  mockInventory,
  mockMaterialShortages,
  mockBuildQueue,
  mockLocations,
  miningRecommendations,
} from "../data/mock/dashboard";
import { useLogisticsStore } from "../stores/logisticsStore";
import { deriveUserDashStats } from "../lib/dashboardStats";
import type { LogisticsMaterialTemplate } from "../data/logistics/seed";

// ── Shared arrow icon for footer links ─────────────────────────────
function ArrowRight({ size = 12 }: { size?: number }) {
  return (
    <svg aria-hidden viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" width={size} height={size} className="dash-card-footer-arrow">
      <path d="M5 12h14M12 5l7 7-7 7" />
    </svg>
  );
}

// ── Stat card icon shapes ──────────────────────────────────────────
type StatIconType = "materials" | "owned" | "needed" | "shortage" | "queue" | "volume" | "high" | "low";
function StatIcon({ type }: { type: StatIconType }) {
  const configs: Record<StatIconType, { bg: string; color: string; d: string }> = {
    materials: { bg: "rgba(167,139,250,0.12)", color: "#a78bfa", d: "M12 2L2 7v10l10 5 10-5V7L12 2zm0 5l5 2.5v5L12 17l-5-2.5v-5L12 7z" },
    owned: { bg: "rgba(56,189,248,0.12)", color: "#38bdf8", d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z" },
    needed: { bg: "rgba(167,139,250,0.12)", color: "#a78bfa", d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01m-.01 4h.01" },
    shortage: { bg: "rgba(248,113,113,0.12)", color: "#f87171", d: "M12 2L2 19h20L12 2zm0 6v5m0 4h.01" },
    queue: { bg: "rgba(251,146,60,0.12)", color: "#fb923c", d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" },
    volume: { bg: "rgba(56,189,248,0.12)", color: "#38bdf8", d: "M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" },
    high: { bg: "rgba(74,222,128,0.12)", color: "#4ade80", d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" },
    low: { bg: "rgba(248,113,113,0.12)", color: "#f87171", d: "M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" },
  };
  const c = configs[type];
  return (
    <div className="dash-stat-icon-wrap" style={{ background: c.bg }}>
      <svg aria-hidden viewBox="0 0 24 24" fill="none" stroke={c.color} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" width="18" height="18">
        <path d={c.d} />
      </svg>
    </div>
  );
}

// ── Stat tooltip ──────────────────────────────────────────────────
function StatTooltip({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <span className="dash-stat-tooltip-wrap">
      <button
        type="button"
        className="dash-stat-info-btn"
        aria-label="More info"
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
      >
        <svg viewBox="0 0 14 14" width="11" height="11" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
          <circle cx="7" cy="7" r="6" />
          <path d="M7 6v4M7 4.5v.5" />
        </svg>
      </button>
      {open && <div className="dash-stat-tooltip" role="tooltip">{children}</div>}
    </span>
  );
}


// ── Build queue thumbnail ──────────────────────────────────────────
function BqThumb({ color }: { color: string }) {
  return (
    <div className="dash-bq-thumb">
      <svg viewBox="0 0 20 20" width="14" height="14" fill="none">
        <rect x="3" y="7" width="14" height="10" rx="1.5" stroke={color} strokeWidth="1.4" />
        <path d="M7 7V5a3 3 0 016 0v2" stroke={color} strokeWidth="1.4" strokeLinecap="round" />
      </svg>
    </div>
  );
}

// ── Location icon ──────────────────────────────────────────────────
function LocationIcon({ type }: { type: string }) {
  const d = type === "station"
    ? "M12 2L2 7v10l10 5 10-5V7L12 2z"
    : "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 110-5 2.5 2.5 0 010 5z";
  return (
    <div className="dash-location-icon">
      <svg aria-hidden viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="12" height="12">
        <path d={d} />
      </svg>
    </div>
  );
}

export default function DashboardPage() {
  const ownedPct = Math.round((mockInventory.owned / mockInventory.needed) * 100);
  const { inventoryEntries, materialTemplates } = useLogisticsStore();
  const userStats = deriveUserDashStats(inventoryEntries, materialTemplates as LogisticsMaterialTemplate[]);

  return (
    <div className="dash-content-grid">
      {/* ── Main column ── */}
      <div className="dash-main-col">

        {/* Hero */}
        <section className="dash-hero" aria-label="Welcome">
          <div className="dash-hero-content">
            <p className="dash-hero-kicker">Welcome to Scintel</p>
            <h1 className="dash-hero-title">
              Parse screenshots<br />keep track of your loot.
            </h1>
            <p className="dash-hero-subtitle">
              Track inventory, queue builds, and prioritize<br />
              the materials that matter next.
            </p>
            <Link to="/dashboard/doctrine/armor-threshold" className="dash-hero-cta">
              Explore Tools
              <svg aria-hidden viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="dash-hero-cta-arrow">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </Link>
          </div>

          {/* Slide dots */}
          <div className="dash-hero-controls" aria-hidden>
            <div className="dash-hero-dot active" />
            <div className="dash-hero-dot" />
            <div className="dash-hero-dot" />
          </div>

          {/* Slide nav */}
          <div className="dash-hero-nav" aria-hidden>
            <button type="button" className="dash-hero-nav-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="12" height="12">
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
            <button type="button" className="dash-hero-nav-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="12" height="12">
                <path d="M9 18l6-6-6-6" />
              </svg>
            </button>
          </div>
        </section>

        {/* Stats row */}
        <section className="dash-stats-row" aria-label="Summary statistics">
          {/* Total Recorded / User */}
          <div className="dash-stat-card">
            <div className="dash-stat-main">
              <div className="dash-stat-label">
                Total Recorded
                <StatTooltip>
                  <div className="dash-stat-tooltip-title">Your top volumes</div>
                  {userStats.top3Volume.length > 0 ? userStats.top3Volume.map((v) => (
                    <div key={v.name} className="dash-stat-tooltip-row">
                      <span>{v.name}</span>
                      <span>{v.unit === "x" ? `x${v.quantity}` : `${v.quantity} SCU`}</span>
                    </div>
                  )) : <div className="dash-stat-tooltip-empty">No inventory recorded</div>}
                </StatTooltip>
              </div>
              <div className="dash-stat-value">
                {userStats.totalVolume > 0
                  ? (userStats.totalVolumeUnit === "x"
                    ? <><span>x</span>{userStats.totalVolume}</>
                    : <>{userStats.totalVolume}<span className="dash-stat-unit"> SCU</span></>)
                  : "—"}
              </div>
              <div className="dash-stat-sublabel">Across all inventory</div>
            </div>
            <StatIcon type="volume" />
          </div>

          {/* Highest Recorded Material */}
          <div className="dash-stat-card">
            <div className="dash-stat-main">
              <div className="dash-stat-label">
                Highest Recorded
                <StatTooltip>
                  <div className="dash-stat-tooltip-title">Top 3 qualities</div>
                  {userStats.top3Highest.length > 0 ? userStats.top3Highest.map((q) => (
                    <div key={q.name + q.quality} className="dash-stat-tooltip-row">
                      <span>{q.name}</span>
                      <span className="dash-stat-tooltip-val">{q.quality}</span>
                    </div>
                  )) : <div className="dash-stat-tooltip-empty">No quality data recorded</div>}
                </StatTooltip>
              </div>
              <div className="dash-stat-value" style={{ color: "#4ade80" }}>
                {userStats.highestQuality ?? "—"}
              </div>
              <div className="dash-stat-sublabel">
                {userStats.highestQualityMaterial ?? "Material quality"}
              </div>
            </div>
            <StatIcon type="high" />
          </div>

          {/* Lowest Ever */}
          <div className="dash-stat-card">
            <div className="dash-stat-main">
              <div className="dash-stat-label">
                Lowest Ever
                <StatTooltip>
                  <div className="dash-stat-tooltip-title">Bottom 3 qualities</div>
                  {userStats.bottom3Lowest.length > 0 ? userStats.bottom3Lowest.map((q) => (
                    <div key={q.name + q.quality} className="dash-stat-tooltip-row">
                      <span>{q.name}</span>
                      <span className="dash-stat-tooltip-val">{q.quality}</span>
                    </div>
                  )) : <div className="dash-stat-tooltip-empty">No quality data recorded</div>}
                </StatTooltip>
              </div>
              <div className="dash-stat-value" style={{ color: "#f87171" }}>
                {userStats.lowestQuality ?? "—"}
              </div>
              <div className="dash-stat-sublabel">
                {userStats.lowestQualityMaterial ?? "Material quality"}
              </div>
            </div>
            <StatIcon type="low" />
          </div>

          {/* Shortage */}
          <div className="dash-stat-card">
            <div className="dash-stat-main">
              <div className="dash-stat-label">Shortage</div>
              <div className="dash-stat-value dash-stat-value--shortage">
                {mockStats.shortage.value}
                <span className="dash-stat-unit" style={{ color: "rgba(248,113,113,0.6)" }}>
                  {mockStats.shortage.unit}
                </span>
              </div>
              <div className="dash-stat-sublabel">{mockStats.shortage.label}</div>
            </div>
            <StatIcon type="shortage" />
          </div>

          {/* Build Queue */}
          <div className="dash-stat-card">
            <div className="dash-stat-main">
              <div className="dash-stat-label">Build Queue</div>
              <div className="dash-stat-value">{mockStats.buildQueue.count}</div>
              <div className="dash-stat-sublabel">{mockStats.buildQueue.label}</div>
            </div>
            <StatIcon type="queue" />
          </div>
        </section>

        {/* Cards row: Inventory | Shortages | Build Queue */}
        <div className="dash-cards-row">

          {/* Inventory Overview */}
          <article className="dash-card" aria-label="Inventory overview">
            <div className="dash-card-header">
              <span className="dash-card-title">Inventory Overview</span>
            </div>
            <div className="dash-card-body dash-inventory-body">
              <div className="dash-donut-wrap">
                <DonutChart
                  owned={mockInventory.owned}
                  needed={mockInventory.needed}
                  shortage={mockInventory.shortage}
                  size={148}
                  strokeWidth={14}
                />
                <div className="dash-donut-center">
                  <div className="dash-donut-center-value">{mockInventory.owned}</div>
                  <div className="dash-donut-center-unit">SCU</div>
                  <div className="dash-donut-center-pct">{ownedPct}% of Needed</div>
                </div>
              </div>
              <div className="dash-donut-legend">
                <div className="dash-donut-legend-row">
                  <span className="dash-donut-legend-dot" style={{ background: "#a78bfa" }} />
                  Owned
                  <span className="dash-donut-legend-value">{mockInventory.owned} SCU</span>
                </div>
                <div className="dash-donut-legend-row">
                  <span className="dash-donut-legend-dot" style={{ background: "#4ade80" }} />
                  Needed
                  <span className="dash-donut-legend-value">{mockInventory.needed} SCU</span>
                </div>
                <div className="dash-donut-legend-row">
                  <span className="dash-donut-legend-dot" style={{ background: "#f87171" }} />
                  Shortage
                  <span className="dash-donut-legend-value">{mockInventory.shortage} SCU</span>
                </div>
              </div>
            </div>
            <div className="dash-card-footer">
              <Link to="/logistics/inventory" className="dash-card-footer-link">
                Go to Inventory <ArrowRight />
              </Link>
            </div>
          </article>

          {/* Material Shortages */}
          <article className="dash-card" aria-label="Material shortages">
            <div className="dash-card-header">
              <span className="dash-card-title">Material Shortages</span>
            </div>
            <div className="dash-card-body">
              <table className="dash-shortages-table">
                <thead>
                  <tr>
                    <th>Material</th>
                    <th>Owned</th>
                    <th>Needed</th>
                    <th>Shortage</th>
                  </tr>
                </thead>
                <tbody>
                  {mockMaterialShortages.map((row) => (
                    <tr key={row.id}>
                      <td>
                        <div className="dash-mat-cell">
                          <MaterialIcon materialName={row.name} size={18} />
                          {row.name}
                        </div>
                      </td>
                      <td>{row.owned}</td>
                      <td>{row.needed}</td>
                      <td>
                        <span className="dash-shortage-badge">{row.shortage}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="dash-card-footer">
              <Link to="/dashboard" className="dash-card-footer-link">
                View All Shortages <ArrowRight />
              </Link>
            </div>
          </article>

          {/* Build Queue */}
          <article className="dash-card" aria-label="Build queue">
            <div className="dash-card-header">
              <span className="dash-card-title">Build Queue</span>
              <div className="dash-card-meta">
                <span>{mockStats.buildQueue.count} Items Queued</span>
                <span className="dash-card-meta-sep">·</span>
                <span>Est. 2h 47m</span>
              </div>
            </div>
            <div className="dash-card-body">
              <ul className="dash-bq-list" role="list">
                {mockBuildQueue.map((item) => {
                  const queued = item.progress < 0;
                  return (
                    <li key={item.id} className="dash-bq-item">
                      <BqThumb color={item.accentColor} />
                      <div className="dash-bq-info">
                        <div className="dash-bq-name">{item.name}</div>
                        <div className="dash-bq-bar-wrap" aria-hidden>
                          <div
                            className="dash-bq-bar-fill"
                            style={{ width: queued ? "0%" : `${item.progress}%` }}
                          />
                        </div>
                      </div>
                      <div className="dash-bq-right">
                        <div className="dash-bq-qty">{item.qty}x</div>
                        {queued ? (
                          <div className="dash-bq-queued">Queued</div>
                        ) : (
                          <div className="dash-bq-pct">{item.progress}%</div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="dash-card-footer">
              <Link to="/logistics/build-queue" className="dash-card-footer-link">
                View Build Queue <ArrowRight />
              </Link>
            </div>
          </article>
        </div>

      </div>

      {/* ── Right column ── */}
      <aside className="dash-right-col" aria-label="System panels">

        {/* Quick Inventory */}
        <QuickInventoryPanel />

        {/* Primary Locations */}
        <div className="dash-panel">
          <div className="dash-panel-header">
            <span className="dash-panel-title">Primary Locations</span>
          </div>
          <div className="dash-panel-body">
            <ul className="dash-locations-list" role="list">
              {mockLocations.map((loc) => (
                <li key={loc.id} className="dash-location-row">
                  <LocationIcon type={loc.type} />
                  <span className="dash-location-name">{loc.name}</span>
                  <span className="dash-location-scu">{loc.scu.toFixed(2)} SCU</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Mining Recommendations */}
        <div className="dash-panel">
          <div className="dash-panel-header">
            <span className="dash-panel-title">Mining Recommendations</span>
          </div>
          <div className="dash-panel-body">
            <ul className="dash-updates-list" role="list">
              {miningRecommendations.map((rec) => (
                <li key={rec.id} className="dash-update-item">
                  <div className="dash-update-thumb" aria-hidden>
                    <svg viewBox="0 0 20 14" width="24" height="17" fill="none">
                      <rect width="20" height="14" rx="2" fill="rgba(167,139,250,0.15)" />
                      <path d="M10 7l-3 4h6zM10 3v1M6 5l.7.7M14 5l-.7.7" stroke="#a78bfa" strokeWidth="1.3" strokeLinecap="round" strokeOpacity="0.85" />
                    </svg>
                  </div>
                  <div className="dash-update-info">
                    <div className="dash-update-title">{rec.material}</div>
                    <div className="dash-update-desc">{rec.location}</div>
                    <div className="dash-update-date dash-rec-reason">{rec.reason}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="dash-panel-footer">
            <Link to="/industry/mining" className="dash-panel-link">View Mining <ArrowRight size={10} /></Link>
          </div>
        </div>
      </aside>
    </div>
  );
}

// ── Sub-components ─────────────────────────────────────────────────

function QuickInventoryPanel() {
  return (
    <div className="dash-panel">
      <div className="dash-panel-header">
        <span className="dash-panel-title">Quick Inventory</span>
      </div>
      <div className="dash-panel-body">
        <p className="dash-panel-desc">Manage stock records and imports.</p>
        <div className="dash-qinv-actions">
          <Link to="/logistics/inventory" className="dash-qinv-btn">
            <svg aria-hidden viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="13" height="13">
              <rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" />
            </svg>
            View Inventory
          </Link>
        </div>
      </div>
    </div>
  );
}

