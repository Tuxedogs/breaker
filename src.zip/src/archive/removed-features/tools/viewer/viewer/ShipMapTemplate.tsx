import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Billboard, Html, OrbitControls, Text } from "@react-three/drei";
import {
  ACESFilmicToneMapping,
  Box3,
  BufferAttribute,
  BufferGeometry,
  Color,
  Euler,
  FogExp2,
  FrontSide,
  Group,
  Material,
  Matrix4,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  Object3D,
  Plane,
  PerspectiveCamera,
  Raycaster,
  SRGBColorSpace,
  Texture,
  TextureLoader,
  Vector3,
  Vector2,
} from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { GLTFLoader, type GLTF } from "three/examples/jsm/loaders/GLTFLoader.js";
import { OBJLoader } from "three/examples/jsm/loaders/OBJLoader.js";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import CTM from "../../lib/openctm/ctm.js";
import {
  ArmoryIcon,
  CoolerIcon,
  CrewQuartersIcon,
  ElevatorIcon,
  EngineeringTerminalIcon,
  LadderIcon,
  LifeSupportIcon,
  PowerPlantIcon,
  QuantumDriveIcon,
  RadarIcon,
  ShieldGeneratorIcon,
  TorpedoStationIcon,
  TurretStationIcon,
} from "../../components/icons/DeckMarkerIcons";

type CtmBody = {
  indices: Uint32Array;
  vertices: Float32Array;
  normals?: Float32Array;
  uvMaps?: Array<{ uv: Float32Array }>;
  attrMaps?: Array<{ name?: string; attr: Float32Array }>;
};

type CtmFile = {
  body: CtmBody;
};

type CtmModule = {
  Stream: new (data: Uint8Array) => unknown;
  File: new (stream: unknown) => CtmFile;
};

export type ShipMapViewState = {
  position: [number, number, number];
  target: [number, number, number];
};

export type ShipMapDeckOverlay = {
  title: string;
  id: string;
  deckMin: number;
  deckMax: number;
  svgPath?: string;
  annotations?: ShipMapDeckAnnotationConfig;
  viewBox: [number, number];
  rotationDeg?: number;
  offsetX?: number;
  offsetZ?: number;
  scaleMultiplier?: number;
  widthMultiplier?: number;
  heightMultiplier?: number;
};

export type ShipMapDeckAnnotationKind =
  | "Main Turret"
  | "Terminal"
  | "Power"
  | "Shield"
  | "Cooler"
  | "Radar"
  | "Quantum"
  | "Life-Support"
  | "Ladder"
  | "Elevator"
  | "Cargo";

export type ShipMapDeckAnnotationPathing = {
  connectsDeckIds: Array<"bottom" | "mid" | "top">;
  toLabels?: string[];
};

export type ShipMapDeckAnnotationBase = {
  id: string;
  label: string;
  token?: string;
  kind: ShipMapDeckAnnotationKind;
  worldPosition: [number, number, number];
  screenOffset?: [number, number];
  colorHint?: string;
  pathing?: ShipMapDeckAnnotationPathing;
};

export type ShipMapDeckComponentAnnotation = ShipMapDeckAnnotationBase & {
  annotationType: "component";
};

export type ShipMapDeckLabelAnnotation = ShipMapDeckAnnotationBase & {
  annotationType: "label";
};

export type ShipMapDeckAnnotationConfig = {
  fixedHeightAboveDeckMin: number;
  worldOffset?: [number, number, number];
  components: ShipMapDeckComponentAnnotation[];
  labels: ShipMapDeckLabelAnnotation[];
};

type DeckMarkerIconComponent = (props: { className?: string }) => React.JSX.Element;
type LegendSectionKey = "ship-components" | "crew-stations" | "navigation";
type LegendItemKey =
  | "power"
  | "radar"
  | "shield"
  | "quantum"
  | "cooler"
  | "crew-quarters"
  | "main-turret"
  | "torpedo-terminal"
  | "engineer-terminal"
  | "elevators"
  | "ladders"
  | "armory";
type ScreenPoint = { x: number; y: number };
type ScreenPath = { points: ScreenPoint[]; color: string };
type DeckMarkerTraceState = {
  key: string;
  annotationIds: readonly string[];
  color: string;
  startAnnotationId?: string;
};
type DeckMarkerLegendItem = {
  key: LegendItemKey;
  label: string;
  color: string;
  Icon: DeckMarkerIconComponent;
  annotationIds: readonly string[];
};
type DeckMarkerLegendSection = {
  key: LegendSectionKey;
  title: string;
  items: readonly DeckMarkerLegendItem[];
};

const DECK_MARKER_LEGEND: readonly DeckMarkerLegendSection[] = [
  {
    key: "ship-components",
    title: "Ship Components",
    items: [
      { key: "power", label: "Power Plants", color: "var(--component-power)", Icon: PowerPlantIcon, annotationIds: ["power-plant-1", "power-plant-2"] },
      { key: "shield", label: "Shield Generators", color: "var(--component-shield)", Icon: ShieldGeneratorIcon, annotationIds: ["shield-generator-1", "shield-generator-2"] },
      { key: "quantum", label: "Quantum Drive", color: "var(--component-qt)", Icon: QuantumDriveIcon, annotationIds: ["qt-drive"] },
      { key: "radar", label: "Radar", color: "var(--component-radar)", Icon: RadarIcon, annotationIds: ["radar"] },
      { key: "cooler", label: "Coolers", color: "var(--component-cooler)", Icon: CoolerIcon, annotationIds: ["cooler-1", "cooler-2"] },
    ],
  },
  {
    key: "crew-stations",
    title: "Crew Stations",
    items: [
      { key: "crew-quarters", label: "Crew Quarters", color: "#e2e8f0", Icon: CrewQuartersIcon, annotationIds: ["crew-quarters-section"] },
      { key: "main-turret", label: "Main Turret", color: "var(--component-gun)", Icon: TurretStationIcon, annotationIds: ["gun-01"] },
      { key: "torpedo-terminal", label: "Torpedo Terminal", color: "var(--component-gun)", Icon: TorpedoStationIcon, annotationIds: ["torpedo-operator-terminal"] },
      { key: "engineer-terminal", label: "Engineer Terminals", color: "#67a1f9", Icon: EngineeringTerminalIcon, annotationIds: ["engineer-terminal-1", "engineer-terminal-2"] },
      { key: "armory", label: "Armory", color: "#fca5a5", Icon: ArmoryIcon, annotationIds: ["armory-section"] },
    ],
  },
  {
    key: "navigation",
    title: "Navigation",
    items: [
      { key: "elevators", label: "Elevator", color: "var(--component-navigation)", Icon: ElevatorIcon, annotationIds: ["elevator"] },
      { key: "ladders", label: "Ladders", color: "var(--component-navigation)", Icon: LadderIcon, annotationIds: ["main-ladder", "secondary-ladder-port", "secondary-ladder-starboard"] },
    ],
  },
];

type DeckOverlayRegion = {
  key: string;
  label: string;
  centerX: number;
  centerY: number;
  bounds: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  highlightMarkup: string;
};

type ShipMapTemplateProps = {
  title: string;
  subtitle: string;
  modelPath: string;
  viewStorageKey: string;
  fallbackView: ShipMapViewState;
  defaultDeckOverlayId?: string;
  defaultInteriorEnabled?: boolean;
  showDebugPanel?: boolean;
  showHeader?: boolean;
  /** Edge-to-edge viewer: fills main under nav; pair with AppShell maps layout. */
  immersiveFocus?: boolean;
  deckOverlayConfig?: ShipMapDeckOverlayConfig;
  mergeMeshesForPerformance?: boolean;
  modelTransform?: {
    scale?: number;
    offset?: [number, number, number];
    rotation?: [number, number, number];
  };
};

const SHIP_VIEWER_SCENE_BG = "#02040a";
const SHIP_VIEWER_FOG_DENSITY = 0.048;
const SHIP_VIEWER_TONE_EXPOSURE = 0.92;
/** Interior ↔ exterior blend duration; ref-driven (no per-frame React state). */
const INTERIOR_TRANSITION_MS = 520;
const INTERIOR_BOOT_MIN_MS = 420;
const INTERIOR_CAMERA_MIN_Y = 0.492;

function InteriorTransitionDriver({
  progressRef,
  interiorTarget,
  onSettled,
}: {
  progressRef: React.MutableRefObject<number>;
  interiorTarget: boolean;
  onSettled?: () => void;
}) {
  const { invalidate } = useThree();
  const rafRef = useRef<number | null>(null);
  const onSettledRef = useRef(onSettled);

  useEffect(() => {
    onSettledRef.current = onSettled;
  }, [onSettled]);

  useEffect(() => {
    const target = interiorTarget ? 1 : 0;
    const from = progressRef.current;
    if (Math.abs(target - from) < 0.0005) {
      progressRef.current = target;
      invalidate();
      onSettledRef.current?.();
      return;
    }

    const startTime = performance.now();
    let cancelled = false;

    const step = (now: number) => {
      if (cancelled) return;
      const t = Math.min((now - startTime) / INTERIOR_TRANSITION_MS, 1);
      const eased = 0.5 - Math.cos(t * Math.PI) * 0.5;
      progressRef.current = from + (target - from) * eased;
      invalidate();
      if (t < 1) {
        rafRef.current = requestAnimationFrame(step);
      } else {
        progressRef.current = target;
        invalidate();
        onSettledRef.current?.();
      }
    };

    rafRef.current = requestAnimationFrame(step);
    return () => {
      cancelled = true;
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [interiorTarget, invalidate, progressRef]);

  return null;
}

function RenderInvalidateOnChange({
  active,
  depsKey,
}: {
  active: boolean;
  depsKey: string;
}) {
  const { invalidate } = useThree();

  useEffect(() => {
    if (!active) return;

    let firstFrame: number | null = null;
    let secondFrame: number | null = null;

    firstFrame = window.requestAnimationFrame(() => {
      invalidate();
      secondFrame = window.requestAnimationFrame(() => {
        invalidate();
      });
    });

    return () => {
      if (firstFrame !== null) window.cancelAnimationFrame(firstFrame);
      if (secondFrame !== null) window.cancelAnimationFrame(secondFrame);
    };
  }, [active, depsKey, invalidate]);

  return null;
}

type ModelSource = "gltf" | "obj" | "ctm";

type ResolvedModelTransform = {
  scale: number;
  offset: [number, number, number];
  rotation: [number, number, number];
};

type LoadedModelAsset = {
  source: ModelSource;
  scene: Object3D;
  baseBounds: Box3;
  suggestedScale: number;
};

type CachedModelAssetEntry = {
  refs: number;
  promise: Promise<LoadedModelAsset>;
  asset: LoadedModelAsset | null;
};

const MODEL_ASSET_CACHE = new Map<string, CachedModelAssetEntry>();
const OVERLAY_TEXTURE_CACHE = new Map<string, Texture>();
const OVERLAY_TEXTURE_PROMISE_CACHE = new Map<string, Promise<Texture>>();
const gltfLoader = new GLTFLoader();
const objLoader = new OBJLoader();
const textureLoader = new TextureLoader();

function round3(value: number): number {
  return Math.round(value * 1000) / 1000;
}

function resolveDeckPlaneSize(
  deck: Pick<ShipMapDeckOverlay, "viewBox" | "scaleMultiplier"> & {
    widthMultiplier?: number;
    heightMultiplier?: number;
  },
  modelSize: { x: number; z: number },
): [number, number] {
  const maxWidth = modelSize.x * 1.12;
  const maxDepth = modelSize.z * 1.12;
  const aspect = deck.viewBox[0] / Math.max(deck.viewBox[1], 1);

  let width = maxWidth;
  let depth = width / Math.max(aspect, 0.0001);
  if (depth > maxDepth) {
    depth = maxDepth;
    width = depth * aspect;
  }
  const scaleMultiplier = deck.scaleMultiplier ?? 1;
  const widthMultiplier = deck.widthMultiplier ?? 1;
  const heightMultiplier = deck.heightMultiplier ?? 1;
  return [width * scaleMultiplier * widthMultiplier, depth * scaleMultiplier * heightMultiplier];
}

export type ShipMapDeckOverlayConfig = {
  decks: ShipMapDeckOverlay[];
};

function labelizeRegion(value: string): string {
  return value
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function parseDeckOverlayRegions(svgText: string): {
  regions: DeckOverlayRegion[];
  sourceViewBox: string | null;
} {
  const parser = new DOMParser();
  const parsed = parser.parseFromString(svgText, "image/svg+xml");
  const svgRoot = parsed.querySelector("svg");
  if (!svgRoot) {
    return { regions: [], sourceViewBox: null };
  }

  const sourceViewBox = svgRoot.getAttribute("viewBox")?.trim() ?? null;
  const graphics = Array.from(svgRoot.querySelectorAll("path, polygon, rect, circle, ellipse"));
  if (graphics.length === 0) {
    return { regions: [], sourceViewBox };
  }

  const measureSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  if (sourceViewBox) {
    measureSvg.setAttribute("viewBox", sourceViewBox);
  }
  measureSvg.setAttribute("width", "1");
  measureSvg.setAttribute("height", "1");
  measureSvg.style.position = "absolute";
  measureSvg.style.left = "-99999px";
  measureSvg.style.top = "-99999px";
  measureSvg.style.pointerEvents = "none";
  measureSvg.style.opacity = "0";
  document.body.appendChild(measureSvg);

  const serializer = new XMLSerializer();
  const regions: DeckOverlayRegion[] = [];

  for (let index = 0; index < graphics.length; index += 1) {
    const sourceElement = graphics[index];
    const measureElement = sourceElement.cloneNode(true) as SVGGraphicsElement;
    measureSvg.appendChild(measureElement);

    let bbox: DOMRect;
    try {
      bbox = measureElement.getBBox();
    } catch {
      measureSvg.removeChild(measureElement);
      continue;
    }
    measureSvg.removeChild(measureElement);

    const idCandidate = sourceElement.getAttribute("id")?.trim();
    const nameCandidate =
      sourceElement.getAttribute("data-name")?.trim() ??
      sourceElement.getAttribute("aria-label")?.trim() ??
      sourceElement.getAttribute("inkscape:label")?.trim();
    const rawLabel = nameCandidate || idCandidate || `section_${index + 1}`;
    const label = labelizeRegion(rawLabel) || `Section ${index + 1}`;
    const stableKey = `${idCandidate || "section"}-${index}`;

    const highlightElement = sourceElement.cloneNode(true) as Element;
    highlightElement.removeAttribute("style");
    highlightElement.setAttribute("fill", "#67e8f9");
    highlightElement.setAttribute("fill-opacity", "0.48");
    highlightElement.setAttribute("stroke", "#a5f3fc");
    highlightElement.setAttribute("stroke-width", "4");
    highlightElement.setAttribute("stroke-linejoin", "round");
    highlightElement.setAttribute("stroke-linecap", "round");

    regions.push({
      key: stableKey,
      label,
      centerX: round3(bbox.x + bbox.width / 2),
      centerY: round3(bbox.y + bbox.height / 2),
      bounds: {
        x: round3(bbox.x),
        y: round3(bbox.y),
        width: round3(bbox.width),
        height: round3(bbox.height),
      },
      highlightMarkup: serializer.serializeToString(highlightElement),
    });
  }

  document.body.removeChild(measureSvg);
  return { regions, sourceViewBox };
}

function buildHighlightTextureDataUri(viewBox: string, highlightMarkup: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${viewBox}">${highlightMarkup}</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function buildDeckShadowTextureDataUri(): string {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
      <defs>
        <radialGradient id="deck-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="rgba(0,0,0,0.55)" />
          <stop offset="62%" stop-color="rgba(0,0,0,0.24)" />
          <stop offset="100%" stop-color="rgba(0,0,0,0)" />
        </radialGradient>
      </defs>
      <rect x="0" y="0" width="100" height="100" fill="url(#deck-shadow)" />
    </svg>
  `;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function readSavedView(storageKey: string, fallbackView: ShipMapViewState): ShipMapViewState {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return fallbackView;
    const parsed = JSON.parse(raw) as Partial<ShipMapViewState>;
    const position = parsed.position;
    const target = parsed.target;
    if (
      !Array.isArray(position) ||
      position.length !== 3 ||
      !position.every((n) => typeof n === "number") ||
      !Array.isArray(target) ||
      target.length !== 3 ||
      !target.every((n) => typeof n === "number")
    ) {
      return fallbackView;
    }
    return {
      position: [position[0], position[1], position[2]],
      target: [target[0], target[1], target[2]],
    };
  } catch {
    return fallbackView;
  }
}

function resolveModelSource(modelPath: string): ModelSource {
  const normalizedPath = modelPath.split("?")[0].trim().toLowerCase();
  if (normalizedPath.endsWith(".obj")) return "obj";
  if (normalizedPath.endsWith(".ctm")) return "ctm";
  return "gltf";
}

function computeSuggestedScale(bounds: Box3): number {
  const size = new Vector3();
  bounds.getSize(size);
  const maxAxis = Math.max(size.x, size.y, size.z) || 1;
  return 5.4 / maxAxis;
}

function ensureFiniteBounds(bounds: Box3): Box3 {
  if (
    bounds.isEmpty() ||
    !Number.isFinite(bounds.min.x) ||
    !Number.isFinite(bounds.min.y) ||
    !Number.isFinite(bounds.min.z) ||
    !Number.isFinite(bounds.max.x) ||
    !Number.isFinite(bounds.max.y) ||
    !Number.isFinite(bounds.max.z)
  ) {
    return new Box3(new Vector3(-0.5, -0.5, -0.5), new Vector3(0.5, 0.5, 0.5));
  }
  return bounds;
}

function getSceneBounds(scene: Object3D): Box3 {
  scene.updateWorldMatrix(true, true);
  const measuredBounds = new Box3().setFromObject(scene);
  return ensureFiniteBounds(measuredBounds);
}

function disposeMaterial(material: Material) {
  for (const value of Object.values(material)) {
    if (value && typeof value === "object" && "isTexture" in value && value.isTexture) {
      value.dispose();
    }
  }
  material.dispose();
}

function loadOverlayTexture(texturePath: string): Promise<Texture> {
  const cachedTexture = OVERLAY_TEXTURE_CACHE.get(texturePath);
  if (cachedTexture) {
    return Promise.resolve(cachedTexture);
  }

  const pendingTexture = OVERLAY_TEXTURE_PROMISE_CACHE.get(texturePath);
  if (pendingTexture) {
    return pendingTexture;
  }

  const promise = textureLoader.loadAsync(texturePath).then((texture) => {
    texture.colorSpace = SRGBColorSpace;
    OVERLAY_TEXTURE_CACHE.set(texturePath, texture);
    OVERLAY_TEXTURE_PROMISE_CACHE.delete(texturePath);
    return texture;
  }).catch((error) => {
    OVERLAY_TEXTURE_PROMISE_CACHE.delete(texturePath);
    throw error;
  });

  OVERLAY_TEXTURE_PROMISE_CACHE.set(texturePath, promise);
  return promise;
}

function useOverlayTexture(texturePath: string) {
  const cachedTexture = OVERLAY_TEXTURE_CACHE.get(texturePath) ?? null;
  const [loadedTexture, setLoadedTexture] = useState<Texture | null>(cachedTexture);

  useEffect(() => {
    if (cachedTexture) {
      return;
    }

    let cancelled = false;

    loadOverlayTexture(texturePath)
      .then((loadedTexture) => {
        if (cancelled) return;
        setLoadedTexture(loadedTexture);
      })
      .catch(() => {
        if (cancelled) return;
        setLoadedTexture(null);
      });

    return () => {
      cancelled = true;
    };
  }, [cachedTexture, texturePath]);

  return cachedTexture ?? loadedTexture;
}

function disposeObject3dResources(root: Object3D) {
  const geometries = new Set<BufferGeometry>();
  const materials = new Set<Material>();

  root.traverse((node) => {
    if (!(node instanceof Mesh)) return;
    if (node.geometry) {
      geometries.add(node.geometry);
    }
    if (Array.isArray(node.material)) {
      for (const material of node.material) {
        if (material) {
          materials.add(material);
        }
      }
      return;
    }
    if (node.material) {
      materials.add(node.material);
    }
  });

  geometries.forEach((geometry) => geometry.dispose());
  materials.forEach((material) => disposeMaterial(material));
}

function createGeometryFromCtm(body: CtmBody): BufferGeometry {
  const geometry = new BufferGeometry();
  geometry.setIndex(new BufferAttribute(body.indices, 1));
  geometry.setAttribute("position", new BufferAttribute(body.vertices, 3));

  if (body.normals) {
    geometry.setAttribute("normal", new BufferAttribute(body.normals, 3));
  } else {
    geometry.computeVertexNormals();
  }

  const uvMap = body.uvMaps?.[0];
  if (uvMap?.uv) {
    geometry.setAttribute("uv", new BufferAttribute(uvMap.uv, 2));
  }

  const colorMap = body.attrMaps?.find((map) => map.name === "Color");
  if (colorMap?.attr) {
    const colorArray = new Float32Array((colorMap.attr.length / 4) * 3);
    for (let i = 0, j = 0; i < colorMap.attr.length; i += 4) {
      colorArray[j++] = colorMap.attr[i];
      colorArray[j++] = colorMap.attr[i + 1];
      colorArray[j++] = colorMap.attr[i + 2];
    }
    geometry.setAttribute("color", new BufferAttribute(colorArray, 3));
  }

  geometry.computeBoundingBox();
  const bounds = geometry.boundingBox ?? new Box3();
  const center = new Vector3();
  bounds.getCenter(center);
  geometry.translate(-center.x, -center.y, -center.z);
  geometry.computeBoundingBox();
  return geometry;
}

async function loadCtmModelAsset(modelPath: string): Promise<LoadedModelAsset> {
  const response = await fetch(modelPath);
  if (!response.ok) {
    throw new Error(`Model request failed: ${response.status}`);
  }

  const buffer = await response.arrayBuffer();
  const data = new Uint8Array(buffer);
  const ctm = CTM as unknown as CtmModule;
  const stream = new ctm.Stream(data);
  const file = new ctm.File(stream);
  const geometry = createGeometryFromCtm(file.body);
  const mesh = new Mesh(geometry, new MeshStandardMaterial());
  const scene = new Group();
  scene.add(mesh);
  const baseBounds = getSceneBounds(scene);
  return {
    source: "ctm",
    scene,
    baseBounds,
    suggestedScale: computeSuggestedScale(baseBounds),
  };
}

function getGltfRoot(gltf: GLTF): Object3D {
  if (gltf.scene) {
    return gltf.scene;
  }
  if (gltf.scenes[0]) {
    return gltf.scenes[0];
  }
  throw new Error("GLTF did not include a scene root.");
}

async function loadModelAsset(modelPath: string): Promise<LoadedModelAsset> {
  const source = resolveModelSource(modelPath);

  if (source === "gltf") {
    const gltf = await gltfLoader.loadAsync(modelPath);
    const scene = getGltfRoot(gltf);
    const baseBounds = getSceneBounds(scene);
    return {
      source,
      scene,
      baseBounds,
      suggestedScale: computeSuggestedScale(baseBounds),
    };
  }

  if (source === "obj") {
    const scene = await objLoader.loadAsync(modelPath);
    const baseBounds = getSceneBounds(scene);
    return {
      source,
      scene,
      baseBounds,
      suggestedScale: computeSuggestedScale(baseBounds),
    };
  }

  return loadCtmModelAsset(modelPath);
}

async function acquireModelAsset(modelPath: string): Promise<LoadedModelAsset> {
  let cacheEntry = MODEL_ASSET_CACHE.get(modelPath);

  if (!cacheEntry) {
    // Cache loaded source assets and release GPU resources when last consumer unmounts.
    const newEntry: CachedModelAssetEntry = {
      refs: 0,
      asset: null,
      promise: null as unknown as Promise<LoadedModelAsset>,
    };
    newEntry.promise = loadModelAsset(modelPath).then((asset) => {
      newEntry.asset = asset;
      if (newEntry.refs <= 0) {
        disposeObject3dResources(asset.scene);
        MODEL_ASSET_CACHE.delete(modelPath);
      }
      return asset;
    }).catch((error) => {
      MODEL_ASSET_CACHE.delete(modelPath);
      throw error;
    });
    MODEL_ASSET_CACHE.set(modelPath, newEntry);
    cacheEntry = newEntry;
  }

  cacheEntry.refs += 1;
  return cacheEntry.promise;
}

function releaseModelAsset(modelPath: string) {
  const cacheEntry = MODEL_ASSET_CACHE.get(modelPath);
  if (!cacheEntry) return;

  cacheEntry.refs -= 1;
  if (cacheEntry.refs > 0) return;
  if (!cacheEntry.asset) return;

  disposeObject3dResources(cacheEntry.asset.scene);
  MODEL_ASSET_CACHE.delete(modelPath);
}

function createMergedMeshScene(modelScene: Object3D): Object3D {
  const clonedGeometries: BufferGeometry[] = [];
  const worldMatrix = new Matrix4();

  modelScene.updateWorldMatrix(true, true);
  modelScene.traverse((node) => {
    if (!(node instanceof Mesh)) return;
    if (!node.geometry) return;
    const clonedGeometry = node.geometry.clone();
    worldMatrix.copy(node.matrixWorld);
    clonedGeometry.applyMatrix4(worldMatrix);
    clonedGeometries.push(clonedGeometry);
  });

  if (clonedGeometries.length === 0) {
    return modelScene;
  }

  const mergedGeometry = mergeGeometries(clonedGeometries, false);
  clonedGeometries.forEach((geometry) => geometry.dispose());

  if (!mergedGeometry) {
    return modelScene;
  }

  const mergedMesh = new Mesh(mergedGeometry, new MeshStandardMaterial());
  const mergedScene = new Group();
  mergedScene.add(mergedMesh);
  mergedScene.userData.__ownedGeometries = [mergedGeometry];
  mergedScene.userData.__ownedMaterials = [mergedMesh.material];
  return mergedScene;
}

function cloneSceneMeshResources(modelScene: Object3D): {
  ownedGeometries: BufferGeometry[];
  ownedMaterials: Material[];
} {
  const ownedGeometries: BufferGeometry[] = [];
  const ownedMaterials: Material[] = [];
  modelScene.traverse((node) => {
    if (!(node instanceof Mesh)) return;
    if (!node.geometry) return;
    const ownedGeometry = node.geometry.clone();
    node.geometry = ownedGeometry;
    ownedGeometries.push(ownedGeometry);
    if (Array.isArray(node.material)) {
      node.material = node.material.map((material) => {
        const ownedMaterial = material.clone();
        ownedMaterials.push(ownedMaterial);
        return ownedMaterial;
      });
      return;
    }
    const ownedMaterial = node.material.clone();
    node.material = ownedMaterial;
    ownedMaterials.push(ownedMaterial);
  });
  return { ownedGeometries, ownedMaterials };
}

function createModelSceneInstance(asset: LoadedModelAsset, mergeMeshesForPerformance: boolean): Object3D {
  const clonedScene = asset.scene.clone(true);
  if (!mergeMeshesForPerformance) {
    const { ownedGeometries, ownedMaterials } = cloneSceneMeshResources(clonedScene);
    clonedScene.userData.__ownedGeometries = ownedGeometries;
    clonedScene.userData.__ownedMaterials = ownedMaterials;
    return clonedScene;
  }
  return createMergedMeshScene(clonedScene);
}

function cloneModelSceneForPass(modelScene: Object3D): Object3D {
  const clonedScene = modelScene.clone(true);
  const { ownedGeometries, ownedMaterials } = cloneSceneMeshResources(clonedScene);
  clonedScene.userData.__ownedGeometries = ownedGeometries;
  clonedScene.userData.__ownedMaterials = ownedMaterials;
  return clonedScene;
}

function disposeModelSceneInstance(modelScene: Object3D) {
  const ownedGeometries = modelScene.userData.__ownedGeometries as BufferGeometry[] | undefined;
  if (ownedGeometries?.length) {
    for (const geometry of ownedGeometries) {
      geometry.dispose();
    }
  }
  modelScene.userData.__ownedGeometries = [];
  const ownedMaterials = modelScene.userData.__ownedMaterials as Material[] | undefined;
  if (ownedMaterials?.length) {
    for (const material of ownedMaterials) {
      disposeMaterial(material);
    }
  }
  modelScene.userData.__ownedMaterials = [];
}

function resolveModelTransform(transform: ShipMapTemplateProps["modelTransform"], fallbackScale: number): ResolvedModelTransform {
  return {
    scale: transform?.scale ?? fallbackScale,
    offset: transform?.offset ?? [0, 0, 0],
    rotation: transform?.rotation ?? [0, 0, 0],
  };
}

function createTransformMatrix(transform: ResolvedModelTransform): Matrix4 {
  const matrix = new Matrix4();
  const scale = new Vector3(transform.scale, transform.scale, transform.scale);
  matrix.makeRotationFromEuler(new Euler(transform.rotation[0], transform.rotation[1], transform.rotation[2]));
  matrix.scale(scale);
  matrix.setPosition(transform.offset[0], transform.offset[1], transform.offset[2]);
  return matrix;
}

function computeBoundsWithTransform(baseBounds: Box3, transform: ResolvedModelTransform): Box3 {
  const transformedBounds = baseBounds.clone();
  transformedBounds.applyMatrix4(createTransformMatrix(transform));
  return ensureFiniteBounds(transformedBounds);
}

function FitModelMesh({
  modelScene,
  transform,
  clippingPlanes,
  opacity = 1,
  opacityRef,
  opacityScale = 1,
  invertProgress = false,
  ghosted = false,
  renderOrder = 0,
}: {
  modelScene: Object3D;
  transform: ResolvedModelTransform;
  clippingPlanes?: Plane[];
  /** Static opacity when not animating via ref */
  opacity?: number;
  /** 0–1 interior blend; read each frame (avoids React re-renders during transition) */
  opacityRef?: React.MutableRefObject<number>;
  /** Multiply ref value (e.g. ghost hull 0.14) */
  opacityScale?: number;
  /** Main hull: 1 − progress */
  invertProgress?: boolean;
  ghosted?: boolean;
  renderOrder?: number;
}) {
  const materialsRef = useRef<Material[]>([]);
  const ghostColorBackupRef = useRef<Map<Material, Color>>(new Map());

  useLayoutEffect(() => {
    const ghostColorBackup = ghostColorBackupRef.current;
    materialsRef.current = [];
    modelScene.traverse((node) => {
      if (!(node instanceof Mesh)) return;
      node.renderOrder = renderOrder;
      const materials = Array.isArray(node.material) ? node.material : [node.material];
      for (const material of materials) {
        materialsRef.current.push(material);
        material.clippingPlanes = clippingPlanes ?? [];
        material.clipShadows = Boolean(clippingPlanes?.length);
        if (ghosted && "color" in material && material.color instanceof Color) {
          const base = material.color.clone();
          ghostColorBackup.set(material, base);
          material.color.copy(base).multiplyScalar(0.72);
        }
        material.needsUpdate = true;
      }
    });

    return () => {
      for (const material of materialsRef.current) {
        material.clippingPlanes = [];
        material.clipShadows = false;
        const base = ghostColorBackup.get(material);
        if (base && "color" in material && material.color instanceof Color) {
          material.color.copy(base);
        }
        ghostColorBackup.delete(material);
        material.transparent = false;
        material.opacity = 1;
        material.depthWrite = true;
        material.needsUpdate = true;
      }
      materialsRef.current = [];
    };
  }, [modelScene, clippingPlanes, ghosted, renderOrder]);

  useFrame(() => {
    const materials = materialsRef.current.slice();
    if (materials.length === 0) return;

    let op: number;
    if (opacityRef) {
      const p = opacityRef.current;
      op = invertProgress ? 1 - p : p * opacityScale;
    } else {
      op = opacity;
    }
    op = Math.max(0, Math.min(1, op));
    const transparent = ghosted || op < 0.999;
    for (const material of materials) {
      material.transparent = transparent;
      material.opacity = op;
      material.depthWrite = !(ghosted || op < 0.999);
    }
  });

  return (
    <group
      position={transform.offset}
      rotation={transform.rotation}
      scale={[transform.scale, transform.scale, transform.scale]}
    >
      <primitive object={modelScene} />
    </group>
  );
}

function DeckOverlayPlane({
  deck,
  modelSize,
  texturePath,
  opacityScale,
  progressRef,
  renderOrder,
  yOffset = 0.002,
}: {
  deck: ShipMapDeckOverlay;
  modelSize: { x: number; z: number };
  texturePath: string;
  /** Final opacity = progressRef.current * opacityScale */
  opacityScale: number;
  progressRef: React.MutableRefObject<number>;
  renderOrder: number;
  yOffset?: number;
}) {
  const texture = useOverlayTexture(texturePath);
  const materialRef = useRef<MeshBasicMaterial | null>(null);

  const [planeWidth, planeDepth] = useMemo(
    () => resolveDeckPlaneSize(deck, modelSize),
    [deck, modelSize],
  );

  const y = deck.deckMin + yOffset;
  const rotationInPlane = -(((deck.rotationDeg ?? 0) * Math.PI) / 180);
  const offsetX = deck.offsetX ?? 0;
  const offsetZ = deck.offsetZ ?? 0;

  useFrame(() => {
    const material = materialRef.current;
    if (!material) return;
    const nextOpacity = Math.max(0, Math.min(1, progressRef.current * opacityScale));
    material.opacity = nextOpacity;
  });

  if (!texture) return null;

  return (
    <group position={[offsetX, y, offsetZ]} rotation={[-Math.PI / 2, 0, rotationInPlane]}>
      <mesh renderOrder={renderOrder}>
        <planeGeometry args={[planeWidth, planeDepth]} />
        <meshBasicMaterial
          ref={materialRef}
          map={texture}
          side={FrontSide}
          transparent
          opacity={0}
          depthTest
          depthWrite
          toneMapped={false}
        />
      </mesh>
    </group>
  );
}

function resolveDeckMarkerIcon(annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation): DeckMarkerIconComponent | null {
  if (annotation.id === "crew-quarters-section") return CrewQuartersIcon;
  if (annotation.id === "armory-section") return ArmoryIcon;
  if (annotation.id === "elevator") return ElevatorIcon;
  if (annotation.id === "torpedo-operator-terminal") return TorpedoStationIcon;
  if (annotation.kind === "Ladder") return LadderIcon;
  if (annotation.kind === "Main Turret") return TurretStationIcon;
  if (annotation.kind === "Terminal") return EngineeringTerminalIcon;
  if (annotation.kind === "Power") return PowerPlantIcon;
  if (annotation.kind === "Shield") return ShieldGeneratorIcon;
  if (annotation.kind === "Cooler") return CoolerIcon;
  if (annotation.kind === "Radar") return RadarIcon;
  if (annotation.kind === "Quantum") return QuantumDriveIcon;
  if (annotation.kind === "Life-Support") return LifeSupportIcon;
  return null;
}

function getAnnotationBadgeText(annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation): string {
  if (annotation.token?.trim()) return annotation.token.trim();
  if (annotation.id === "crew-quarters-section") return "CQ";
  if (annotation.id === "armory-section") return "AR";
  if (annotation.id === "torpedo-operator-terminal") return "TT";
  if (annotation.id === "engineer-terminal-1" || annotation.id === "engineer-terminal-2") return "ET";
  if (annotation.id === "gun-01") return "MT";
  if (annotation.id === "qt-drive") return "QT";
  if (annotation.id === "power-plant-1" || annotation.id === "power-plant-2") return "PP";
  if (annotation.id === "shield-generator-1" || annotation.id === "shield-generator-2") return "SG";
  if (annotation.id === "cooler-1" || annotation.id === "cooler-2") return "CL";
  if (annotation.id === "life-support") return "LS";
  if (annotation.id === "main-ladder" || annotation.id.startsWith("secondary-ladder")) return "LD";
  if (annotation.id === "elevator") return "EL";
  if (annotation.id === "radar") return "RD";

  return annotation.label
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("") || "MK";
}

function projectWorldPointToOverlay(
  point: Vector3,
  camera: PerspectiveCamera,
  overlayBounds: DOMRect,
): ScreenPoint | null {
  const projected = point.clone().project(camera);
  if (projected.z < -1 || projected.z > 1) return null;

  return {
    x: ((projected.x + 1) * 0.5) * overlayBounds.width,
    y: ((1 - projected.y) * 0.5) * overlayBounds.height,
  };
}

function chainLegendPath(start: ScreenPoint, points: ScreenPoint[]): ScreenPoint[] {
  if (points.length === 0) return [];

  const remaining = [...points];
  const ordered: ScreenPoint[] = [];
  let cursor = start;

  while (remaining.length > 0) {
    let closestIndex = 0;
    let closestDistance = Number.POSITIVE_INFINITY;
    for (let index = 0; index < remaining.length; index += 1) {
      const dx = remaining[index].x - cursor.x;
      const dy = remaining[index].y - cursor.y;
      const distance = Math.hypot(dx, dy);
      if (distance < closestDistance) {
        closestDistance = distance;
        closestIndex = index;
      }
    }
    const [nextPoint] = remaining.splice(closestIndex, 1);
    ordered.push(nextPoint);
    cursor = nextPoint;
  }

  return ordered;
}

function isExteriorMarkerVisible(annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation): boolean {
  return annotation.kind === "Power" || annotation.kind === "Shield" || annotation.kind === "Quantum" || annotation.kind === "Cooler";
}

function getTraceStateForAnnotation(
  annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation,
): DeckMarkerTraceState | null {
  const matchingLegendItem = DECK_MARKER_LEGEND.flatMap((section) => section.items).find((item) => item.annotationIds.includes(annotation.id));
  if (!matchingLegendItem) return null;

  return {
    key: `marker:${annotation.id}`,
    annotationIds: matchingLegendItem.annotationIds,
    color: matchingLegendItem.color,
    startAnnotationId: annotation.id,
  };
}

function getLegendItemForAnnotation(
  annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation,
): DeckMarkerLegendItem | null {
  return DECK_MARKER_LEGEND.flatMap((section) => section.items).find((item) => item.annotationIds.includes(annotation.id)) ?? null;
}

function getAnnotationWorldPosition(
  annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation,
  annotations?: ShipMapDeckAnnotationConfig,
): [number, number, number] {
  const offset = annotations?.worldOffset ?? [0, 0, 0];
  return [
    annotation.worldPosition[0] + offset[0],
    annotation.worldPosition[1] + offset[1],
    annotation.worldPosition[2] + offset[2],
  ];
}

function getVisibleLegendSections(
  deck: ShipMapDeckOverlay | null,
  showInterior: boolean,
): DeckMarkerLegendSection[] {
  const exteriorKeys = new Set<LegendItemKey>(["power", "shield", "quantum", "cooler"]);
  if (!showInterior) {
    return DECK_MARKER_LEGEND.map((section) => ({
      ...section,
      items: section.items.filter((item) => exteriorKeys.has(item.key)),
    })).filter((section) => section.items.length > 0);
  }

  const annotationIds = new Set<string>();
  deck?.annotations?.components.forEach((annotation) => annotationIds.add(annotation.id));
  deck?.annotations?.labels.forEach((annotation) => annotationIds.add(annotation.id));

  return DECK_MARKER_LEGEND.map((section) => ({
    ...section,
    items: section.items.filter((item) => item.annotationIds.some((id) => annotationIds.has(id))),
  })).filter((section) => section.items.length > 0);
}

function getDefaultDeckOverlayId(deckOverlayConfig?: ShipMapDeckOverlayConfig): string {
  if (!deckOverlayConfig?.decks.length) return "";
  return deckOverlayConfig.decks.find((deck) => deck.id.toLowerCase().includes("mid"))?.id ?? deckOverlayConfig.decks[0].id;
}

function DeckAnnotations({
  deck,
  showExteriorSubsetOnly = false,
  activeTraceAnnotationIds,
  visibleAnnotationIds,
  onAnnotationHover,
  onAnnotationLeave,
  onAnnotationClick,
}: {
  deck: ShipMapDeckOverlay;
  showExteriorSubsetOnly?: boolean;
  activeTraceAnnotationIds?: readonly string[];
  visibleAnnotationIds?: readonly string[];
  onAnnotationHover?: (annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation) => void;
  onAnnotationLeave?: () => void;
  onAnnotationClick?: (annotation: ShipMapDeckComponentAnnotation | ShipMapDeckLabelAnnotation) => void;
}) {
  if (!deck.annotations) return null;

  const baseY = deck.deckMin;
  const stemHeight = Math.max(deck.annotations.fixedHeightAboveDeckMin, 0.02);
  const chipHeight = 0.012;
  const chipRadius = Math.max(Math.min((deck.deckMax - deck.deckMin) * 0.06, 0.026), 0.014);
  const visibleIdSet = visibleAnnotationIds ? new Set(visibleAnnotationIds) : null;
  const items = [...deck.annotations.components, ...deck.annotations.labels].filter((annotation) =>
    showExteriorSubsetOnly ? isExteriorMarkerVisible(annotation) : visibleIdSet ? visibleIdSet.has(annotation.id) : true,
  );

  return (
    <>
      {items.map((annotation) => {
        const [worldX, , worldZ] = getAnnotationWorldPosition(annotation, deck.annotations);
        const MarkerIcon = resolveDeckMarkerIcon(annotation);
        const isTraceActive = activeTraceAnnotationIds?.includes(annotation.id) ?? false;
        const showIconBadge = Boolean(MarkerIcon) && (!showExteriorSubsetOnly || isTraceActive);
        const markerColor = isTraceActive ? "#f8fafc" : annotation.colorHint ?? "#93c5fd";
        const markerOpacity = isTraceActive ? 1 : 0.96;
        const badgeText = getAnnotationBadgeText(annotation);
        const handleAnnotationSelect = () => onAnnotationClick?.(annotation);

        return (
          <group
            key={annotation.id}
            position={[worldX, baseY, worldZ]}
            onPointerEnter={() => onAnnotationHover?.(annotation)}
            onPointerLeave={() => onAnnotationLeave?.()}
            onClick={(event) => {
              event.stopPropagation();
              handleAnnotationSelect();
            }}
          >
            <mesh position={[0, stemHeight * 0.5, 0]} renderOrder={70}>
              <cylinderGeometry args={[0.0018, 0.0018, stemHeight, 10]} />
              <meshBasicMaterial color={markerColor} transparent opacity={isTraceActive ? 0.98 : 0.82} depthTest={false} depthWrite={false} />
            </mesh>
            <mesh position={[0, stemHeight + chipHeight * 0.5, 0]} rotation={[-Math.PI / 2, 0, 0]} renderOrder={71}>
              <circleGeometry args={[chipRadius, 18]} />
              <meshBasicMaterial color={markerColor} transparent opacity={markerOpacity} depthTest={false} depthWrite={false} />
            </mesh>
            <Billboard position={[0, stemHeight + chipHeight + 0.012, 0]} follow lockX={false} lockY={false} lockZ={false}>
              {MarkerIcon && showIconBadge ? (
                <Html center>
                  <div
                    className={`deck-marker-icon-badge ${isTraceActive ? "deck-marker-icon-badge-active" : ""}`}
                    style={{ "--marker-accent": markerColor } as React.CSSProperties}
                    onClick={(event) => {
                      event.stopPropagation();
                      handleAnnotationSelect();
                    }}
                  >
                    <MarkerIcon className="deck-marker-icon-svg" />
                  </div>
                </Html>
              ) : (
                <Text
                  fontSize={chipRadius * 0.7}
                  maxWidth={chipRadius * 4.8}
                  anchorX="center"
                  anchorY="middle"
                  color={isTraceActive ? "#f8fafc" : markerColor}
                  fillOpacity={isTraceActive ? 0.98 : 0.92}
                  outlineWidth={0.0022}
                  outlineColor="#02040a"
                >
                  {badgeText}
                </Text>
              )}
            </Billboard>
          </group>
        );
      })}
    </>
  );
}

export default function ShipMapTemplate({
  title,
  subtitle,
  modelPath,
  viewStorageKey,
  fallbackView,
  defaultDeckOverlayId,
  defaultInteriorEnabled = false,
  showDebugPanel = false,
  showHeader = true,
  immersiveFocus = false,
  deckOverlayConfig,
  mergeMeshesForPerformance = false,
  modelTransform,
}: ShipMapTemplateProps) {
  const hasDeckOverlay = Boolean(deckOverlayConfig?.decks.length);
  const initialInteriorEnabled = defaultInteriorEnabled && hasDeckOverlay;
  const initialView = useMemo(() => readSavedView(viewStorageKey, fallbackView), [viewStorageKey, fallbackView]);
  const [modelScene, setModelScene] = useState<Object3D | null>(null);
  const [modelBounds, setModelBounds] = useState<Box3 | null>(null);
  const [modelSource, setModelSource] = useState<ModelSource | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<ShipMapViewState>(initialView);
  const [activeLegendSectionKey, setActiveLegendSectionKey] = useState<LegendSectionKey | null>("ship-components");
  const [hoveredLegendKey, setHoveredLegendKey] = useState<LegendItemKey | null>(null);
  const [hoveredMarkerTrace, setHoveredMarkerTrace] = useState<DeckMarkerTraceState | null>(null);
  const [legendPaths, setLegendPaths] = useState<ScreenPath[]>([]);
  const [suggestedScale, setSuggestedScale] = useState<number | null>(null);
  const [sliceEnabled, setSliceEnabled] = useState(initialInteriorEnabled);
  const [deckBounds, setDeckBounds] = useState<{ min: number; max: number }>({ min: -1, max: 1 });
  const [deckOverlayEnabled, setDeckOverlayEnabled] = useState(initialInteriorEnabled);
  /** True while interior↔exterior blend is running (keeps slice/ghost mounted without per-frame React state). */
  const [interiorAnimating, setInteriorAnimating] = useState(false);
  const [activeDeckOverlayId, setActiveDeckOverlayId] = useState(
    defaultDeckOverlayId ?? getDefaultDeckOverlayId(deckOverlayConfig),
  );
  const [interiorAssetsReady, setInteriorAssetsReady] = useState(!initialInteriorEnabled);
  const [bootOverlayVisible, setBootOverlayVisible] = useState(initialInteriorEnabled);
  const [modelFootprint, setModelFootprint] = useState<{ x: number; z: number }>({ x: 1, z: 1 });
  const [deckOverlayRegions, setDeckOverlayRegions] = useState<DeckOverlayRegion[]>([]);
  const [deckOverlayViewBox, setDeckOverlayViewBox] = useState<string | null>(null);
  const [selectedRegionKey, setSelectedRegionKey] = useState<string | null>(null);
  const [hoveredRegionKey, setHoveredRegionKey] = useState<string | null>(null);
  const [deckMenuOpen, setDeckMenuOpen] = useState(false);
  const [mobileLegendOpen, setMobileLegendOpen] = useState(false);
  const controlsRef = useRef<OrbitControlsImpl | null>(null);
  const cameraRef = useRef<PerspectiveCamera | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const viewerShellRef = useRef<HTMLDivElement | null>(null);
  const legendItemRefs = useRef<Record<string, HTMLElement | null>>({});
  const deckOverlayVisualProgressRef = useRef(initialInteriorEnabled ? 1 : 0);
  const prevDeckOverlayEnabledRef = useRef<boolean | undefined>(initialInteriorEnabled);
  const bootStartTimeRef = useRef(initialInteriorEnabled ? performance.now() : 0);
  const controlsFrameRef = useRef<number | null>(null);
  const pickRayRef = useRef(new Raycaster());
  const pickPointerRef = useRef(new Vector2());

  const activeDeckOverlay = useMemo(
    () => deckOverlayConfig?.decks.find((deck) => deck.id === activeDeckOverlayId) ?? null,
    [deckOverlayConfig, activeDeckOverlayId],
  );
  const exteriorDeckOverlay = useMemo<ShipMapDeckOverlay | null>(() => {
    if (!deckOverlayConfig?.decks.length) return null;
    const sourceDecks = deckOverlayConfig.decks.filter((deck) => deck.annotations);
    if (sourceDecks.length === 0) return null;

    const components = sourceDecks.flatMap((deck) => deck.annotations?.components ?? []).filter(isExteriorMarkerVisible);
    const labels = sourceDecks.flatMap((deck) => deck.annotations?.labels ?? []).filter(isExteriorMarkerVisible);
    const baseDeck =
      deckOverlayConfig.decks.find((deck) => deck.id.toLowerCase().includes("mid") && deck.annotations) ??
      activeDeckOverlay ??
      sourceDecks[0];
    return {
      ...baseDeck,
      annotations: {
        fixedHeightAboveDeckMin: sourceDecks[0].annotations?.fixedHeightAboveDeckMin ?? 0.02,
        worldOffset: sourceDecks[0].annotations?.worldOffset,
        components,
        labels,
      },
    };
  }, [activeDeckOverlay, deckOverlayConfig]);
  const interactiveDeckOverlay = deckOverlayEnabled ? activeDeckOverlay : exteriorDeckOverlay;
  const activeLegendKey = hoveredLegendKey;
  const activeLegendItem = useMemo(
    () => DECK_MARKER_LEGEND.flatMap((section) => section.items).find((item) => item.key === activeLegendKey) ?? null,
    [activeLegendKey],
  );
  const activeTrace = useMemo<DeckMarkerTraceState | null>(() => {
    if (hoveredMarkerTrace) return hoveredMarkerTrace;
    if (hoveredLegendKey && activeLegendItem) {
      return {
        key: `legend:${hoveredLegendKey}`,
        annotationIds: activeLegendItem.annotationIds,
        color: activeLegendItem.color,
      };
    }
    return null;
  }, [activeLegendItem, hoveredLegendKey, hoveredMarkerTrace]);
  const effectiveModelTransform = useMemo(
    () => resolveModelTransform(modelTransform, suggestedScale ?? 1),
    [modelTransform, suggestedScale],
  );
  const activeRegionKey = hoveredRegionKey ?? selectedRegionKey;
  const activeDeckRegion = useMemo(
    () => deckOverlayRegions.find((region) => region.key === activeRegionKey) ?? null,
    [deckOverlayRegions, activeRegionKey],
  );
  const deckOverlayOptions = useMemo(() => {
    if (!deckOverlayConfig) return [];

    const options: Array<{ id: string; label: string }> = [];
    const topDeck = deckOverlayConfig.decks.at(-1);
    const midDeck = deckOverlayConfig.decks.length > 2 ? deckOverlayConfig.decks[1] : null;
    const lowerDeck = deckOverlayConfig.decks[0] ?? null;

    if (topDeck) options.push({ id: topDeck.id, label: "Top Deck" });
    if (midDeck) options.push({ id: midDeck.id, label: "Mid Deck" });
    if (lowerDeck) options.push({ id: lowerDeck.id, label: "Lower Deck" });

    return options;
  }, [deckOverlayConfig]);
  const activeDeckRegionHighlightUri = useMemo(() => {
    if (!activeDeckRegion) return null;
    const fallbackViewBox = activeDeckOverlay
      ? `0 0 ${activeDeckOverlay.viewBox[0]} ${activeDeckOverlay.viewBox[1]}`
      : null;
    const viewBox = deckOverlayViewBox ?? fallbackViewBox;
    if (!viewBox) return null;
    return buildHighlightTextureDataUri(viewBox, activeDeckRegion.highlightMarkup);
  }, [activeDeckRegion, deckOverlayViewBox, activeDeckOverlay]);
  const activeDeckShadowTextureUri = useMemo(() => buildDeckShadowTextureDataUri(), []);
  const deckOverlayVisualActive = deckOverlayEnabled || interiorAnimating;
  const showInteriorBootOverlay = initialInteriorEnabled && !loadError && bootOverlayVisible;
  const viewerBackdropStyle = useMemo(
    () =>
      ({
        "--ship-x": "50%",
        "--ship-y": "48%",
      }) as React.CSSProperties,
    [],
  );
  const activeDeckCutY = useMemo(() => {
    if ((!sliceEnabled && !deckOverlayVisualActive) || !activeDeckOverlay) return null;
    return Math.min(deckBounds.max, activeDeckOverlay.deckMin + 0.02);
  }, [sliceEnabled, deckOverlayVisualActive, activeDeckOverlay, deckBounds.max]);
  const activeAnnotationIds = useMemo(() => {
    const ids = new Set<string>();
    activeTrace?.annotationIds.forEach((id) => ids.add(id));
    return [...ids];
  }, [activeTrace]);
  const visibleLegendSections = useMemo(
    () => getVisibleLegendSections(interactiveDeckOverlay, deckOverlayEnabled),
    [interactiveDeckOverlay, deckOverlayEnabled],
  );
  const activeLegendSection = useMemo(
    () => visibleLegendSections.find((section) => section.key === activeLegendSectionKey) ?? null,
    [activeLegendSectionKey, visibleLegendSections],
  );
  const visibleLegendItems = useMemo(() => activeLegendSection?.items ?? [], [activeLegendSection]);
  const visibleAnnotationIds = useMemo(
    () => [...new Set(visibleLegendItems.flatMap((item) => item.annotationIds))],
    [visibleLegendItems],
  );
  const mobileLegendPreviewItems = useMemo(() => {
    const items = visibleLegendItems;
    const radarItem = items.find((item) => item.Icon === RadarIcon);
    const nonRadarItems = items.filter((item) => item.key !== radarItem?.key);

    if (radarItem) {
      return [...nonRadarItems.slice(0, 2), radarItem];
    }

    return items.slice(0, 3);
  }, [visibleLegendItems]);
  const lowerHullClippingPlanes = useMemo(() => {
    if (activeDeckCutY === null) return [];
    return [new Plane(new Vector3(0, -1, 0), activeDeckCutY)];
  }, [activeDeckCutY]);
  const lowerHullGhostScene = useMemo(() => {
    if (!modelScene) return null;
    return cloneModelSceneForPass(modelScene);
  }, [modelScene]);

  useEffect(() => {
    if (!deckOverlayConfig?.decks.length) return;

    const texturePaths = new Set<string>([activeDeckShadowTextureUri]);
    for (const deck of deckOverlayConfig.decks) {
      if (deck.svgPath) {
        texturePaths.add(deck.svgPath);
      }
    }

    let cancelled = false;

    Promise.all([...texturePaths].map((texturePath) => loadOverlayTexture(texturePath)))
      .then(() => {
        if (cancelled) return;
        setInteriorAssetsReady(true);
      })
      .catch(() => {
        if (cancelled) return;
        setInteriorAssetsReady(true);
      });

    return () => {
      cancelled = true;
    };
  }, [activeDeckShadowTextureUri, deckOverlayConfig]);

  useEffect(() => {
    if (!initialInteriorEnabled) return;
    if (loadError) {
      setBootOverlayVisible(false);
      return;
    }
    if (!modelScene || !interiorAssetsReady) return;

    let cancelled = false;
    let firstFrame: number | null = null;
    let secondFrame: number | null = null;
    let timeoutId: number | null = null;
    const elapsed = performance.now() - bootStartTimeRef.current;
    const remaining = Math.max(0, INTERIOR_BOOT_MIN_MS - elapsed);

    const reveal = () => {
      if (cancelled) return;
      setBootOverlayVisible(false);
    };

    const queueReveal = () => {
      firstFrame = window.requestAnimationFrame(() => {
        secondFrame = window.requestAnimationFrame(reveal);
      });
    };

    if (remaining > 0) {
      timeoutId = window.setTimeout(queueReveal, remaining);
    } else {
      queueReveal();
    }

    return () => {
      cancelled = true;
      if (timeoutId !== null) window.clearTimeout(timeoutId);
      if (firstFrame !== null) window.cancelAnimationFrame(firstFrame);
      if (secondFrame !== null) window.cancelAnimationFrame(secondFrame);
    };
  }, [initialInteriorEnabled, interiorAssetsReady, loadError, modelScene]);

  useEffect(() => {
    if (!deckOverlayConfig?.decks.length) return;
    if (deckOverlayConfig.decks.some((deck) => deck.id === activeDeckOverlayId)) return;
    setActiveDeckOverlayId(defaultDeckOverlayId ?? getDefaultDeckOverlayId(deckOverlayConfig));
  }, [activeDeckOverlayId, deckOverlayConfig, defaultDeckOverlayId]);

  useEffect(() => {
    if (!hasDeckOverlay) {
      setDeckMenuOpen(false);
      setMobileLegendOpen(false);
    }
  }, [hasDeckOverlay]);

  useEffect(() => {
    setHoveredLegendKey(null);
    setHoveredMarkerTrace(null);
  }, [activeLegendSectionKey]);

  useEffect(() => {
    if (!interactiveDeckOverlay?.annotations) {
      setLegendPaths([]);
      return;
    }

    const viewerShell = viewerShellRef.current;
    const camera = cameraRef.current;
    if (!viewerShell || !camera) {
      setLegendPaths([]);
      return;
    }

    const overlayBounds = viewerShell.getBoundingClientRect();
    const y = interactiveDeckOverlay.deckMin + Math.max(interactiveDeckOverlay.annotations.fixedHeightAboveDeckMin, 0.02) + 0.012;
    const allAnnotations = [...interactiveDeckOverlay.annotations.components, ...interactiveDeckOverlay.annotations.labels];

    if (!activeTrace) {
      setLegendPaths([]);
      return;
    }

    const matchingAnnotations = allAnnotations.filter((annotation) => activeTrace.annotationIds.includes(annotation.id));

    const projectedById = new Map<string, ScreenPoint>();
    for (const annotation of matchingAnnotations) {
      const [worldX, , worldZ] = getAnnotationWorldPosition(annotation, interactiveDeckOverlay.annotations);
      const projected = projectWorldPointToOverlay(
        new Vector3(worldX, y, worldZ),
        camera,
        overlayBounds,
      );
      if (projected) {
        projectedById.set(annotation.id, projected);
      }
    }

    if (projectedById.size === 0) {
      setLegendPaths([]);
      return;
    }

    let startPoint: ScreenPoint | null = null;
    const startAnnotationId = activeTrace.startAnnotationId;
    if (startAnnotationId) {
      startPoint = projectedById.get(startAnnotationId) ?? null;
    } else {
      const legendElement = legendItemRefs.current[activeLegendKey ?? ""];
      if (legendElement) {
        const legendBounds = legendElement.getBoundingClientRect();
        startPoint = {
          x: legendBounds.right - overlayBounds.left,
          y: legendBounds.top - overlayBounds.top + legendBounds.height * 0.5,
        };
      }
    }

    if (!startPoint) {
      setLegendPaths([]);
      return;
    }

    const chainedPoints = matchingAnnotations
      .filter((annotation) => annotation.id !== startAnnotationId)
      .map((annotation) => projectedById.get(annotation.id) ?? null)
      .filter((point): point is ScreenPoint => point !== null);

    setLegendPaths([{ points: [startPoint, ...chainLegendPath(startPoint, chainedPoints)], color: activeTrace.color }]);
  }, [interactiveDeckOverlay, activeLegendKey, activeTrace, currentView]);

  function handleControlsChange() {
    if (controlsFrameRef.current !== null) return;
    controlsFrameRef.current = window.requestAnimationFrame(() => {
      controlsFrameRef.current = null;
      const controls = controlsRef.current;
      if (!controls) return;
      const camera = controls.object;
      if (deckOverlayEnabled && camera.position.y < INTERIOR_CAMERA_MIN_Y) {
        camera.position.y = INTERIOR_CAMERA_MIN_Y;
        controls.update();
      }
      setCurrentView({
        position: [round3(camera.position.x), round3(camera.position.y), round3(camera.position.z)],
        target: [round3(controls.target.x), round3(controls.target.y), round3(controls.target.z)],
      });
    });
  }

  function handleViewportPick(event: React.MouseEvent<HTMLDivElement>) {
    const canvas = canvasRef.current;
    const camera = cameraRef.current;
    if (!canvas || !camera) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    pickPointerRef.current.set(x, y);
    pickRayRef.current.setFromCamera(pickPointerRef.current, camera);

    const planeY = activeDeckOverlay?.deckMin ?? controlsRef.current?.target.y ?? 0;
    const pickingPlane = new Plane(new Vector3(0, 1, 0), -planeY);
    const hitPoint = new Vector3();

    if (!pickRayRef.current.ray.intersectPlane(pickingPlane, hitPoint)) return;

  }

  useEffect(() => {
    let cancelled = false;
    let acquiredAsset = false;

    setLoadError(null);
    setModelScene(null);
    setModelBounds(null);
    setModelSource(resolveModelSource(modelPath));
    setSuggestedScale(null);

    async function loadModel() {
      try {
        const asset = await acquireModelAsset(modelPath);
        acquiredAsset = true;
        if (cancelled) {
          releaseModelAsset(modelPath);
          return;
        }

        const sceneInstance = createModelSceneInstance(asset, mergeMeshesForPerformance);
        setModelScene(sceneInstance);
        setModelBounds(asset.baseBounds.clone());
        setModelSource(asset.source);
        setSuggestedScale(asset.suggestedScale);
      } catch (error) {
        if (cancelled) return;
        const message = error instanceof Error ? error.message : "Unknown model parsing error";
        setLoadError(message);
      }
    }

    void loadModel();

    return () => {
      cancelled = true;
      if (acquiredAsset) {
        releaseModelAsset(modelPath);
      }
    };
  }, [modelPath, mergeMeshesForPerformance]);

  useEffect(() => {
    if (!modelScene || !modelBounds) return;

    const transformedBounds = computeBoundsWithTransform(modelBounds, effectiveModelTransform);
    const size = new Vector3();
    transformedBounds.getSize(size);

    setDeckBounds({ min: transformedBounds.min.y, max: transformedBounds.max.y });
    setModelFootprint({ x: Math.max(size.x, 0.1), z: Math.max(size.z, 0.1) });
  }, [modelScene, modelBounds, effectiveModelTransform]);

  useEffect(() => {
    return () => {
      if (!modelScene) return;
      disposeModelSceneInstance(modelScene);
    };
  }, [modelScene]);

  useEffect(() => {
    return () => {
      if (!lowerHullGhostScene) return;
      disposeModelSceneInstance(lowerHullGhostScene);
    };
  }, [lowerHullGhostScene]);

  useEffect(() => {
    return () => {
      if (controlsFrameRef.current !== null) {
        window.cancelAnimationFrame(controlsFrameRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (!hasDeckOverlay || !activeDeckOverlay) return;

    if (!deckOverlayEnabled) {
      setSliceEnabled(false);
      return;
    }

    setSliceEnabled(true);
  }, [hasDeckOverlay, activeDeckOverlay, deckOverlayEnabled, deckBounds.min, deckBounds.max]);

  useEffect(() => {
    if (!hasDeckOverlay) {
      deckOverlayVisualProgressRef.current = 0;
      setInteriorAnimating(false);
    }
  }, [hasDeckOverlay]);

  useEffect(() => {
    if (prevDeckOverlayEnabledRef.current === undefined) {
      prevDeckOverlayEnabledRef.current = deckOverlayEnabled;
      return;
    }
    if (prevDeckOverlayEnabledRef.current !== deckOverlayEnabled) {
      prevDeckOverlayEnabledRef.current = deckOverlayEnabled;
      setInteriorAnimating(true);
    }
  }, [deckOverlayEnabled]);

  useEffect(() => {
    let cancelled = false;

    setDeckOverlayRegions([]);
    setDeckOverlayViewBox(null);
    setSelectedRegionKey(null);
    setHoveredRegionKey(null);

    if (!activeDeckOverlay || !activeDeckOverlay.svgPath) return;
    const overlay = activeDeckOverlay;
    const overlayPath = overlay.svgPath!;

    async function loadDeckRegions() {
      try {
        const response = await fetch(overlayPath);
        if (!response.ok) {
          throw new Error(`SVG request failed: ${response.status}`);
        }
        const svgText = await response.text();
        if (cancelled) return;
        const parsed = parseDeckOverlayRegions(svgText);
        setDeckOverlayRegions(parsed.regions);
        setDeckOverlayViewBox(parsed.sourceViewBox);
      } catch {
        if (cancelled) return;
      }
    }

    void loadDeckRegions();

    return () => {
      cancelled = true;
    };
  }, [activeDeckOverlay]);

  const roundShell = immersiveFocus ? "rounded-none" : "rounded-[1.2rem]";

  return (
    <section
      className={
        immersiveFocus
          ? "route-fade flex h-full min-h-0 flex-1 flex-col pb-0 pt-0"
          : "route-fade pb-8 pt-2"
      }
    >
      <div
        className={
          immersiveFocus
            ? "mx-auto flex w-full max-w-none flex-1 min-h-0 flex-col"
            : "mx-auto w-full max-w-none space-y-6"
        }
      >
        {showHeader ? (
          <article className="base-card base-card--maps p-4 sm:p-6">
            <header className="base-card-head p-5">
              <p className="base-card-kicker">Ship Maps</p>
              <h1 className="title-font mt-2 text-4xl tracking-[0.07em] text-amber-200 sm:text-5xl">{title}</h1>
              <p className="mt-4 max-w-3xl text-base leading-relaxed text-slate-200 sm:text-lg">{subtitle}</p>
            </header>
          </article>
        ) : null}

        <article
          className={
            immersiveFocus
              ? "base-card base-card--maps flex min-h-0 flex-1 flex-col overflow-hidden border-0 p-0 sm:rounded-none"
              : "base-card base-card--maps overflow-hidden p-2 sm:p-3"
          }
        >
          <div
            ref={viewerShellRef}
            className={
              immersiveFocus
                ? "ship-viewer-shell ship-viewer-shell--immersive relative flex min-h-0 w-full flex-1 flex-col overflow-hidden border-0 sm:min-h-0"
                : "ship-viewer-shell relative h-[min(72vh,85dvh)] min-h-[min(360px,52dvh)] w-full sm:min-h-[480px] lg:min-h-[620px] rounded-[1.2rem] border border-white/15"
            }
            style={viewerBackdropStyle}
          >
            <div className={`ship-viewer-bg ${roundShell}`} />
            <div className={`ship-viewer-grid ${roundShell}`} />
            <div className={`ship-backlight ${roundShell}`} />
            {showInteriorBootOverlay ? (
              <div className="ship-viewer-boot-overlay">
                <div className="ship-viewer-boot-panel">
                  <span className="ship-viewer-boot-spinner" aria-hidden="true" />
                  <p className="ship-viewer-boot-kicker">Initializing Viewer</p>
                  <p className="ship-viewer-boot-copy">Loading Perseus mid-deck interior.</p>
                </div>
              </div>
            ) : null}
            <div
              className={`map-deck-viewport relative h-full w-full min-h-0 flex-1 overflow-hidden ${roundShell}`}
              onClick={handleViewportPick}
            >
              <Canvas
              className={immersiveFocus ? "h-full min-h-0 w-full min-w-0" : undefined}
              dpr={[1, 1.25]}
              gl={{ localClippingEnabled: true, preserveDrawingBuffer: true }}
              camera={{ position: initialView.position, fov: 42 }}
              onCreated={({ gl, camera, scene }) => {
                gl.localClippingEnabled = true;
                gl.outputColorSpace = SRGBColorSpace;
                gl.toneMapping = ACESFilmicToneMapping;
                gl.toneMappingExposure = SHIP_VIEWER_TONE_EXPOSURE;
                scene.background = new Color(SHIP_VIEWER_SCENE_BG);
                scene.fog = new FogExp2(SHIP_VIEWER_SCENE_BG, SHIP_VIEWER_FOG_DENSITY);
                canvasRef.current = gl.domElement;
                cameraRef.current = camera as PerspectiveCamera;
              }}
            >
              <InteriorTransitionDriver
                progressRef={deckOverlayVisualProgressRef}
                interiorTarget={deckOverlayEnabled}
                onSettled={() => setInteriorAnimating(false)}
              />
              <RenderInvalidateOnChange
                active={!showInteriorBootOverlay && Boolean(interactiveDeckOverlay && modelScene)}
                depsKey={[
                  activeDeckOverlayId,
                  deckOverlayEnabled ? "interior" : "exterior",
                  interactiveDeckOverlay?.annotations?.components.length ?? 0,
                  interactiveDeckOverlay?.annotations?.labels.length ?? 0,
                ].join(":")}
              />
              <hemisphereLight intensity={0.42} color="#9eb0c8" groundColor="#0a0c12" />
              <ambientLight intensity={0.2} color="#cbd5e1" />
              <directionalLight position={[14, 22, 16]} intensity={1.32} color="#f2ede4" />
              <directionalLight position={[-10, 6, -8]} intensity={0.4} color="#8fa3c4" />
              <directionalLight position={[-18, 12, -24]} intensity={0.88} color="#7dd3fc" />
              {modelScene ? (
                <>
                  <FitModelMesh
                    modelScene={modelScene}
                    transform={effectiveModelTransform}
                    opacityRef={deckOverlayVisualProgressRef}
                    invertProgress
                  />
                  {lowerHullGhostScene ? (
                    <FitModelMesh
                      modelScene={lowerHullGhostScene}
                      transform={effectiveModelTransform}
                      clippingPlanes={lowerHullClippingPlanes}
                      opacityRef={deckOverlayVisualProgressRef}
                      opacityScale={0.14}
                      ghosted
                      renderOrder={4}
                    />
                  ) : null}
                </>
              ) : null}
              {deckOverlayVisualActive && activeDeckOverlay && modelScene ? (
                <DeckOverlayPlane
                  deck={{
                    ...activeDeckOverlay,
                    scaleMultiplier: (activeDeckOverlay.scaleMultiplier ?? 1) * 1.08,
                  }}
                  modelSize={modelFootprint}
                  texturePath={activeDeckShadowTextureUri}
                  progressRef={deckOverlayVisualProgressRef}
                  opacityScale={0.3}
                  renderOrder={40}
                  yOffset={-0.01}
                />
              ) : null}
              {deckOverlayVisualActive && activeDeckOverlay?.svgPath && modelScene ? (
                <DeckOverlayPlane
                  deck={activeDeckOverlay}
                  modelSize={modelFootprint}
                  texturePath={activeDeckOverlay.svgPath}
                  progressRef={deckOverlayVisualProgressRef}
                  opacityScale={0.95}
                  renderOrder={41}
                />
              ) : null}
              {interactiveDeckOverlay && modelScene ? (
                <DeckAnnotations
                  deck={interactiveDeckOverlay}
                  showExteriorSubsetOnly={!deckOverlayEnabled}
                  activeTraceAnnotationIds={activeAnnotationIds}
                  visibleAnnotationIds={deckOverlayEnabled ? visibleAnnotationIds : undefined}
                  onAnnotationHover={(annotation) => {
                    if (!deckOverlayEnabled) return;
                    setHoveredMarkerTrace(getTraceStateForAnnotation(annotation));
                  }}
                  onAnnotationLeave={() => {
                    if (!deckOverlayEnabled) return;
                    setHoveredMarkerTrace(null);
                  }}
                  onAnnotationClick={(annotation) => {
                    if (!deckOverlayEnabled) return;
                    const matchingLegendItem = getLegendItemForAnnotation(annotation);
                    setHoveredLegendKey(null);
                    setHoveredMarkerTrace(null);
                    if (matchingLegendItem) {
                      const parentSection = DECK_MARKER_LEGEND.find((section) =>
                        section.items.some((item) => item.key === matchingLegendItem.key),
                      );
                      setActiveLegendSectionKey(parentSection?.key ?? "ship-components");
                      setHoveredLegendKey(matchingLegendItem.key);
                      return;
                    }
                  }}
                />
              ) : null}
              {deckOverlayVisualActive && activeDeckOverlay && activeDeckRegionHighlightUri && modelScene ? (
                <DeckOverlayPlane
                  deck={activeDeckOverlay}
                  modelSize={modelFootprint}
                  texturePath={activeDeckRegionHighlightUri}
                  progressRef={deckOverlayVisualProgressRef}
                  opacityScale={0.98}
                  renderOrder={42}
                  yOffset={0.0035}
                />
              ) : null}
              <OrbitControls
                ref={controlsRef}
                enableDamping
                dampingFactor={0.08}
                minDistance={0}
                maxDistance={20}
                target={initialView.target}
                onChange={handleControlsChange}
              />
              </Canvas>
            </div>

            {legendPaths.some((path) => path.points.length > 1) ? (
              <svg
                className="map-legend-path-overlay absolute inset-0 z-10"
                viewBox={`0 0 ${Math.max(viewerShellRef.current?.clientWidth ?? 0, 1)} ${Math.max(viewerShellRef.current?.clientHeight ?? 0, 1)}`}
                preserveAspectRatio="none"
                aria-hidden
              >
                {legendPaths.map((path, pathIndex) => (
                  <g key={`${path.color}-${pathIndex}`} style={{ "--legend-path-accent": path.color } as React.CSSProperties}>
                    <polyline
                      points={path.points.map((point) => `${point.x},${point.y}`).join(" ")}
                      className="map-legend-path-line"
                    />
                    {path.points.slice(1).map((point, index) => (
                      <g key={`${point.x}-${point.y}-${index}`}>
                        <circle cx={point.x} cy={point.y} r="9.5" className="map-legend-path-hit-core" />
                        <circle cx={point.x} cy={point.y} r="12.5" className="map-legend-path-hit-ring" />
                      </g>
                    ))}
                  </g>
                ))}
              </svg>
            ) : null}

            {showDebugPanel ? (
              <aside className="map-debug-panel">
                <p className="map-debug-kicker">Viewer Debug</p>
                <div className="map-debug-block">
                  <p className="map-debug-label">Position</p>
                  <code className="map-debug-value">
                    [{currentView.position.map((value) => value.toFixed(3)).join(", ")}]
                  </code>
                </div>
                <div className="map-debug-block">
                  <p className="map-debug-label">Target</p>
                  <code className="map-debug-value">
                    [{currentView.target.map((value) => value.toFixed(3)).join(", ")}]
                  </code>
                </div>
                <div className="map-debug-block">
                  <p className="map-debug-label">Deck</p>
                  <code className="map-debug-value">{activeDeckOverlayId || "none"}</code>
                </div>
              </aside>
            ) : null}

            <div
              className={
                immersiveFocus
                  ? "map-mobile-overlay-cluster absolute left-4 z-10 flex max-w-[calc(100%-2rem)] flex-col gap-2"
                  : "map-mobile-overlay-cluster absolute left-4 top-4 z-10 flex max-w-[calc(100%-2rem)] flex-col gap-2"
              }
            >
              {hasDeckOverlay ? (
                <div className="map-mobile-overlay-actions">
                  <button
                    type="button"
                    onClick={() => setDeckOverlayEnabled((enabled) => !enabled)}
                    className={`rounded-md border border-white/35 bg-black/50 px-3 py-1.5 text-xs uppercase tracking-[0.14em] text-white transition hover:bg-black/65 sm:min-h-12 sm:px-4 sm:py-2 sm:text-sm ${
                      deckOverlayEnabled ? "map-selection-active" : ""
                    }`}
                    aria-label="Toggle interior exterior view"
                  >
                    <span className="sm:hidden">{deckOverlayEnabled ? "Ext." : "Int."}</span>
                    <span className="hidden sm:inline">{deckOverlayEnabled ? "Exterior" : "Interior"}</span>
                  </button>

                  {deckOverlayEnabled && deckOverlayOptions.length > 0 ? (
                    <div className="map-deck-picker">
                      <button
                        type="button"
                        onClick={() => setDeckMenuOpen((open) => !open)}
                        className={`map-deck-picker-trigger ${deckMenuOpen ? "map-selection-active" : ""}`}
                        aria-expanded={deckMenuOpen}
                        aria-controls="map-deck-picker-menu"
                        aria-label="Toggle deck layers"
                      >
                        <svg viewBox="0 0 24 24" className="map-deck-picker-icon" aria-hidden="true">
                          <path d="M12 4 4 8l8 4 8-4-8-4Z" />
                          <path d="m4 12 8 4 8-4" />
                          <path d="m4 16 8 4 8-4" />
                        </svg>
                      </button>

                      {deckMenuOpen ? (
                        <div id="map-deck-picker-menu" className="map-deck-picker-menu">
                          {deckOverlayOptions.map((deckOption) => (
                            <button
                              key={deckOption.id}
                              type="button"
                              onClick={() => {
                                setActiveDeckOverlayId(deckOption.id);
                                setDeckOverlayEnabled(true);
                                setDeckMenuOpen(false);
                              }}
                              className={`map-deck-picker-option ${
                                deckOption.id === activeDeckOverlayId
                                  ? "map-selection-active border-cyan-300/60 bg-cyan-500/20 text-cyan-100"
                                  : "border-white/30 bg-black/45 text-slate-100 hover:bg-black/65"
                              }`}
                            >
                              {deckOption.label}
                            </button>
                          ))}
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              ) : null}

              {hasDeckOverlay && deckOverlayEnabled ? (
                <section
                  className={`map-legend-panel ${
                    mobileLegendOpen ? "map-legend-panel-mobile-open" : "map-legend-panel-mobile-closed"
                  }`}
                >
                  <div className="map-legend-mobile-bar">
                    <div className="map-legend-mobile-preview" aria-hidden>
                      {mobileLegendPreviewItems.map(({ key, color, Icon }) => (
                        <span
                          key={key}
                          className="map-legend-mobile-preview-item"
                          style={{ "--legend-accent": color } as React.CSSProperties}
                        >
                          <Icon className="map-legend-icon-svg" />
                        </span>
                      ))}
                    </div>
                    <button
                      type="button"
                      className="map-legend-mobile-toggle"
                      onClick={() => setMobileLegendOpen((open) => !open)}
                      aria-expanded={mobileLegendOpen}
                      aria-label={mobileLegendOpen ? "Hide legend" : "Show legend"}
                    >
                      <svg viewBox="0 0 24 24" className="map-legend-mobile-toggle-icon" aria-hidden="true">
                        <path d="m7 15 5-5 5 5" />
                        <path d="m7 19 5-5 5 5" />
                        <path d="m7 11 5-5 5 5" />
                      </svg>
                    </button>
                  </div>

                  {visibleLegendSections.map((section) => {
                    const sectionOpen = activeLegendSectionKey === section.key;

                    return (
                    <div key={section.title} className="map-legend-section">
                      <button
                        type="button"
                        className={`map-legend-heading ${sectionOpen ? "map-legend-heading-active" : ""}`}
                        onClick={() => {
                          setActiveLegendSectionKey((current) => (current === section.key ? null : section.key));
                        }}
                        aria-expanded={sectionOpen}
                      >
                        {section.title}
                      </button>
                      {sectionOpen ? (
                      <div className="map-legend-items">
                        {section.items.map(({ key, label, color, Icon }) => {
                          const forcedRowClass =
                            Icon === RadarIcon
                              ? "map-legend-item-row-two"
                              : Icon === CoolerIcon
                                ? "map-legend-item-row-three"
                                : "";

                          return (
                            <button
                              key={label}
                              type="button"
                              ref={(node) => {
                                legendItemRefs.current[key] = node;
                              }}
                              className={`map-legend-item ${activeLegendKey === key ? "map-legend-item-active" : ""} ${forcedRowClass}`}
                              style={{ "--legend-accent": color } as React.CSSProperties}
                              title={label}
                              aria-label={label}
                              onMouseEnter={() => {
                                setHoveredLegendKey(key);
                              }}
                              onMouseLeave={() => {
                                setHoveredLegendKey(null);
                              }}
                              onFocus={() => {
                                setHoveredLegendKey(key);
                              }}
                              onBlur={() => {
                                setHoveredLegendKey(null);
                              }}
                              onClick={() => {
                                setHoveredMarkerTrace(null);
                                setHoveredLegendKey(key);
                              }}
                            >
                              <span className="map-legend-icon" aria-hidden>
                                <Icon className="map-legend-icon-svg" />
                              </span>
                              <span className="map-legend-label">{label}</span>
                            </button>
                          );
                        })}
                      </div>
                      ) : null}
                    </div>
                  )})}
                </section>
              ) : null}
            </div>

            {!modelScene && !loadError ? (
              <p className="absolute inset-x-0 top-4 text-center text-xs uppercase tracking-[0.15em] text-cyan-200/85">
                Loading {modelSource === null ? "model" : `${modelSource.toUpperCase()} model`}...
              </p>
            ) : null}

            {loadError ? (
              <p className="absolute inset-x-0 top-4 text-center text-xs uppercase tracking-[0.15em] text-red-300">
                Failed to load model: {loadError}
              </p>
            ) : null}
          </div>
        </article>
      </div>
    </section>
  );
}
