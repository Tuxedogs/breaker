import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  initialBuildQueue,
  initialInventoryEntries,
  inventoryLocations,
  itemTemplates,
  materialTemplates,
  recipeInputTemplates,
  recipeTemplates,
  rarityCatalog,
  type RecipeInputTemplate,
} from "../data/logistics/seed";
import { normalizeRecipeInputTemplate } from "../lib/logistics/materialResolver";
import {
  getLegacyMaterialItemKind,
  resolveInventoryItemName,
  resolveInventoryUnitType,
} from "../lib/logistics/inventory";
import type {
  BuildQueueItem,
  InventoryCatalogSource,
  InventoryEntry,
  InventoryItemKind,
  InventoryLocation,
  InventoryUnitType,
  ItemTemplate,
  MaterialTemplate,
  OwnedItem,
  RecipeTemplate,
  RarityInfo,
  ReservedMaterialAllocation,
} from "../types/logistics";

export interface CraftingRecipeRegistration {
  recipeId: string;
  name: string;
  category?: string;
  inputs: RecipeInputTemplate[];
}

interface LogisticsStoreState {
  materialTemplates: MaterialTemplate[];
  itemTemplates: ItemTemplate[];
  recipeTemplates: RecipeTemplate[];
  recipeInputTemplates: Record<string, RecipeInputTemplate[]>;
  locations: InventoryLocation[];
  inventoryEntries: InventoryEntry[];
  buildQueue: BuildQueueItem[];
  addLocation: (location: InventoryLocation) => void;
  updateLocation: (location: InventoryLocation) => void;
  deleteLocation: (id: string) => void;
  addInventoryEntries: (entries: InventoryEntry[]) => void;
  updateInventoryEntry: (entry: InventoryEntry) => void;
  deleteInventoryEntry: (id: string) => void;
  registerCraftingRecipe: (registration: CraftingRecipeRegistration) => void;
  addBuildQueueItem: (recipeId: string, quantity?: number, snapshot?: Partial<Pick<BuildQueueItem, "itemId" | "itemName" | "materialRequirements">>) => void;
  updateBuildQueueItemStatus: (id: string, status: NonNullable<BuildQueueItem["status"]>) => void;
  updateBuildQueueItemPriority: (id: string, priority: number) => void;
  toggleBuildQueueItemPriority: (id: string) => void;
  updateBuildQueueItemQuantity: (id: string, quantity: number) => void;
  updateBuildQueueItemAllowLowerQuality: (id: string, allowLowerQuality: boolean) => void;
  updateBuildQueueMaterialRequirement: (id: string, requirementId: string, input: RecipeInputTemplate) => void;
  removeBuildQueueItem: (id: string) => void;
  setBuildQueueItemAllocations: (buildQueueItemId: string, allocations: ReservedMaterialAllocation[]) => void;
  toggleBuildQueueAllocation: (buildQueueItemId: string, allocation: ReservedMaterialAllocation) => void;
  updateBuildQueueAllocationQuantity: (buildQueueItemId: string, allocationId: string, quantity: number) => void;
  clearBuildQueueItemAllocations: (buildQueueItemId: string) => void;
  clearStaleBuildQueueItemAllocations: (buildQueueItemId: string) => void;
  resetLogisticsState: () => void;
}

const LOGISTICS_STORAGE_KEY = "sc_logistics_state_v1";
const LEGACY_LOGISTICS_STORAGE_KEY = "moonbreaker-logistics-v1";

function migrateLegacyLogisticsStorage() {
  if (typeof window === "undefined") return;
  const storage = window.localStorage;
  if (storage.getItem(LOGISTICS_STORAGE_KEY)) return;
  const legacyState = storage.getItem(LEGACY_LOGISTICS_STORAGE_KEY);
  if (!legacyState) return;
  storage.setItem(LOGISTICS_STORAGE_KEY, legacyState);
}

function getMaterialTemplate(materialId: string | undefined, materials: MaterialTemplate[]): MaterialTemplate | undefined {
  if (!materialId) return undefined;
  return materials.find((material) => material.id === materialId);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isString(value: unknown): value is string {
  return typeof value === "string";
}

function isNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isRarityTier(value: unknown): value is keyof typeof rarityCatalog {
  return (
    value === "legendary" ||
    value === "epic" ||
    value === "rare" ||
    value === "uncommon" ||
    value === "common" ||
    value === "quantanium"
  );
}

function isMaterialType(value: unknown): value is MaterialTemplate["materialType"] {
  return value === "ore" || value === "refined" || value === "raw" || value === "special";
}

function isInventoryItemKind(value: unknown): value is InventoryItemKind {
  return (
    value === "material" ||
    value === "ore" ||
    value === "raw_mineable" ||
    value === "ice" ||
    value === "fps_weapon" ||
    value === "fps_armor" ||
    value === "vehicle_component" ||
    value === "crafted_item" ||
    value === "manual" ||
    value === "unknown"
  );
}

function isInventoryUnitType(value: unknown): value is InventoryUnitType {
  return value === "scu" || value === "unit";
}

function isInventoryCatalogSource(value: unknown): value is InventoryCatalogSource {
  return value === "api" || value === "seed" || value === "manual" || value === "unknown";
}

function isBuildStatus(value: unknown): value is BuildQueueItem["status"] {
  return value === "queued" || value === "active" || value === "paused" || value === "complete";
}

function coercePersistedRecipeInput(value: unknown, materials: MaterialTemplate[]): RecipeInputTemplate | null {
  if (!isRecord(value) || !isNumber(value.quantity)) return null;
  const materialId =
    isString(value.materialId) ? value.materialId :
    isString(value.materialKey) ? value.materialKey :
    isString(value.rawName) ? value.rawName :
    isString(value.materialName) ? value.materialName :
    isString(value.displayName) ? value.displayName :
    "";
  if (!materialId) return null;
  return normalizeRecipeInputTemplate({
    ...value,
    materialId,
    materialKey: isString(value.materialKey) ? value.materialKey : undefined,
    requirementId: isString(value.requirementId) ? value.requirementId : undefined,
    costId: isString(value.costId) ? value.costId : undefined,
    materialGuid: isString(value.materialGuid) ? value.materialGuid : isString(value.costId) ? value.costId : undefined,
    materialName: isString(value.materialName) ? value.materialName : undefined,
    displayName: isString(value.displayName) ? value.displayName : undefined,
    rawName: isString(value.rawName) ? value.rawName : undefined,
    sourceName: isString(value.sourceName) ? value.sourceName : undefined,
    sourceType: isString(value.sourceType) ? value.sourceType : undefined,
    quantity: value.quantity,
  } as RecipeInputTemplate, materials);
}

function coercePersistedReservedAllocation(value: unknown): ReservedMaterialAllocation | null {
  if (
    !isRecord(value) ||
    !isString(value.id) ||
    !isString(value.materialId) ||
    !isString(value.inventoryEntryId) ||
    !isNumber(value.quantityReserved) ||
    !isRecord(value.rarity) ||
    !isRarityTier(value.rarity.tier)
  ) {
    return null;
  }

  return {
    id: value.id,
    materialId: value.materialId,
    inventoryEntryId: value.inventoryEntryId,
    quantityReserved: Math.max(0, value.quantityReserved),
    requirementId: isString(value.requirementId) ? value.requirementId : undefined,
    selectedQuality: isNumber(value.selectedQuality) ? value.selectedQuality : undefined,
    allowLowerQualityOverride: value.allowLowerQualityOverride === true,
    unitType: isString(value.unitType) ? value.unitType as ReservedMaterialAllocation["unitType"] : undefined,
    materialName: isString(value.materialName) ? value.materialName : undefined,
    quality: isNumber(value.quality) ? value.quality : undefined,
    rarity: rarityCatalog[value.rarity.tier],
    locationId: isString(value.locationId) ? value.locationId : undefined,
    container: isString(value.container) ? value.container : undefined,
  };
}

export function getRarityForQuality(quality?: number, material?: MaterialTemplate): RarityInfo {
  if (quality === undefined) return rarityCatalog.common;
  if (material?.isQuantanium) return rarityCatalog.quantanium;
  if (quality >= 900) return rarityCatalog.legendary;
  if (quality >= 800) return rarityCatalog.epic;
  if (quality >= 750) return rarityCatalog.rare;
  if (quality >= 650) return rarityCatalog.uncommon;
  return rarityCatalog.common;
}

function normalizeRarity(rarity: RarityInfo | undefined, fallback: RarityInfo): RarityInfo {
  return isRarityTier(rarity?.tier) ? rarityCatalog[rarity.tier] : fallback;
}

function normalizeInventoryEntry(
  entry: InventoryEntry,
  materials: MaterialTemplate[],
  fallbackCreatedAt?: string,
): InventoryEntry {
  const material = getMaterialTemplate(entry.materialId, materials);
  const quality = isNumber(entry.quality) ? Math.max(0, Math.min(1000, entry.quality)) : undefined;
  const rarity = material?.isQuantanium
    ? rarityCatalog.quantanium
    : quality !== undefined
      ? getRarityForQuality(quality, material)
      : normalizeRarity(entry.rarity, rarityCatalog.common);
  const itemName = resolveInventoryItemName(entry, material);
  const itemKind = entry.itemKind ?? getLegacyMaterialItemKind(material);
  const unitType = entry.unitType ?? resolveInventoryUnitType(entry, material);
  return {
    ...entry,
    materialName: material?.name ?? entry.materialName,
    materialType: material?.materialType ?? entry.materialType,
    catalogItemId: entry.catalogItemId ?? entry.materialId,
    catalogSource: entry.catalogSource ?? (material ? "seed" : "manual"),
    itemName,
    itemKind,
    unitType,
    quality,
    accentTier: quality !== undefined ? rarity.tier : entry.accentTier,
    rarity,
    createdAt: entry.createdAt ?? fallbackCreatedAt ?? new Date().toISOString(),
    updatedAt: entry.updatedAt ?? new Date().toISOString(),
  };
}

export function normalizeOwnedItemRarity(item: OwnedItem): OwnedItem {
  return {
    ...item,
    rarity: normalizeRarity(item.rarity, rarityCatalog.common),
  };
}

function getInventoryMergeKey(entry: InventoryEntry): string {
  return [
    entry.materialId ?? "",
    entry.catalogItemId ?? "",
    entry.itemName ?? entry.materialName ?? "",
    entry.itemKind ?? "",
    entry.unitType ?? "",
  ].join("|");
}

function coercePersistedLocation(value: unknown): InventoryLocation | null {
  if (!isRecord(value) || !isString(value.id) || !isString(value.name)) return null;
  return {
    id: value.id,
    name: value.name,
    category: isString(value.category) ? value.category : undefined,
    system: isString(value.system) ? value.system : undefined,
    type: (value.type === "station" || value.type === "city" || value.type === "outpost" || value.type === "ship")
      ? (value.type as InventoryLocation["type"]) : undefined,
  };
}

function coercePersistedInventoryEntry(value: unknown, materials: MaterialTemplate[]): InventoryEntry | null {
  if (!isRecord(value) || !isString(value.id) || !isNumber(value.quantity)) {
    return null;
  }
  const materialId = isString(value.materialId) ? value.materialId : undefined;
  const itemName = isString(value.itemName) ? value.itemName : isString(value.materialName) ? value.materialName : undefined;
  const catalogItemId = isString(value.catalogItemId) ? value.catalogItemId : materialId;
  if (!materialId && !itemName && !catalogItemId) return null;

  const material = getMaterialTemplate(materialId, materials);
  const materialType = material?.materialType ?? (isMaterialType(value.materialType) ? value.materialType : "special");
  const entry: InventoryEntry = {
    id: value.id,
    materialId,
    materialName: isString(value.materialName) ? value.materialName : undefined,
    materialType,
    catalogItemId,
    catalogSource: isInventoryCatalogSource(value.catalogSource) ? value.catalogSource : undefined,
    itemName,
    itemKind: isInventoryItemKind(value.itemKind) ? value.itemKind : undefined,
    category: isString(value.category) ? value.category : undefined,
    unitType: isInventoryUnitType(value.unitType) ? value.unitType : undefined,
    quality: isNumber(value.quality) ? value.quality : undefined,
    quantity: value.quantity,
    locationId: isString(value.locationId) ? value.locationId : undefined,
    container: isString(value.container) ? value.container : isString(value.containerName) ? value.containerName : undefined,
    notes: isString(value.notes) ? value.notes : undefined,
    source: isString(value.source) ? value.source : undefined,
    sourceHistory: Array.isArray(value.sourceHistory) ? value.sourceHistory.filter(isString) : undefined,
    workOrderId: isString(value.workOrderId) ? value.workOrderId : undefined,
    workOrderIds: Array.isArray(value.workOrderIds) ? value.workOrderIds.filter(isString) : undefined,
    accentTier: isRarityTier(value.accentTier) ? value.accentTier : undefined,
    rarity: isRecord(value.rarity) && isRarityTier(value.rarity.tier)
      ? rarityCatalog[value.rarity.tier]
      : rarityCatalog.common,
    createdAt: isString(value.createdAt) ? value.createdAt : new Date().toISOString(),
    updatedAt: isString(value.updatedAt) ? value.updatedAt : new Date().toISOString(),
  };

  return normalizeInventoryEntry(entry, materials);
}

function coercePersistedBuildQueueItem(value: unknown, materials: MaterialTemplate[]): BuildQueueItem | null {
  if (!isRecord(value) || !isString(value.id) || !isString(value.recipeId) || !isNumber(value.quantity)) {
    return null;
  }

  return {
    id: value.id,
    recipeId: value.recipeId,
    itemId: isString(value.itemId) ? value.itemId : undefined,
    itemName: isString(value.itemName) ? value.itemName : undefined,
    quantity: value.quantity,
    allowLowerQuality: value.allowLowerQuality === true,
    priority: isNumber(value.priority) ? value.priority : undefined,
    priorityActive: typeof value.priorityActive === "boolean" ? value.priorityActive : undefined,
    status: isBuildStatus(value.status) ? value.status : undefined,
    reservedAllocations: Array.isArray(value.reservedAllocations)
      ? value.reservedAllocations
          .map(coercePersistedReservedAllocation)
          .filter((allocation): allocation is ReservedMaterialAllocation => allocation !== null)
      : undefined,
    materialRequirements: Array.isArray(value.materialRequirements)
      ? value.materialRequirements
          .map((input) => coercePersistedRecipeInput(input, materials))
          .filter((input): input is RecipeInputTemplate => input !== null)
      : undefined,
  };
}

function getPersistedArray(persisted: unknown, key: string): unknown[] | undefined {
  if (!isRecord(persisted)) return undefined;
  const value = persisted[key];
  return Array.isArray(value) ? value : undefined;
}

function getReservedQuantityForStack(
  buildQueue: BuildQueueItem[],
  inventoryEntryId: string,
  excludeBuildQueueItemId?: string,
): number {
  return buildQueue.reduce((sum, item) => {
    if (item.id === excludeBuildQueueItemId) return sum;
    return (
      sum +
      (item.reservedAllocations ?? [])
        .filter((allocation) => allocation.inventoryEntryId === inventoryEntryId)
        .reduce((allocationSum, allocation) => allocationSum + allocation.quantityReserved, 0)
    );
  }, 0);
}

function getRequirementLineId(item: BuildQueueItem, input: RecipeInputTemplate, index: number): string {
  return input.requirementId ?? `${item.id}:${index}:${input.materialKey ?? input.materialId}:${input.modifierName ?? input.modifierType ?? "material"}`;
}

function createValidatedAllocation(
  allocation: ReservedMaterialAllocation,
  inventoryEntry: InventoryEntry,
  quantityReserved: number,
): ReservedMaterialAllocation {
  const materialId = inventoryEntry.materialId ?? allocation.materialId;
  const allocationId = allocation.id || [
    allocation.requirementId,
    materialId,
    allocation.selectedQuality ?? "any",
    allocation.unitType ?? "unit",
    inventoryEntry.id,
    inventoryEntry.locationId ?? "unassigned",
  ].join(":");
  return {
    id: allocationId,
    inventoryEntryId: inventoryEntry.id,
    materialId,
    quantityReserved,
    requirementId: allocation.requirementId,
    selectedQuality: allocation.selectedQuality,
    allowLowerQualityOverride: allocation.allowLowerQualityOverride,
    unitType: allocation.unitType,
    materialName: inventoryEntry.itemName ?? inventoryEntry.materialName ?? allocation.materialName,
    quality: inventoryEntry.quality,
    rarity: normalizeRarity(inventoryEntry.rarity, rarityCatalog.common),
    locationId: inventoryEntry.locationId,
    container: inventoryEntry.container,
  };
}

function sanitizeReservedAllocationsForItem(
  buildQueueItemId: string,
  allocations: ReservedMaterialAllocation[],
  state: Pick<LogisticsStoreState, "buildQueue" | "inventoryEntries">,
): ReservedMaterialAllocation[] {
  if (!state.buildQueue.some((item) => item.id === buildQueueItemId)) return [];

  const usedByPayload = new Map<string, number>();
  const sanitized: ReservedMaterialAllocation[] = [];

  for (const allocation of allocations) {
    if (!allocation.inventoryEntryId || allocation.quantityReserved <= 0) continue;
    const inventoryEntry = state.inventoryEntries.find((entry) => entry.id === allocation.inventoryEntryId);
    if (!inventoryEntry?.materialId || inventoryEntry.materialId !== allocation.materialId) continue;
    if (
      !allocation.allowLowerQualityOverride &&
      allocation.selectedQuality !== undefined &&
      (inventoryEntry.quality === undefined || inventoryEntry.quality < allocation.selectedQuality)
    ) continue;

    const reservedByOthers = getReservedQuantityForStack(
      state.buildQueue,
      allocation.inventoryEntryId,
      buildQueueItemId,
    );
    const alreadyUsed = usedByPayload.get(allocation.inventoryEntryId) ?? 0;
    const availableQuantity = Math.max(0, inventoryEntry.quantity - reservedByOthers - alreadyUsed);
    const quantityReserved = Math.min(allocation.quantityReserved, availableQuantity);
    if (quantityReserved <= 0) continue;

    usedByPayload.set(allocation.inventoryEntryId, alreadyUsed + quantityReserved);
    sanitized.push(createValidatedAllocation(allocation, inventoryEntry, quantityReserved));
  }

  return sanitized;
}

function removeStaleReservedAllocations(
  allocations: ReservedMaterialAllocation[],
  inventoryEntries: InventoryEntry[],
): ReservedMaterialAllocation[] {
  return allocations.filter((allocation) => {
    const inventoryEntry = inventoryEntries.find((entry) => entry.id === allocation.inventoryEntryId);
    return (
      inventoryEntry !== undefined &&
      inventoryEntry.materialId !== undefined &&
      inventoryEntry.materialId === allocation.materialId &&
      allocation.quantityReserved > 0 &&
      allocation.quantityReserved <= inventoryEntry.quantity
    );
  });
}

migrateLegacyLogisticsStorage();

export const useLogisticsStore = create<LogisticsStoreState>()(
  persist(
    (set) => ({
      materialTemplates,
      itemTemplates,
      recipeTemplates,
      recipeInputTemplates,
      locations: inventoryLocations,
      inventoryEntries: initialInventoryEntries,
      buildQueue: initialBuildQueue,
      addLocation: (location) => {
        set((state) => ({ locations: [...state.locations, location] }));
      },
      updateLocation: (location) => {
        set((state) => ({ locations: state.locations.map((l) => l.id === location.id ? location : l) }));
      },
      deleteLocation: (id) => {
        set((state) => ({ locations: state.locations.filter((l) => l.id !== id) }));
      },
      addInventoryEntries: (entries) => {
        set((state) => ({
          inventoryEntries: entries.reduce((inventory, entry) => {
            const normalized = normalizeInventoryEntry(entry, state.materialTemplates);
            const incomingWorkOrderIds = normalized.workOrderIds ?? (normalized.workOrderId ? [normalized.workOrderId] : []);
            if (
              incomingWorkOrderIds.length > 0 &&
              inventory.some((current) => {
                const currentWorkOrderIds = current.workOrderIds ?? (current.workOrderId ? [current.workOrderId] : []);
                return current.materialId !== undefined &&
                  current.materialId === normalized.materialId &&
                  currentWorkOrderIds.some((id) => incomingWorkOrderIds.includes(id));
              })
            ) {
              return inventory;
            }
            const existingIdx = inventory.findIndex((current) =>
              getInventoryMergeKey(current) === getInventoryMergeKey(normalized) &&
              (current.locationId ?? "") === (normalized.locationId ?? "") &&
              (current.container ?? "") === (normalized.container ?? "") &&
              (current.quality ?? "__none") === (normalized.quality ?? "__none")
            );
            if (existingIdx === -1) return [...inventory, normalized];

            const existing = inventory[existingIdx];
            const sourceHistory = Array.from(new Set([
              ...(existing.sourceHistory ?? (existing.source ? [existing.source] : [])),
              ...(normalized.sourceHistory ?? (normalized.source ? [normalized.source] : [])),
            ]));
            const workOrderIds = Array.from(new Set([
              ...(existing.workOrderIds ?? (existing.workOrderId ? [existing.workOrderId] : [])),
              ...(normalized.workOrderIds ?? (normalized.workOrderId ? [normalized.workOrderId] : [])),
            ]));
            const merged = normalizeInventoryEntry({
              ...existing,
              quantity: existing.quantity + normalized.quantity,
              source: normalized.source ?? existing.source,
              sourceHistory: sourceHistory.length ? sourceHistory : undefined,
              workOrderId: normalized.workOrderId ?? existing.workOrderId,
              workOrderIds: workOrderIds.length ? workOrderIds : undefined,
              updatedAt: new Date().toISOString(),
            }, state.materialTemplates, existing.createdAt);

            return inventory.map((current, idx) => idx === existingIdx ? merged : current);
          }, state.inventoryEntries),
        }));
      },
      updateInventoryEntry: (entry) => {
        set((state) => ({
          inventoryEntries: state.inventoryEntries.map((current) =>
            current.id === entry.id
              ? normalizeInventoryEntry(entry, state.materialTemplates, current.createdAt)
              : current,
          ),
        }));
      },
      deleteInventoryEntry: (id) => {
        set((state) => ({
          inventoryEntries: state.inventoryEntries.filter((entry) => entry.id !== id),
        }));
      },
      registerCraftingRecipe: ({ recipeId, name, category, inputs }) => {
        set((state) => {
          const normalizedInputs = inputs.map((input) => normalizeRecipeInputTemplate(input, state.materialTemplates));
          const existingRecipe = state.recipeTemplates.find((r) => r.id === recipeId);
          const nextRecipes = existingRecipe
            ? state.recipeTemplates
            : [...state.recipeTemplates, { id: recipeId, name, category }];
          return {
            recipeTemplates: nextRecipes,
            recipeInputTemplates: { ...state.recipeInputTemplates, [recipeId]: normalizedInputs },
          };
        });
      },
      addBuildQueueItem: (recipeId, quantity = 1, snapshot) => {
        set((state) => {
          const existing = state.buildQueue.find((item) =>
            item.recipeId === recipeId &&
            JSON.stringify(item.materialRequirements ?? null) === JSON.stringify(snapshot?.materialRequirements ?? null)
          );
          if (existing) {
            return {
              buildQueue: state.buildQueue.map((item) =>
                item.id === existing.id ? { ...item, quantity: item.quantity + quantity } : item,
              ),
            };
          }
          const nextPriority = state.buildQueue.reduce((max, item) => Math.max(max, item.priority ?? 0), 0) + 1;
          const newItem: BuildQueueItem = {
            id: `bq-craft-${recipeId}-${Date.now()}`,
            recipeId,
            itemId: snapshot?.itemId,
            itemName: snapshot?.itemName,
            quantity,
            allowLowerQuality: false,
            status: "queued",
            priority: nextPriority,
            priorityActive: false,
            materialRequirements: snapshot?.materialRequirements?.map((input, index) => ({
              ...input,
              requirementId: input.requirementId ?? `${recipeId}:${index}:${input.materialKey ?? input.materialId}:${input.modifierName ?? input.modifierType ?? "material"}`,
            })),
          };
          return { buildQueue: [...state.buildQueue, newItem] };
        });
      },
      updateBuildQueueItemStatus: (id, status) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) => (item.id === id ? { ...item, status } : item)),
        }));
      },
      updateBuildQueueItemPriority: (id, priority) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) =>
            item.id === id ? { ...item, priority: Math.max(1, Math.trunc(priority)) } : item,
          ),
        }));
      },
      toggleBuildQueueItemPriority: (id) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) =>
            item.id === id ? { ...item, priorityActive: !(item.priorityActive ?? false) } : item,
          ),
        }));
      },
      updateBuildQueueItemQuantity: (id, quantity) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) =>
            item.id === id ? { ...item, quantity: Math.max(1, Math.trunc(quantity)) } : item,
          ),
        }));
      },
      updateBuildQueueItemAllowLowerQuality: (id, allowLowerQuality) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) =>
            item.id === id
              ? {
                  ...item,
                  allowLowerQuality,
                  reservedAllocations: allowLowerQuality
                    ? item.reservedAllocations
                    : (item.reservedAllocations ?? []).filter((allocation) => !allocation.allowLowerQualityOverride),
                }
              : item,
          ),
        }));
      },
      updateBuildQueueMaterialRequirement: (id, requirementId, input) => {
        set((state) => {
          const item = state.buildQueue.find((entry) => entry.id === id);
          if (!item) return {};
          const inputs = (item.materialRequirements ?? state.recipeInputTemplates[item.recipeId] ?? []).map((entry, index) => ({
            ...entry,
            requirementId: getRequirementLineId(item, entry, index),
          }));
          return {
            buildQueue: state.buildQueue.map((entry) =>
              entry.id === id
                ? {
                    ...entry,
                    materialRequirements: inputs.map((entry) =>
                      entry.requirementId === requirementId
                        ? { ...entry, ...input, requirementId: entry.requirementId, materialId: entry.materialId, quantity: entry.quantity }
                        : entry,
                    ),
                  }
                : entry,
            ),
          };
        });
      },
      removeBuildQueueItem: (id) => {
        set((state) => ({
          buildQueue: state.buildQueue.filter((item) => item.id !== id),
        }));
      },
      setBuildQueueItemAllocations: (buildQueueItemId, allocations) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) =>
            item.id === buildQueueItemId
              ? { ...item, reservedAllocations: sanitizeReservedAllocationsForItem(buildQueueItemId, allocations, state) }
              : item,
          ),
        }));
      },
      toggleBuildQueueAllocation: (buildQueueItemId, allocation) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) => {
            if (item.id !== buildQueueItemId) return item;
            const allocations = item.reservedAllocations ?? [];
            const exists = allocations.some((current) => current.id === allocation.id);
            const nextAllocations = exists
              ? allocations.filter((current) => current.id !== allocation.id)
              : sanitizeReservedAllocationsForItem(buildQueueItemId, [...allocations, allocation], state);
            return {
              ...item,
              reservedAllocations: nextAllocations,
            };
          }),
        }));
      },
      updateBuildQueueAllocationQuantity: (buildQueueItemId, allocationId, quantity) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) => {
            if (item.id !== buildQueueItemId) return item;
            const allocations = item.reservedAllocations ?? [];
            const allocation = allocations.find((entry) => entry.id === allocationId);
            if (!allocation) return item;
            const inventoryEntry = state.inventoryEntries.find((e) => e.id === allocation.inventoryEntryId);
            if (!inventoryEntry) return item;
            if (!allocation || allocation.materialId !== inventoryEntry.materialId) return item;
            if (
              !allocation.allowLowerQualityOverride &&
              allocation.selectedQuality !== undefined &&
              (inventoryEntry.quality === undefined || inventoryEntry.quality < allocation.selectedQuality)
            ) {
              return { ...item, reservedAllocations: allocations.filter((a) => a.id !== allocationId) };
            }
            const reservedByOthers = getReservedQuantityForStack(state.buildQueue, inventoryEntry.id, buildQueueItemId);
            const reservedByThisStackOtherSlots = allocations
              .filter((entry) => entry.id !== allocationId && entry.inventoryEntryId === inventoryEntry.id)
              .reduce((sum, entry) => sum + entry.quantityReserved, 0);
            const maxQuantity = Math.max(0, inventoryEntry.quantity - reservedByOthers - reservedByThisStackOtherSlots);
            const clamped = Math.max(0, Math.min(quantity, maxQuantity));
            if (clamped <= 0) {
              return { ...item, reservedAllocations: allocations.filter((a) => a.id !== allocationId) };
            }
            return {
              ...item,
              reservedAllocations: allocations.map((a) =>
                a.id === allocationId ? createValidatedAllocation(a, inventoryEntry, clamped) : a,
              ),
            };
          }),
        }));
      },
      clearBuildQueueItemAllocations: (buildQueueItemId) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) =>
            item.id === buildQueueItemId ? { ...item, reservedAllocations: [] } : item,
          ),
        }));
      },
      clearStaleBuildQueueItemAllocations: (buildQueueItemId) => {
        set((state) => ({
          buildQueue: state.buildQueue.map((item) =>
            item.id === buildQueueItemId
              ? {
                  ...item,
                  reservedAllocations: removeStaleReservedAllocations(
                    item.reservedAllocations ?? [],
                    state.inventoryEntries,
                  ),
                }
              : item,
          ),
        }));
      },
      resetLogisticsState: () => {
        set({
          materialTemplates,
          itemTemplates,
          recipeTemplates,
          recipeInputTemplates,
          locations: inventoryLocations,
          inventoryEntries: initialInventoryEntries,
          buildQueue: initialBuildQueue,
        });
      },
    }),
    {
      name: LOGISTICS_STORAGE_KEY,
      version: 2,
      partialize: (state) => ({
        inventoryEntries: state.inventoryEntries,
        buildQueue: state.buildQueue,
        locations: state.locations,
        recipeTemplates: state.recipeTemplates,
        recipeInputTemplates: state.recipeInputTemplates,
      }),
      merge: (persisted, current) => {
        const persistedInventory = getPersistedArray(persisted, "inventoryEntries");
        const persistedBuildQueue = getPersistedArray(persisted, "buildQueue");
        const persistedLocations = getPersistedArray(persisted, "locations");
        const persistedRecipes = getPersistedArray(persisted, "recipeTemplates");
        const persistedInputs = isRecord(persisted) ? persisted["recipeInputTemplates"] : undefined;

        const inventoryEntries = persistedInventory
          ?.map((entry) => coercePersistedInventoryEntry(entry, current.materialTemplates))
          .filter((entry): entry is InventoryEntry => entry !== null);
        const buildQueue = persistedBuildQueue
          ?.map((item) => coercePersistedBuildQueueItem(item, current.materialTemplates))
          .filter((item): item is BuildQueueItem => item !== null);
        const locations = persistedLocations
          ?.map(coercePersistedLocation)
          .filter((l): l is InventoryLocation => l !== null);

        // Merge persisted recipe templates over seed — seed entries win for known IDs
        const seedRecipeIds = new Set(current.recipeTemplates.map((r) => r.id));
        const extraRecipes: RecipeTemplate[] = Array.isArray(persistedRecipes)
          ? persistedRecipes.filter(
              (r): r is RecipeTemplate =>
                isRecord(r) && isString(r.id) && isString(r.name) && !seedRecipeIds.has(r.id as string),
            )
          : [];
        const mergedRecipes = [...current.recipeTemplates, ...extraRecipes];

        const mergedInputs: Record<string, RecipeInputTemplate[]> = { ...current.recipeInputTemplates };
        if (isRecord(persistedInputs)) {
          for (const [recipeId, inputs] of Object.entries(persistedInputs)) {
            if (seedRecipeIds.has(recipeId)) continue;
            if (Array.isArray(inputs)) {
              const coerced = inputs
                .map((input) => coercePersistedRecipeInput(input, current.materialTemplates))
                .filter((input): input is RecipeInputTemplate => input !== null);
              if (coerced.length) mergedInputs[recipeId] = coerced;
            }
          }
        }

        return {
          ...current,
          inventoryEntries: inventoryEntries ?? current.inventoryEntries,
          buildQueue: buildQueue ?? current.buildQueue,
          locations: locations?.length ? locations : current.locations,
          recipeTemplates: mergedRecipes,
          recipeInputTemplates: mergedInputs,
        };
      },
    },
  ),
);

export function createInventoryEntryDraft(
  input: Pick<InventoryEntry, "id" | "quantity"> &
    Partial<Omit<InventoryEntry, "id" | "quantity" | "rarity">>,
): InventoryEntry {
  const material = getMaterialTemplate(input.materialId, get().materialTemplates);
  const timestamp = new Date().toISOString();
  const quality = input.quality === undefined ? undefined : Math.max(0, Math.min(1000, input.quality));
  const rarity = quality !== undefined ? getRarityForQuality(quality, material) : rarityCatalog.common;
  return normalizeInventoryEntry({
    id: input.id,
    materialId: input.materialId,
    materialName: material?.name ?? input.materialName,
    materialType: material?.materialType ?? input.materialType,
    catalogItemId: input.catalogItemId ?? input.materialId,
    catalogSource: input.catalogSource,
    itemName: input.itemName,
    itemKind: input.itemKind,
    category: input.category,
    unitType: input.unitType,
    quality,
    quantity: input.quantity,
    locationId: input.locationId,
    container: input.container,
    notes: input.notes,
    source: input.source,
    sourceHistory: input.sourceHistory,
    workOrderId: input.workOrderId,
    workOrderIds: input.workOrderIds,
    accentTier: quality !== undefined ? rarity.tier : input.accentTier,
    rarity,
    createdAt: input.createdAt ?? timestamp,
    updatedAt: input.updatedAt ?? timestamp,
  }, get().materialTemplates);
}

function get() {
  return useLogisticsStore.getState();
}
