export type ModuleFilters = {
  ship: string;
  role: string;
  enemy: string;
  status: string;
  domain: string;
  query: string;
};

export const emptyModuleFilters: ModuleFilters = {
  ship: "",
  role: "",
  enemy: "",
  status: "",
  domain: "",
  query: "",
};

export function readModuleFilters(searchParams: URLSearchParams): ModuleFilters {
  return {
    ship: searchParams.get("ship") ?? "",
    role: searchParams.get("role") ?? "",
    enemy: searchParams.get("enemy") ?? "",
    status: searchParams.get("status") ?? "",
    domain: searchParams.get("domain") ?? "",
    query: searchParams.get("q") ?? "",
  };
}

export function writeModuleFilters(filters: ModuleFilters): URLSearchParams {
  const params = new URLSearchParams();
  const entries = Object.entries(filters) as Array<[keyof ModuleFilters, string]>;
  for (const [key, value] of entries) {
    if (value) {
      params.set(key === "query" ? "q" : key, value);
    }
  }
  return params;
}
