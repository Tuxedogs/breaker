import './threshold.css'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  AlphaThresholdOnboardingModal,
  type AlphaThresholdOnboardingHighlight,
} from './components/AlphaThresholdOnboardingModal'
import { AlphaThresholdMobileOnboardingTip } from './components/AlphaThresholdMobileOnboardingTip'
import { ShipSelectorOverlay } from './components/ShipSelectorOverlay'
import { ThresholdHeatmapBoard } from './components/ThresholdHeatmapBoard'
import { WeaponSelectorOverlay } from './components/WeaponSelectorOverlay'
import { useAlphaThresholdState } from './hooks/useAlphaThresholdState'
import { useLocalStorageState } from './hooks/useLocalStorageState'
import type { ArmorInteractionFilterChip } from './components/ArmorInteractionSummaryPanel'
import type { Ship, SelectedWeaponComparison, SlotTone, WeaponRecord } from './types'
import { parseShieldMode } from './lib/shieldMode'

const MATRIX_VISIBLE_SLOT_COUNT = 6
const SLOT_TONES: SlotTone[] = ['cyan', 'violet', 'amber', 'emerald']

export default function AlphaThresholdToolPage() {
  const [selectionMode, setSelectionMode] = useState<'ship' | 'weapon' | null>(null)
  const [activeShipSlotIndex, setActiveShipSlotIndex] = useState(0)
  const [activeWeaponSlotIndex, setActiveWeaponSlotIndex] = useState(0)
  const [weaponAnchorSlotIndex, setWeaponAnchorSlotIndex] = useState(0)
  const [shipAutoAdvance, setShipAutoAdvance] = useState(true)
  const [weaponAutoAdvance, setWeaponAutoAdvance] = useState(true)
  const [selectionNotice, setSelectionNotice] = useState<string | null>(null)
  const [hoveredShipSlotIndex, setHoveredShipSlotIndex] = useState<number | null>(null)
  const [hoveredWeaponSlotIndex, setHoveredWeaponSlotIndex] = useState<number | null>(null)
  const [weaponOverlayFilterPreset, setWeaponOverlayFilterPreset] =
    useState<ArmorInteractionFilterChip | null>(null)
  const [targetWeaponFilterPreset, setTargetWeaponFilterPreset] =
    useState<ArmorInteractionFilterChip | null>(null)
  const [targetWeaponSizeFilter, setTargetWeaponSizeFilter] = useState<number | null>(null)
  /** Clears in the overlay; at 2+ re-enable auto-advance (per ship / weapon flows). */
  const shipClearStreakRef = useRef(0)
  const weaponClearStreakRef = useRef(0)
  const [searchParams, setSearchParams] = useSearchParams()
  const [onboardingDismissed, setOnboardingDismissed] = useLocalStorageState<boolean>(
    'moonbreaker.alphaThreshold.onboarding.v1',
    false
  )
  const [mobileOnboardingDismissed, setMobileOnboardingDismissed] = useLocalStorageState<boolean>(
    'moonbreaker.alphaThreshold.mobileOnboarding.v1',
    false
  )
  const [onboardingHighlight, setOnboardingHighlight] =
    useState<AlphaThresholdOnboardingHighlight>(null)
  const [isMobileViewport, setIsMobileViewport] = useState(false)
  const [matrixMode, setMatrixMode] = useState<'analysis' | 'target'>('analysis')
  const {
    slots,
    setSlotWeapon,
    allWeapons,
    allShips,
    selectedWeapons,
    selectedShipNames,
    setVictimShipAt,
    maxVictimShips,
    shipPresets,
    weaponSizePresets,
    weaponPresets,
    activeShipPresetId,
    activeWeaponPresetId,
    activeWeaponSizePresetId,
    applyShipPreset,
    applyWeaponSizePreset,
    applyWeaponPreset,
    clearShipPreset,
    clearWeaponPreset,
  } = useAlphaThresholdState(matrixMode)
  const shieldMode = parseShieldMode(searchParams.get('shield'))
  const visibleShipCount = Math.min(maxVictimShips, MATRIX_VISIBLE_SLOT_COUNT)
  const visibleWeaponCount = Math.min(slots.length, MATRIX_VISIBLE_SLOT_COUNT)
  const activeShipLimit = visibleShipCount
  const activeWeaponLimit = visibleWeaponCount

  const handleOnboardingHighlight = useCallback((highlight: AlphaThresholdOnboardingHighlight) => {
    setOnboardingHighlight(highlight)
  }, [])

  const handleOnboardingComplete = useCallback(() => {
    setOnboardingDismissed(true)
    setOnboardingHighlight(null)
  }, [setOnboardingDismissed])

  function getShipSelectionKey(ship: Pick<Ship, 'manufacturer' | 'name'>): string {
    return `${ship.manufacturer}::${ship.name}`
  }
  const nextShipSlotIndex = useMemo(() => {
    const openIndex = selectedShipNames.slice(0, activeShipLimit).findIndex((shipName) => shipName === null)
    return openIndex === -1 ? Math.max(0, activeShipLimit - 1) : openIndex
  }, [selectedShipNames, activeShipLimit])
  const nextWeaponSlotIndex = useMemo(() => {
    const openIndex = slots.slice(0, activeWeaponLimit).findIndex((slot) => slot.weaponKey == null)
    return openIndex === -1 ? Math.max(0, activeWeaponLimit - 1) : openIndex
  }, [slots, activeWeaponLimit])

  /** Column shown in weapon overlay + matrix when auto-advance: prefer active slot if empty (e.g. after clear). */
  const weaponOverlayTargetIndex = useMemo(() => {
    const clamped = Math.max(0, Math.min(activeWeaponLimit - 1, activeWeaponSlotIndex))
    if (!weaponAutoAdvance) return clamped
    return slots[clamped]?.weaponKey == null ? clamped : nextWeaponSlotIndex
  }, [weaponAutoAdvance, activeWeaponSlotIndex, slots, nextWeaponSlotIndex, activeWeaponLimit])
  /** Matrix destination highlight: overlay hover must not move row/column — use active slot only while selector is open. */
  const effectiveShipSlotIndex = Math.max(
    0,
    Math.min(
      visibleShipCount - 1,
      activeShipLimit - 1,
      selectionMode === 'ship' ? activeShipSlotIndex : hoveredShipSlotIndex ?? activeShipSlotIndex
    )
  )
  const effectiveWeaponSlotIndex = Math.max(
    0,
    Math.min(
      activeWeaponLimit - 1,
      selectionMode === 'weapon' ? activeWeaponSlotIndex : hoveredWeaponSlotIndex ?? activeWeaponSlotIndex
    )
  )

  const shipBySelectionKey = useMemo(() => {
    return new Map(allShips.map((ship) => [getShipSelectionKey(ship), ship] as const))
  }, [allShips])

  const previewShips = useMemo(() => {
    const placeholderHistory: Ship['history'] = []
    return Array.from({ length: visibleShipCount }, (_, index): Ship => {
      const shipKey = selectedShipNames[index]
      const selectedShip = shipKey ? shipBySelectionKey.get(shipKey) : null
      if (selectedShip) return selectedShip

      return {
        id: `placeholder-ship-${index + 1}`,
        manufacturer: '',
        name: '',
        sizeGroup: 'small',
        health: 0,
        ballisticThreshold: 0,
        energyThreshold: 0,
        armor: 0,
        armorHp: 0,
        vitalHp: 0,
        history: placeholderHistory,
      }
    })
  }, [selectedShipNames, shipBySelectionKey, visibleShipCount])

  const previewWeapons = useMemo<SelectedWeaponComparison[]>(() => {
    const selectedWeaponBySlotId = new Map(
      selectedWeapons.map((selection) => [selection.slotId, selection] as const)
    )

    return slots
      .slice(0, visibleWeaponCount)
      .map((slot, index) => {
        const selectedWeapon = selectedWeaponBySlotId.get(slot.id)
        if (selectedWeapon) return selectedWeapon

        const placeholderWeapon: WeaponRecord = {
          id: `placeholder-weapon-${index + 1}`,
          name: '',
          size: 0,
          damageType: index % 2 === 0 ? 'ballistic' : 'energy',
          weaponClass: '',
          alpha: null,
          burstDps: null,
          projectileSpeed: null,
        }

        return {
          slotId: slot.id,
          slotLabel: slot.label ?? `Weapon ${index + 1}`,
          tone: SLOT_TONES[index] ?? 'cyan',
          weapon: placeholderWeapon,
        }
      })
  }, [selectedWeapons, slots, visibleWeaponCount])

  function handleShieldModeChange(mode: 'up' | 'down') {
    const next = new URLSearchParams(searchParams)
    next.set('shield', mode)
    setSearchParams(next, { replace: true })
  }

  useEffect(() => {
    document.body.classList.add('alpha-threshold-page')

    return () => {
      document.body.classList.remove('alpha-threshold-page')
    }
  }, [])

  useEffect(() => {
    const mq = window.matchMedia('(max-width: 768px)')
    const sync = () => setIsMobileViewport(mq.matches)
    sync()
    mq.addEventListener('change', sync)
    return () => mq.removeEventListener('change', sync)
  }, [])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return
      if (!selectionMode) return
      event.preventDefault()
      setSelectionMode(null)
    }

    const onPointerDown = (event: PointerEvent) => {
      if (!selectionMode) return
      const target = event.target
      if (!(target instanceof Element)) return

      // Dismiss unless the hit target is part of the overlay UI or an established
      // matrix slot control (ship column, weapon headers, chart corner). Clicks on
      // matrix cells / chart panels close the overlay.
      if (target.closest('.alpha-overlay-panel')) return
      if (target.closest('.acm-ship-card')) return
      if (target.closest('.acm-weapon-header')) return
      if (target.closest('.acm-corner')) return

      setSelectionMode(null)
      setSelectionNotice(null)
      setHoveredShipSlotIndex(null)
      setHoveredWeaponSlotIndex(null)
    }

    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('pointerdown', onPointerDown)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('pointerdown', onPointerDown)
    }
  }, [selectionMode])

  function handleShipSelect(shipKey: string) {
    const existingIndex = selectedShipNames.findIndex((selectedKey) => selectedKey === shipKey)
    if (existingIndex !== -1) {
      handleClearShipAt(existingIndex)
      return
    }

    const allShipSlotsFull = selectedShipNames.slice(0, activeShipLimit).every((name) => name != null)

    if (shipAutoAdvance && allShipSlotsFull) {
      setSelectionNotice('All ship slots are filled. Clear a slot or select one to replace.')
      return
    }

    const currentIndex = Math.max(0, Math.min(activeShipLimit - 1, activeShipSlotIndex))
    const currentSlotEmpty = selectedShipNames[currentIndex] == null
    const targetIndex = shipAutoAdvance
      ? selectedShipNames[currentIndex] == null
        ? currentIndex
        : nextShipSlotIndex
      : currentIndex
    const projectedShips = selectedShipNames.slice(0, activeShipLimit).map((selectedShip, index) =>
      index === targetIndex ? shipKey : selectedShip
    )
    const remainingOpenShipCount = projectedShips.filter((selectedShip) => selectedShip == null).length

    setSelectionNotice(null)
    shipClearStreakRef.current = 0
    setVictimShipAt(targetIndex, shipKey)

    if (!shipAutoAdvance && remainingOpenShipCount > 1) {
      const nextOpenIndex = projectedShips.findIndex((selectedShip) => selectedShip == null)
      setShipAutoAdvance(true)
      setActiveShipSlotIndex(
        nextOpenIndex === -1 ? targetIndex : Math.max(0, Math.min(activeShipLimit - 1, nextOpenIndex))
      )
      return
    }

    if (shipAutoAdvance && currentSlotEmpty) {
      const nextIndex = selectedShipNames.findIndex(
        (shipName, index) => index > targetIndex && shipName === null
      )
      setActiveShipSlotIndex(
        nextIndex === -1 ? targetIndex : Math.max(0, Math.min(activeShipLimit - 1, nextIndex))
      )
    }
  }

  function handleWeaponSelect(weaponKey: string) {
    const existingIndex = slots
      .slice(0, activeWeaponLimit)
      .findIndex((entry) => entry.weaponKey === weaponKey)
    if (existingIndex !== -1) {
      handleClearWeaponAt(existingIndex)
      return
    }

    const allWeaponSlotsFull = slots.slice(0, activeWeaponLimit).every((s) => s.weaponKey != null)

    if (weaponAutoAdvance && allWeaponSlotsFull) {
      setSelectionNotice('All weapon slots are filled. Clear a slot or select one to replace.')
      return
    }

    const currentIndex = Math.max(0, Math.min(activeWeaponLimit - 1, activeWeaponSlotIndex))
    const currentSlot = slots[currentIndex]
    const currentSlotEmpty = currentSlot?.weaponKey == null
    const targetIndex = weaponAutoAdvance
      ? currentSlotEmpty
        ? currentIndex
        : nextWeaponSlotIndex
      : currentIndex
    const slot = slots[targetIndex]
    if (!slot) return
    const projectedEntries = slots.slice(0, activeWeaponLimit).map((entry, index) =>
      index === targetIndex ? { ...entry, weaponKey } : entry
    )
    const remainingOpenWeaponCount = projectedEntries.filter((entry) => entry.weaponKey == null).length

    setSelectionNotice(null)
    weaponClearStreakRef.current = 0
    setSlotWeapon(slot.id, weaponKey)

    if (!weaponAutoAdvance && remainingOpenWeaponCount > 1) {
      const nextOpenIndex = projectedEntries.findIndex((entry) => entry.weaponKey == null)
      setWeaponAutoAdvance(true)
      setActiveWeaponSlotIndex(
        nextOpenIndex === -1 ? targetIndex : Math.max(0, Math.min(activeWeaponLimit - 1, nextOpenIndex))
      )
      return
    }

    if (weaponAutoAdvance && currentSlotEmpty) {
      const nextIndex = slots.slice(0, activeWeaponLimit).findIndex(
        (entry, index) => index > targetIndex && entry.weaponKey === null
      )
      setActiveWeaponSlotIndex(
        nextIndex === -1 ? targetIndex : Math.max(0, Math.min(activeWeaponLimit - 1, nextIndex))
      )
    }
  }

  function handleOpenShipsAt(slotIndex: number, autoAdvance = false) {
    const nextIndex = Math.max(0, Math.min(activeShipLimit - 1, slotIndex))

    if (selectionMode === 'ship' && activeShipSlotIndex === nextIndex) {
      setSelectionMode(null)
      setSelectionNotice(null)
      setHoveredShipSlotIndex(null)
      return
    }

    setActiveShipSlotIndex(nextIndex)
    setHoveredShipSlotIndex(null)
    setShipAutoAdvance(autoAdvance)
    if (autoAdvance) {
      shipClearStreakRef.current = 0
    }
    setSelectionNotice(null)
    setSelectionMode('ship')
  }

  function handleOpenWeaponsAt(slotIndex: number, autoAdvance = false) {
    const nextIndex = Math.max(0, Math.min(activeWeaponLimit - 1, slotIndex))
    setWeaponOverlayFilterPreset(null)
    setWeaponAnchorSlotIndex(nextIndex)
    setActiveWeaponSlotIndex(nextIndex)
    setHoveredWeaponSlotIndex(null)
    setWeaponAutoAdvance(autoAdvance)
    if (autoAdvance) {
      weaponClearStreakRef.current = 0
    }
    setSelectionNotice(null)
    setSelectionMode('weapon')
  }

  function handleOpenShips() {
    handleOpenShipsAt(nextShipSlotIndex, true)
  }

  function handleClearShipAt(slotIndex: number) {
    const clampedIndex = Math.max(0, Math.min(activeShipLimit - 1, slotIndex))
    shipClearStreakRef.current += 1
    const projectedShips = selectedShipNames.slice(0, activeShipLimit).map((shipName, index) =>
      index === clampedIndex ? null : shipName
    )
    const openShipCount = projectedShips.filter((shipName) => shipName == null).length
    const shouldResumeAutoAdvance = shipClearStreakRef.current >= 2 || openShipCount > 1
    const nextOpenIndex = projectedShips.findIndex((shipName) => shipName == null)

    setSelectionNotice(null)
    setShipAutoAdvance(shouldResumeAutoAdvance)
    setActiveShipSlotIndex(
      nextOpenIndex === -1 ? clampedIndex : Math.max(0, Math.min(activeShipLimit - 1, nextOpenIndex))
    )
    setVictimShipAt(clampedIndex, null)
  }

  function handleClearWeaponAt(slotIndex: number) {
    const clampedIndex = Math.max(0, Math.min(activeWeaponLimit - 1, slotIndex))
    const slot = slots[clampedIndex]
    if (!slot) return

    weaponClearStreakRef.current += 1
    const projectedEntries = slots.slice(0, activeWeaponLimit).map((entry, index) =>
      index === clampedIndex ? { ...entry, weaponKey: null } : entry
    )
    const openWeaponCount = projectedEntries.filter((entry) => entry.weaponKey == null).length
    const shouldResumeAutoAdvance = weaponClearStreakRef.current >= 2 || openWeaponCount > 1
    const nextOpenIndex = projectedEntries.findIndex((entry) => entry.weaponKey == null)

    setSelectionNotice(null)
    setWeaponAutoAdvance(shouldResumeAutoAdvance)
    setActiveWeaponSlotIndex(
      nextOpenIndex === -1 ? clampedIndex : Math.max(0, Math.min(activeWeaponLimit - 1, nextOpenIndex))
    )
    setSlotWeapon(slot.id, null)
  }

  function handleOpenWeapons() {
    handleOpenWeaponsAt(nextWeaponSlotIndex, true)
  }

  return (
    <section className="alpha-threshold-tool" aria-label="Alpha threshold tool">
      <ThresholdHeatmapBoard
        ships={previewShips}
        selectedWeapons={previewWeapons}
        allWeapons={allWeapons}
        shieldMode={shieldMode}
        matrixMode={matrixMode}
        targetWeaponFilterPreset={targetWeaponFilterPreset}
        onTargetWeaponFilterPresetChange={setTargetWeaponFilterPreset}
        targetWeaponSizeFilter={targetWeaponSizeFilter}
        onTargetWeaponSizeFilterChange={setTargetWeaponSizeFilter}
        hideHeaderRow={false}
        selectionMode={selectionMode}
        nextShipSlotIndex={effectiveShipSlotIndex}
        nextWeaponSlotIndex={effectiveWeaponSlotIndex}
        onShieldModeChange={handleShieldModeChange}
        onMatrixModeChange={setMatrixMode}
        onOpenWeapons={handleOpenWeapons}
        onOpenShips={handleOpenShips}
        onOpenWeaponsAt={handleOpenWeaponsAt}
        onOpenShipsAt={handleOpenShipsAt}
        onClearShipAt={handleClearShipAt}
        onClearWeaponAt={handleClearWeaponAt}
        shipPresets={shipPresets}
        weaponSizePresets={weaponSizePresets}
        weaponPresets={weaponPresets}
        activeShipPresetId={activeShipPresetId}
        activeWeaponPresetId={activeWeaponPresetId}
        activeWeaponSizePresetId={activeWeaponSizePresetId}
        onApplyShipPreset={applyShipPreset}
        onApplyWeaponSizePreset={applyWeaponSizePreset}
        onApplyWeaponPreset={applyWeaponPreset}
        onClearShipPreset={clearShipPreset}
        onClearWeaponPreset={clearWeaponPreset}
        onboardingHighlight={onboardingHighlight}
      />
      {selectionMode === 'ship' ? (
        <ShipSelectorOverlay
          open
          allShips={allShips}
          selectedShipNames={selectedShipNames}
          activeSlotIndex={Math.max(0, Math.min(activeShipLimit - 1, activeShipSlotIndex))}
          selectionNotice={selectionMode === 'ship' ? selectionNotice : null}
          disableAnchor={isMobileViewport}
          onSelectShip={handleShipSelect}
          onActivateSlot={(slotIndex) => handleOpenShipsAt(slotIndex, false)}
          onClearSlot={handleClearShipAt}
          onClose={() => setSelectionMode(null)}
        />
      ) : selectionMode === 'weapon' ? (
        <WeaponSelectorOverlay
          open
          slots={slots.slice(0, activeWeaponLimit)}
          weapons={allWeapons}
          targetSlotIndex={Math.max(0, Math.min(activeWeaponLimit - 1, weaponOverlayTargetIndex))}
          activeSlotIndex={Math.max(0, Math.min(activeWeaponLimit - 1, activeWeaponSlotIndex))}
          anchorSlotIndex={Math.max(0, Math.min(activeWeaponLimit - 1, weaponAnchorSlotIndex))}
          selectionNotice={selectionMode === 'weapon' ? selectionNotice : null}
          weaponFilterPreset={weaponOverlayFilterPreset}
          disableAnchor={isMobileViewport}
          onSelectWeapon={handleWeaponSelect}
          onActivateSlot={(slotIndex) => handleOpenWeaponsAt(slotIndex, false)}
          onClearSlot={handleClearWeaponAt}
          onClose={() => {
            setWeaponOverlayFilterPreset(null)
            setSelectionMode(null)
          }}
        />
      ) : null}
      {!onboardingDismissed && !isMobileViewport ? (
        <AlphaThresholdOnboardingModal
          onHighlightChange={handleOnboardingHighlight}
          onComplete={handleOnboardingComplete}
        />
      ) : null}
      {!mobileOnboardingDismissed && isMobileViewport ? (
        <AlphaThresholdMobileOnboardingTip onComplete={() => setMobileOnboardingDismissed(true)} />
      ) : null}
    </section>
  )
}
