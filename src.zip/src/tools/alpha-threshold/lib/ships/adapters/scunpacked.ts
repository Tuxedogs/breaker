import type { ShipRecord } from '../types'

export function normalizeScunpackedShip(
  input: Record<string, unknown>
): ShipRecord {
  const health = Number(input.health ?? 0)
  const ballisticThreshold = Number(input.ballisticThreshold ?? 0)
  const energyThreshold = Number(input.energyThreshold ?? 0)

  return {
    id: String(input.id ?? ''),
    manufacturer: String(input.manufacturer ?? ''),
    name: String(input.name ?? ''),
    role: typeof input.role === 'string' ? input.role : null,
    career: typeof input.career === 'string' ? input.career : null,
    isGroundVehicle: typeof input.isGroundVehicle === 'boolean' ? input.isGroundVehicle : false,
    sizeGroup: 'medium',
    health,
    armor: Math.max(1, Math.round((ballisticThreshold + energyThreshold) / 2)),
    armorHp: health,
    vitalHp: health,
    ballisticThreshold,
    energyThreshold,
    history: [],
    source: 'scunpacked',
    sourceId: String(input.id ?? input.name ?? ''),
    patch: typeof input.patch === 'string' ? input.patch : undefined,
  }
}
