import { useState } from 'react'
import type { FocusEvent, PointerEvent } from 'react'

import { estimateArmorInteraction, formatMetric } from '../lib/calculations'
import { formatWeaponClassLabel } from '../lib/weapons/normalize'
import type { ArmorInteractionEstimate, SelectedWeaponComparison, Ship } from '../types'
import { HeatmapTooltip } from './HeatmapTooltip'

export type ArmorInteractionFilterChip =
  | { kind: 'damageType'; slotId: string; label: string; value: string }
  | { kind: 'weaponClass'; slotId: string; label: string; value: string }
  | { kind: 'velocity'; slotId: string; label: string; value: number | null }

type Props = {
  ship: Ship
  selectedWeapon: SelectedWeaponComparison
  compact?: boolean
  hideWeaponHeader?: boolean
  highlighted?: boolean
  onFilterChipClick?: (chip: ArmorInteractionFilterChip) => void
}

type TooltipState = {
  open: boolean
  x: number
  y: number
  title: string
  sectionTitle?: string
  lines: Array<{
    label: string
    value: string
    tone?: 'immediate' | 'cyan' | 'danger' | 'amber'
    kind?: 'section'
  }>
}

function formatSourceLabel(source: ArmorInteractionEstimate['armorDamageStartsAtPercentSource']) {
  switch (source) {
    case 'observed':
      return 'Observed'
    case 'estimated':
      return 'Estimated'
    case 'threshold':
      return 'Threshold'
    default:
      return 'Unknown'
  }
}

function formatStateLabel(state: 'up' | 'down') {
  return state === 'up' ? 'Online' : 'Offline'
}

function getThresholdRatioLabel(ratio: number) {
  if (!Number.isFinite(ratio)) return 'Overkill'
  if (ratio >= 2) return 'Overkill'
  if (ratio >= 1.15) return 'Above'
  if (ratio >= 0.85) return 'Near'
  if (ratio > 0.65) return 'Medium'
  return 'Low'
}

function getThresholdRatioToneClass(ratio: number) {
  const label = getThresholdRatioLabel(ratio)
  if (label === 'Overkill') return 'alpha-armor-interaction-ratio-label-overkill'
  return ''
}

function formatPassThroughLabel(value: { min: number; max: number } | undefined) {
  if (!value) return '100% / 100%'
  return `${Math.round(value.min * 100)}% / ${Math.round(value.max * 100)}%`
}

function formatArmorOnsetValue(estimate: ArmorInteractionEstimate) {
  if (estimate.armorDamageStartsAtPercent != null) {
    return `${Math.round(estimate.armorDamageStartsAtPercent)}%`
  }

  return estimate.damagesFreshArmor ? '100%' : 'Not Yet Calibrated'
}

function getArmorEffectivenessRating(estimate: ArmorInteractionEstimate) {
  if (estimate.damagesFreshArmor) {
    return estimate.thresholdRatio >= 1.5 ? 'High' : 'Medium'
  }

  if (estimate.thresholdRatio >= 0.85) return 'Medium'
  return 'Low'
}

function formatSourceBadgeLabel(source: ArmorInteractionEstimate['armorDamageStartsAtPercentSource']) {
  return formatSourceLabel(source)
}

function formatSourceTypeLabel(source: ArmorInteractionEstimate['armorDamageStartsAtPercentSource']) {
  if (source === 'estimated') return 'Estimated'
  if (source === 'none') return 'Unknown'
  return 'Threshold'
}

function getIntactArmorValueClass(damagesFreshArmor: boolean, highlighted: boolean) {
  if (!highlighted) return ''

  return damagesFreshArmor
    ? 'alpha-armor-interaction-result-value-yes'
    : 'alpha-armor-interaction-result-value-no'
}

function getEffectivenessSemanticClass(rating: string) {
  switch (rating) {
    case 'High':
      return 'alpha-armor-interaction-result-value-high'
    case 'Medium':
      return 'alpha-armor-interaction-result-value-medium'
    default:
      return 'alpha-armor-interaction-result-value-low'
  }
}

function getEffectivenessValueClass(
  rating: string,
  highlighted: boolean,
  thresholdRatio: number
) {
  if (!highlighted) return ''
  if (thresholdRatio >= 1) return 'alpha-armor-interaction-result-value-high'

  return getEffectivenessSemanticClass(rating)
}

function getConfidenceLabel(confidence: ArmorInteractionEstimate['confidence']) {
  return `${confidence[0].toUpperCase()}${confidence.slice(1)}`
}

function getInterpretationSentence(estimate: ArmorInteractionEstimate, effectivenessRating: string) {
  if (estimate.damagesFreshArmor && effectivenessRating === 'High') {
    return 'Reliable immediate armor damage with high threshold pressure.'
  }

  if (estimate.damagesFreshArmor) {
    return 'Immediate armor damage, but threshold pressure is moderate.'
  }

  if (estimate.armorDamageStartsAtPercent != null) {
    return `Armor damage starts around ${Math.round(estimate.armorDamageStartsAtPercent)}% integrity.`
  }

  return 'Not yet calibrated for a reliable armor onset point.'
}

export function ArmorInteractionSummaryPanel({
  ship,
  selectedWeapon,
  compact = false,
  hideWeaponHeader = false,
  highlighted = false,
  onFilterChipClick,
}: Props) {
  const [tooltipState, setTooltipState] = useState<TooltipState>({
    open: false,
    x: 0,
    y: 0,
    title: '',
    lines: [],
  })

  const shieldUpEstimate = estimateArmorInteraction(selectedWeapon.weapon, ship, 'up')
  const shieldDownEstimate = estimateArmorInteraction(selectedWeapon.weapon, ship, 'down')
  const activeChannel = shieldUpEstimate.damageChannel
  const activeShield = ship.defenseProfile?.shields
  const visibleStates: Array<'up' | 'down'> =
    selectedWeapon.weapon.damageType === 'ballistic' ? ['up', 'down'] : ['down']
  const familyClass =
    selectedWeapon.weapon.damageType === 'ballistic'
      ? 'alpha-armor-interaction-panel-ballistic'
      : 'alpha-armor-interaction-panel-energy'
  const layoutClass = compact
    ? 'alpha-armor-interaction-panel-compact'
    : 'alpha-armor-interaction-panel-full'
  const headerClass = hideWeaponHeader
    ? 'alpha-armor-interaction-panel-headless'
    : 'alpha-armor-interaction-panel-headed'
  const velocityLabel =
    selectedWeapon.weapon.projectileSpeed != null
      ? `${formatMetric(selectedWeapon.weapon.projectileSpeed)} m/s`
      : null
  function openTooltip(
    event: PointerEvent<HTMLButtonElement> | FocusEvent<HTMLButtonElement>,
    title: string,
    sectionTitle: string | undefined,
    lines: TooltipState['lines']
  ) {
    const rect = event.currentTarget.getBoundingClientRect()
    setTooltipState({
      open: true,
      x: Math.min(rect.left, window.innerWidth - 320),
      y: Math.max(16, rect.bottom + 12),
      title,
      sectionTitle,
      lines,
    })
  }

  function closeTooltip() {
    setTooltipState((current) => ({ ...current, open: false }))
  }

  function renderStateCard(estimate: ArmorInteractionEstimate, state: 'up' | 'down') {
    const isPrimaryState =
      selectedWeapon.weapon.damageType === 'ballistic' ? state === 'up' : state === 'down'
    const gradedForArmorOnly =
      state === 'up' &&
      !estimate.damagesFreshArmor &&
      shieldDownEstimate.damagesFreshArmor
    const toneClass = estimate.damagesFreshArmor
      ? 'alpha-armor-interaction-state-pass'
      : gradedForArmorOnly
        ? 'alpha-armor-interaction-state-neutral'
        : 'alpha-armor-interaction-state-hold'
    const effectivenessRating = getArmorEffectivenessRating(estimate)
    const activePassThrough =
      state === 'up'
        ? activeChannel === 'physical'
          ? activeShield?.passThrough.physical
          : activeShield?.passThrough.energy
        : null
    const armorOnsetBand = estimate.estimatedArmorOnsetBand
    const confidenceLabel = getConfidenceLabel(estimate.confidence)
    const thresholdRatioValue = Number.isFinite(estimate.thresholdRatio)
      ? estimate.thresholdRatio.toFixed(2)
      : 'Immediate'
    const thresholdRatioLabel = getThresholdRatioLabel(estimate.thresholdRatio)
    const interpretationSentence = getInterpretationSentence(estimate, effectivenessRating)
    const sourceTypeLabel = formatSourceTypeLabel(estimate.armorDamageStartsAtPercentSource)
    const tooltipLines: TooltipState['lines'] = [
      {
        label: 'Context',
        value: '',
        kind: 'section',
      },
      {
        label: 'Ship',
        value: ship.name.replaceAll('_', ' '),
      },
      {
        label: 'Weapon',
        value: selectedWeapon.weapon.name,
      },
      {
        label: 'Weapon Group',
        value: formatWeaponClassLabel(selectedWeapon.weapon.weaponClass),
      },
      {
        label: 'Combat State',
        value: '',
        kind: 'section',
      },
      {
        label: 'Alpha',
        value: formatMetric(selectedWeapon.weapon.alpha ?? 0),
      },
      {
        label: 'Velocity',
        value: velocityLabel ?? 'Unknown',
      },
      {
        label: 'Shield State',
        value: formatStateLabel(state),
      },
      {
        label: 'State/Source',
        value: `${formatStateLabel(state)} / ${sourceTypeLabel}`,
      },
      {
        label: 'Outcomes',
        value: '',
        kind: 'section',
      },
      {
        label: 'Intact Armor',
        value: estimate.damagesFreshArmor ? 'Yes' : 'No',
        tone: estimate.damagesFreshArmor ? 'immediate' : 'amber',
      },
      {
        label: 'Effective Damage',
        value: effectivenessRating,
        tone:
          effectivenessRating === 'High'
            ? 'immediate'
            : effectivenessRating === 'Medium'
              ? 'amber'
              : 'danger',
      },
      {
        label: 'Effective Alpha',
        value: formatMetric(estimate.effectiveArmorAlpha),
      },
      {
        label: 'Deflection Threshold',
        value: formatMetric(estimate.deflectionThreshold),
      },
      {
        label: 'Threshold Ratio',
        value: `${thresholdRatioValue} (${thresholdRatioLabel})`,
        tone: thresholdRatioLabel === 'Low' ? 'danger' : thresholdRatioLabel === 'Near' ? 'amber' : 'cyan',
      },
      {
        label: 'Confidence',
        value: confidenceLabel,
      },
      {
        label: 'Model Details',
        value: '',
        kind: 'section',
      },
      {
        label: 'Pass Through',
        value: state === 'up' ? formatPassThroughLabel(activePassThrough ?? undefined) : '100%',
        tone: 'cyan',
      },
      {
        label: 'Armor Start',
        value: formatArmorOnsetValue(estimate),
      },
      ...(armorOnsetBand
        ? [{
            label: 'Estimated Band',
            value: `${armorOnsetBand[0]}-${armorOnsetBand[1]}%`,
            tone: 'amber' as const,
          }]
        : []),
      ...(estimate.notes?.[0]
        ? [{
            label: 'Note',
            value: estimate.notes[0],
            tone: estimate.armorDamageStartsAtPercentSource === 'estimated' ? 'amber' as const : undefined,
          }]
        : []),
      {
        label: 'Interpretation',
        value: interpretationSentence,
      },
    ]

    return (
      <article
        key={state}
        className={`alpha-armor-interaction-state ${toneClass} ${isPrimaryState ? 'alpha-armor-interaction-state-primary' : 'alpha-armor-interaction-state-secondary'} ${highlighted ? 'alpha-armor-interaction-state-highlighted' : ''}`}
      >
        <header className="alpha-armor-interaction-state-head">
          <p className="alpha-armor-interaction-hover-title" aria-hidden="true">
            {ship.name.replaceAll('_', ' ')} · {selectedWeapon.weapon.name} · {formatWeaponClassLabel(selectedWeapon.weapon.weaponClass)}
          </p>
          <div className="alpha-armor-interaction-state-badges">
            <span className="alpha-armor-badge alpha-armor-badge-state">
              <span
                className={`alpha-armor-badge-state-value ${state === 'up' ? 'alpha-armor-badge-state-online' : 'alpha-armor-badge-state-offline'}`}
              >
                Shield State: {state === 'up' ? 'Online' : 'Offline'}
              </span>
            </span>
            <span className="alpha-armor-badge alpha-armor-badge-source">
              {formatSourceBadgeLabel(estimate.armorDamageStartsAtPercentSource)}
            </span>
            {effectivenessRating === 'High' ? (
              <span className="alpha-armor-badge alpha-armor-badge-rating">
                {effectivenessRating}
              </span>
            ) : null}
            {estimate.damagesFreshArmor ? (
              <span className="alpha-armor-badge alpha-armor-badge-priority">
                Intact Armor: Yes
              </span>
            ) : null}
            {effectivenessRating === 'High' ? (
                <span className="alpha-armor-badge alpha-armor-badge-priority">
                  Effective Damage: High
                </span>
              ) : null}
              {isPrimaryState ? (
                <>
                  <button
                    type="button"
                    className="alpha-armor-badge alpha-armor-badge-meta alpha-armor-badge-button"
                    onClick={() =>
                      onFilterChipClick?.({
                        kind: 'damageType',
                        slotId: selectedWeapon.slotId,
                        label: selectedWeapon.weapon.damageType === 'ballistic' ? 'Ballistic' : 'Energy',
                        value: selectedWeapon.weapon.damageType,
                      })
                    }
                  >
                    {selectedWeapon.weapon.damageType === 'ballistic' ? 'Ballistic' : 'Energy'}
                  </button>
                  <button
                    type="button"
                    className="alpha-armor-badge alpha-armor-badge-meta alpha-armor-badge-button"
                    onClick={() =>
                      onFilterChipClick?.({
                        kind: 'weaponClass',
                        slotId: selectedWeapon.slotId,
                        label: formatWeaponClassLabel(selectedWeapon.weapon.weaponClass),
                        value: selectedWeapon.weapon.weaponClass,
                      })
                    }
                  >
                    {formatWeaponClassLabel(selectedWeapon.weapon.weaponClass)}
                  </button>
                  {hideWeaponHeader && velocityLabel ? (
                    <button
                      type="button"
                      className="alpha-armor-badge alpha-armor-badge-meta alpha-armor-badge-button"
                      onClick={() =>
                        onFilterChipClick?.({
                          kind: 'velocity',
                          slotId: selectedWeapon.slotId,
                          label: velocityLabel,
                          value: selectedWeapon.weapon.projectileSpeed,
                        })
                      }
                    >
                      Velocity {velocityLabel}
                    </button>
                  ) : null}
                </>
              ) : null}
            </div>

          <button
            type="button"
            className="alpha-armor-tooltip-trigger"
            aria-label={`Open ${formatStateLabel(state)} armor interaction details`}
            onPointerEnter={(event) =>
              openTooltip(
                event,
                `${ship.name.replaceAll('_', ' ')} · ${selectedWeapon.weapon.name}`,
                `${formatWeaponClassLabel(selectedWeapon.weapon.weaponClass)} · Shield ${formatStateLabel(state)}`,
                tooltipLines
              )
            }
            onPointerLeave={closeTooltip}
            onFocus={(event) =>
              openTooltip(
                event,
                `${ship.name.replaceAll('_', ' ')} · ${selectedWeapon.weapon.name}`,
                `${formatWeaponClassLabel(selectedWeapon.weapon.weaponClass)} · Shield ${formatStateLabel(state)}`,
                tooltipLines
              )
            }
            onBlur={closeTooltip}
          >
            <span aria-hidden="true">i</span>
          </button>
        </header>

        <div className="alpha-armor-interaction-body">
          <section className="alpha-armor-interaction-result">
            <div className="alpha-armor-interaction-result-head">
              <div>
                <p className="alpha-armor-interaction-result-label">Intact Armor</p>
                <p className={`alpha-armor-interaction-result-value ${getIntactArmorValueClass(estimate.damagesFreshArmor, highlighted)}`}>
                  {estimate.damagesFreshArmor ? 'Yes' : 'No'}
                </p>
              </div>
              <div className="alpha-armor-interaction-result-secondary">
                <p className="alpha-armor-interaction-result-label">Effective Damage</p>
                <p className={`alpha-armor-interaction-result-value ${getEffectivenessValueClass(effectivenessRating, highlighted, estimate.thresholdRatio)}`}>
                  {effectivenessRating}
                </p>
              </div>
            </div>
          </section>

          <dl className="alpha-armor-interaction-grid">
            <div>
              <dt>Threshold Ratio</dt>
              <dd>
                <span className={getEffectivenessValueClass(effectivenessRating, highlighted, estimate.thresholdRatio) || undefined}>
                  {Number.isFinite(estimate.thresholdRatio) ? estimate.thresholdRatio.toFixed(2) : 'Immediate'}
                </span>{' '}
                <span className="alpha-armor-interaction-ratio-label">
                  <span className={getThresholdRatioToneClass(estimate.thresholdRatio)}>
                    ({getThresholdRatioLabel(estimate.thresholdRatio)})
                  </span>
                </span>
              </dd>
            </div>
            <div>
              <dt>Confidence</dt>
              <dd>{confidenceLabel}</dd>
            </div>
          </dl>
        </div>

      </article>
    )
  }

  return (
    <section className={`alpha-armor-interaction-panel ${familyClass} ${layoutClass} ${headerClass}`}>
      {!hideWeaponHeader ? (
        <header className="alpha-armor-interaction-panel-head">
          <div>
            <p className="alpha-armor-interaction-eyebrow">{selectedWeapon.weapon.name}</p>
            {selectedWeapon.weapon.projectileSpeed != null ? (
              <p className="alpha-armor-interaction-kicker">
                {formatMetric(selectedWeapon.weapon.projectileSpeed)} m/s
              </p>
            ) : null}
          </div>
        </header>
      ) : null}

      <div className="alpha-armor-interaction-state-grid">
        {visibleStates.map((state) =>
          renderStateCard(state === 'up' ? shieldUpEstimate : shieldDownEstimate, state)
        )}
      </div>

      <HeatmapTooltip
        open={tooltipState.open}
        x={tooltipState.x}
        y={tooltipState.y}
        title={tooltipState.title}
        sectionTitle={tooltipState.sectionTitle}
        lines={tooltipState.lines}
      />
    </section>
  )
}
