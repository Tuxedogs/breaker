export const erkulPtuShieldProfiles = [
  {
    "shipName": "Avenger Stalker",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Avenger Titan",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Avenger Titan Rngd.",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Avenger Warlock",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Eclipse",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "32e241cf-130e-4b00-8752-0da67e98a40f"
    ],
    "installedShieldNames": [
      "Veil"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.74,
        "max": -0.25
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s01_veil_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s01_veil_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Gladius",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Gladius Pirate",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "334e6cb2-5e77-4bc8-bd92-d756848f050b"
    ],
    "installedShieldNames": [
      "SecureHyde"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.4,
        "max": -0.13
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_securehyde_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_securehyde_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Gladius Valiant",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Hammerhead",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_l\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_r\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Idris-M",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 4,
    "installedShieldIds": [
      "dfe6794e-80e7-4d2b-9dbc-6c2f8eb0018c"
    ],
    "installedShieldNames": [
      "Holdstrong"
    ],
    "hasBespokeShield": true,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.31,
        "max": -0.1
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"dfe6794e-80e7-4d2b-9dbc-6c2f8eb0018c\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"dfe6794e-80e7-4d2b-9dbc-6c2f8eb0018c\"}"
    ]
  },
  {
    "shipName": "Idris-P",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 4,
    "installedShieldIds": [
      "dfe6794e-80e7-4d2b-9dbc-6c2f8eb0018c"
    ],
    "installedShieldNames": [
      "Holdstrong"
    ],
    "hasBespokeShield": true,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.31,
        "max": -0.1
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"dfe6794e-80e7-4d2b-9dbc-6c2f8eb0018c\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"dfe6794e-80e7-4d2b-9dbc-6c2f8eb0018c\"}"
    ]
  },
  {
    "shipName": "Reclaimer",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 4,
    "installedShieldIds": [
      "6ed772d7-ba17-4bf1-ae49-0a6ff82be1a9"
    ],
    "installedShieldNames": [
      "RS-Barrier"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": true,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.68,
        "max": -0.23
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_01\",\"localName\":\"shld_aegs_s04_reclaimer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":4,\"minSize\":4}"
    ]
  },
  {
    "shipName": "Redeemer",
    "source": "ptu",
    "shieldCount": 6,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_l\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_r\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_3\",\"localName\":\"shld_godi_s02_fullstop_scitem\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_4\",\"localName\":\"shld_godi_s02_fullstop_scitem\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_5\",\"localName\":\"shld_godi_s02_fullstop_scitem\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_6\",\"localName\":\"shld_godi_s02_fullstop_scitem\"}"
    ]
  },
  {
    "shipName": "Retaliator",
    "source": "ptu",
    "shieldCount": 6,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shieldgenerator_right_top\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shieldgenerator_right_bottom\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shieldgenerator_left_bottom\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shieldgenerator_left_top\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shieldgenerator_middle_bottom\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shieldgenerator_middle_top\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Sabre",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Sabre Comet",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Sabre Firebird",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Sabre Peregrine",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Sabre Raven",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Vanguard Harbinger",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "c8b42a1b-2000-4d7e-8888-208480c739b6"
    ],
    "installedShieldNames": [
      "SecureShield"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.4,
        "max": -0.13
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_001\",\"localName\":\"shld_godi_s02_secureshield_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_002\",\"localName\":\"shld_godi_s02_secureshield_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Vanguard Hoplite",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_001\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_002\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Vanguard Sentinel",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "d8c15fce-d188-4ce4-b303-196bc733b5d7"
    ],
    "installedShieldNames": [
      "Sheut"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.74,
        "max": -0.25
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_001\",\"localName\":\"shld_asas_s02_sheut_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_002\",\"localName\":\"shld_asas_s02_sheut_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Vanguard Warden",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_001\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_002\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Arrow",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Unknown Ship",
    "source": "ptu",
    "shieldCount": 4,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_rear_left\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_rear_right\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "C8 Pisces",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "C8R Pisces Rescue",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "C8X Pisces Exp.",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Carrack",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "e538a97f-d9cd-4997-9f43-11450e364af1"
    ],
    "installedShieldNames": [
      "Barbican"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.63,
        "max": -0.21
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_l\",\"localReference\":\"e538a97f-d9cd-4997-9f43-11450e364af1\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_r\",\"localReference\":\"e538a97f-d9cd-4997-9f43-11450e364af1\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Carrack Expedition",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "e538a97f-d9cd-4997-9f43-11450e364af1"
    ],
    "installedShieldNames": [
      "Barbican"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.63,
        "max": -0.21
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_l\",\"localReference\":\"e538a97f-d9cd-4997-9f43-11450e364af1\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_r\",\"localReference\":\"e538a97f-d9cd-4997-9f43-11450e364af1\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "F7A Mk I",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7A Mk II",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C Mk I",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C Mk II",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C Wildfire Mk I",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-M Hrtskr. Mk I",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "b66a64ca-9c53-40e7-8618-3b66b10a021c"
    ],
    "installedShieldNames": [
      "ForceWall"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.34,
        "max": -0.11
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_forcewall_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_forcewall_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-M Hrtskr. Mk II",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_center\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-M Mk I",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-M Mk II",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_center\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-R Mk I",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-R Mk II",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-S Mk I",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F7C-S Mk II",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "F8A Lightning",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "d8c15fce-d188-4ce4-b303-196bc733b5d7"
    ],
    "installedShieldNames": [
      "Sheut"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.74,
        "max": -0.25
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s02_sheut_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s02_sheut_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "F8C Lightning",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "d8c15fce-d188-4ce4-b303-196bc733b5d7"
    ],
    "installedShieldNames": [
      "Sheut"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.74,
        "max": -0.25
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_asas_s02_sheut_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_asas_s02_sheut_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Gladiator",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Hawk",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Hurricane",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Paladin",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"3a2e37f0-dc95-4082-b74d-fe968ed64eb3\"}"
    ]
  },
  {
    "shipName": "Terrapin",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "8c2b0c60-881b-4163-9d72-b6b74806735a"
    ],
    "installedShieldNames": [
      "5MA 'Chimalli'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"8c2b0c60-881b-4163-9d72-b6b74806735a\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"8c2b0c60-881b-4163-9d72-b6b74806735a\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Terrapin Medic",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "8c2b0c60-881b-4163-9d72-b6b74806735a"
    ],
    "installedShieldNames": [
      "5MA 'Chimalli'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"8c2b0c60-881b-4163-9d72-b6b74806735a\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"8c2b0c60-881b-4163-9d72-b6b74806735a\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Valkyrie",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Khartu-al",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "b66a64ca-9c53-40e7-8618-3b66b10a021c"
    ],
    "installedShieldNames": [
      "ForceWall"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.34,
        "max": -0.11
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_forcewall_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_forcewall_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "San'tok.yāi",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "MOLE",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6"
    ],
    "installedShieldNames": [
      "5CA 'Akura'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_behr_s03_5ca_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "MOTH",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6"
    ],
    "installedShieldNames": [
      "5CA 'Akura'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "MPUV Cargo",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "MPUV Personnel",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "MPUV Tractor",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "RAFT",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 2,
    "installedShieldIds": [
      "37ae6971-46d1-4021-bb9f-353813df8e9f"
    ],
    "installedShieldNames": [
      "Aspis"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localReference\":\"37ae6971-46d1-4021-bb9f-353813df8e9f\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localReference\":\"37ae6971-46d1-4021-bb9f-353813df8e9f\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_3\",\"localReference\":\"37ae6971-46d1-4021-bb9f-353813df8e9f\"}"
    ]
  },
  {
    "shipName": "SRV",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "8c2b0c60-881b-4163-9d72-b6b74806735a"
    ],
    "installedShieldNames": [
      "5MA 'Chimalli'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Defender",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "39e7e5bf-27ba-4e45-914f-3fcc79a8886c"
    ],
    "installedShieldNames": [
      "Sukoran"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.66,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_banu_s02_placeholder_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Mustang Alpha",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "4323ef0d-778f-4e8f-89e8-bbe3d33f5f08"
    ],
    "installedShieldNames": [
      "INK"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.9,
        "max": -0.3
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_ink_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_ink_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Mustang Beta",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "4323ef0d-778f-4e8f-89e8-bbe3d33f5f08"
    ],
    "installedShieldNames": [
      "INK"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.9,
        "max": -0.3
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_ink_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_ink_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Mustang Delta",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "334e6cb2-5e77-4bc8-bd92-d756848f050b"
    ],
    "installedShieldNames": [
      "SecureHyde"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.4,
        "max": -0.13
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_securehyde_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_securehyde_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Mustang Gamma",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "b64ab3f3-4b44-418c-a438-57a04a1cf1b2"
    ],
    "installedShieldNames": [
      "Falco"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -1,
        "max": -0.33
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_yorm_s01_falco_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_yorm_s01_falco_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Mustang Omega",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "b64ab3f3-4b44-418c-a438-57a04a1cf1b2"
    ],
    "installedShieldNames": [
      "Falco"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -1,
        "max": -0.33
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_yorm_s01_falco_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_yorm_s01_falco_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Nomad",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_01\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "A1 Spirit",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "A2 Hercules",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 3,
    "installedShieldIds": [
      "6a4d4eb2-dacd-4b04-b17f-e7a02ea7e744"
    ],
    "installedShieldNames": [
      "FullBlock"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.34,
        "max": -0.11
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_l\",\"localReference\":\"6a4d4eb2-dacd-4b04-b17f-e7a02ea7e744\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_r\",\"localReference\":\"6a4d4eb2-dacd-4b04-b17f-e7a02ea7e744\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_c\",\"localReference\":\"6a4d4eb2-dacd-4b04-b17f-e7a02ea7e744\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Ares Inferno",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Ares Ion",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "C1 Spirit",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "C2 Hercules",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_l\",\"localReference\":\"3a2e37f0-dc95-4082-b74d-fe968ed64eb3\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_r\",\"localReference\":\"3a2e37f0-dc95-4082-b74d-fe968ed64eb3\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Intrepid",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "2de33b34-afaf-40ec-ab30-0a5039946866"
    ],
    "installedShieldNames": [
      "HEX"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.82,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"2de33b34-afaf-40ec-ab30-0a5039946866\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "M2 Hercules",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "6a4d4eb2-dacd-4b04-b17f-e7a02ea7e744"
    ],
    "installedShieldNames": [
      "FullBlock"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.34,
        "max": -0.11
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_l\",\"localReference\":\"6a4d4eb2-dacd-4b04-b17f-e7a02ea7e744\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_r\",\"localReference\":\"6a4d4eb2-dacd-4b04-b17f-e7a02ea7e744\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Mercury",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"3a2e37f0-dc95-4082-b74d-fe968ed64eb3\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Buccaneer",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Caterpillar",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}"
    ]
  },
  {
    "shipName": "Caterpillar Pirate",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}"
    ]
  },
  {
    "shipName": "Drake Clipper",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "4323ef0d-778f-4e8f-89e8-bbe3d33f5f08"
    ],
    "installedShieldNames": [
      "INK"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.9,
        "max": -0.3
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localReference\":\"4323ef0d-778f-4e8f-89e8-bbe3d33f5f08\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localReference\":\"4323ef0d-778f-4e8f-89e8-bbe3d33f5f08\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Corsair",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6"
    ],
    "installedShieldNames": [
      "5CA 'Akura'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_a\",\"localReference\":\"51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Cutlass Black",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "86bfeaef-e0e2-4373-9dca-47e193c0b203"
    ],
    "installedShieldNames": [
      "STOP"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Cutlass Blue",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "37ae6971-46d1-4021-bb9f-353813df8e9f"
    ],
    "installedShieldNames": [
      "Aspis"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"37ae6971-46d1-4021-bb9f-353813df8e9f\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Cutlass Red",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "37ae6971-46d1-4021-bb9f-353813df8e9f"
    ],
    "installedShieldNames": [
      "Aspis"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"37ae6971-46d1-4021-bb9f-353813df8e9f\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Cutlass Steel",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Cutter",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "2de33b34-afaf-40ec-ab30-0a5039946866"
    ],
    "installedShieldNames": [
      "HEX"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.82,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s01_hex_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Cutter Rambler",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "2de33b34-afaf-40ec-ab30-0a5039946866"
    ],
    "installedShieldNames": [
      "HEX"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.82,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_expo_shield\",\"localName\":\"shld_seco_s01_hex_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Cutter Scout",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "2de33b34-afaf-40ec-ab30-0a5039946866"
    ],
    "installedShieldNames": [
      "HEX"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.82,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_scout_shieldgen\",\"localName\":\"shld_seco_s01_hex_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Golem",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"624e6c75-afd8-4606-a10e-45d12cb3c882\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Drake Golem OX",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"624e6c75-afd8-4606-a10e-45d12cb3c882\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Herald",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"ecc8d200-548c-4de0-a60e-d1e316515170\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"ecc8d200-548c-4de0-a60e-d1e316515170\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Vulture",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_rear\",\"localName\":\"shld_basl_s01_bulwark_scitem\"}"
    ]
  },
  {
    "shipName": "Blade",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Glaive",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Prowler",
    "source": "ptu",
    "shieldCount": 4,
    "shieldSize": 2,
    "installedShieldIds": [
      "5f3fced2-3c4a-4a50-8a3e-4ba36064854c"
    ],
    "installedShieldNames": [
      "Obscura"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s02_obscura_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s02_obscura_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localReference\":\"5f3fced2-3c4a-4a50-8a3e-4ba36064854c\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_04\",\"localReference\":\"5f3fced2-3c4a-4a50-8a3e-4ba36064854c\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Prowler Utility",
    "source": "ptu",
    "shieldCount": 4,
    "shieldSize": 2,
    "installedShieldIds": [
      "5f3fced2-3c4a-4a50-8a3e-4ba36064854c"
    ],
    "installedShieldNames": [
      "Obscura"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s02_obscura_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s02_obscura_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localReference\":\"5f3fced2-3c4a-4a50-8a3e-4ba36064854c\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_04\",\"localReference\":\"5f3fced2-3c4a-4a50-8a3e-4ba36064854c\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Stinger",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Talon",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Talon Shrike",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Syulen",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "2de33b34-afaf-40ec-ab30-0a5039946866"
    ],
    "installedShieldNames": [
      "HEX"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.82,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localName\":\"shld_seco_s01_hex_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localName\":\"shld_seco_s01_hex_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Shiv",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "86bfeaef-e0e2-4373-9dca-47e193c0b203"
    ],
    "installedShieldNames": [
      "STOP"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Wolf",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "2de33b34-afaf-40ec-ab30-0a5039946866"
    ],
    "installedShieldNames": [
      "HEX"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.82,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"2de33b34-afaf-40ec-ab30-0a5039946866\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"2de33b34-afaf-40ec-ab30-0a5039946866\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Kruger L-22 Alpha Wolf",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "2de33b34-afaf-40ec-ab30-0a5039946866"
    ],
    "installedShieldNames": [
      "HEX"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.82,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"2de33b34-afaf-40ec-ab30-0a5039946866\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"2de33b34-afaf-40ec-ab30-0a5039946866\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "P-52",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "334e6cb2-5e77-4bc8-bd92-d756848f050b"
    ],
    "installedShieldNames": [
      "SecureHyde"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.4,
        "max": -0.13
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s01_securehyde_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "P-72",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "P-72 Emerald",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Fury",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "48e2b865-a936-4346-a621-582568ebd008"
    ],
    "installedShieldNames": [
      "Cloak"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.8,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_asas_s01_cloak_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Fury LX",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "b64ab3f3-4b44-418c-a438-57a04a1cf1b2"
    ],
    "installedShieldNames": [
      "Falco"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -1,
        "max": -0.33
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_yorm_s01_falco_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Fury MX",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "48e2b865-a936-4346-a621-582568ebd008"
    ],
    "installedShieldNames": [
      "Cloak"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.8,
        "max": -0.27
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_asas_s01_cloak_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Guardian",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Guardian MX",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_01\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Guardian QI",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"924e275a-d449-44f5-a8a8-6e0e93a9661e\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Razor",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"d0669062-2e64-41d4-beb2-d510588ca593\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Razor EX",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"localReference\":\"d0669062-2e64-41d4-beb2-d510588ca593\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Razor LX",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"d0669062-2e64-41d4-beb2-d510588ca593\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Fortune",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"624e6c75-afd8-4606-a10e-45d12cb3c882\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator02\",\"localReference\":\"624e6c75-afd8-4606-a10e-45d12cb3c882\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator03\",\"localReference\":\"624e6c75-afd8-4606-a10e-45d12cb3c882\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Freelancer",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 2,
    "installedShieldIds": [
      "8c2b0c60-881b-4163-9d72-b6b74806735a"
    ],
    "installedShieldNames": [
      "5MA 'Chimalli'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Freelancer DUR",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 2,
    "installedShieldIds": [
      "8c2b0c60-881b-4163-9d72-b6b74806735a"
    ],
    "installedShieldNames": [
      "5MA 'Chimalli'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Freelancer MAX",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 2,
    "installedShieldIds": [
      "8c2b0c60-881b-4163-9d72-b6b74806735a"
    ],
    "installedShieldNames": [
      "5MA 'Chimalli'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Freelancer MIS",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Hull A",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "7ff2c313-51c7-459b-91e5-8afd089df32f"
    ],
    "installedShieldNames": [
      "Armada"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.7,
        "max": -0.23
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localName\":\"shld_basl_s02_armada_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Hull C",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator01\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator03\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator04\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}"
    ]
  },
  {
    "shipName": "Prospector",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_basl_s01_bulwark_scitem\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_c\",\"localName\":\"shld_basl_s01_bulwark_scitem\"}"
    ]
  },
  {
    "shipName": "Reliant Kore",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Reliant Mako",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Reliant Sen",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Reliant Tana",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Starfarer",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_c\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}"
    ]
  },
  {
    "shipName": "Starfarer Gemini",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_b\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}",
      "{\"itemPortName\":\"hardpoint_shield_generator_c\",\"localName\":\"shld_basl_s03_stronghold_scitem\"}"
    ]
  },
  {
    "shipName": "Starlancer MAX",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Starlancer TAC",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "100i",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "125a",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "135c",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "300i",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "6be9c02c-ff32-483f-a6f8-d984dcb97c40"
    ],
    "installedShieldNames": [
      "WEB"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_web_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "315p",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "ecc8d200-548c-4de0-a60e-d1e316515170"
    ],
    "installedShieldNames": [
      "Shimmer"
    ],
    "installedShieldClass": [
      "Stealth"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.77,
        "max": -0.26
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_asas_s01_shimmer_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "325a",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "350r",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "400i",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "87710dba-dd06-41b4-974e-475ee7d36055"
    ],
    "installedShieldNames": [
      "GUARD"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s03_guard_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "600i",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "600i Exec. Edition",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "600i Touring",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "85X Limited",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "890 Jump",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 4,
    "installedShieldIds": [
      "6fc982c0-2747-42b7-a628-7c76ecedf732"
    ],
    "installedShieldNames": [
      "Glacis"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.6,
        "max": -0.2
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_orig_s04_890j_scitem\",\"editable\":false,\"editableChildren\":false,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":4,\"minSize\":4}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_orig_s04_890j_scitem\",\"editable\":false,\"editableChildren\":false,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":4,\"minSize\":4}"
    ]
  },
  {
    "shipName": "M50 Interceptor",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "X1",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [],
    "installedShieldNames": [],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0
      },
      "energy": {
        "min": 0,
        "max": 0
      },
      "distortion": {
        "min": 0,
        "max": 0
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 1
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "rawShieldRecords": []
  },
  {
    "shipName": "X1 Force",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "X1 Velocity",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [],
    "installedShieldNames": [],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0
      },
      "energy": {
        "min": 0,
        "max": 0
      },
      "distortion": {
        "min": 0,
        "max": 0
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 1
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "rawShieldRecords": []
  },
  {
    "shipName": "Apollo Medivac",
    "source": "ptu",
    "shieldCount": 4,
    "shieldSize": 2,
    "installedShieldIds": [
      "86bfeaef-e0e2-4373-9dca-47e193c0b203"
    ],
    "installedShieldNames": [
      "STOP"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_01\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_04\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Apollo Triage",
    "source": "ptu",
    "shieldCount": 4,
    "shieldSize": 2,
    "installedShieldIds": [
      "86bfeaef-e0e2-4373-9dca-47e193c0b203"
    ],
    "installedShieldNames": [
      "STOP"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_01\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_04\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Aurora Mk I LX",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "d0669062-2e64-41d4-beb2-d510588ca593"
    ],
    "installedShieldNames": [
      "Targa"
    ],
    "installedShieldClass": [
      "Competition"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.97,
        "max": -0.32
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_yorm_s01_targa_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Aurora Mk I CL",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Aurora Mk I ES",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "4323ef0d-778f-4e8f-89e8-bbe3d33f5f08"
    ],
    "installedShieldNames": [
      "INK"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.9,
        "max": -0.3
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s01_ink_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s01_ink_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Aurora Mk I LN",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "334e6cb2-5e77-4bc8-bd92-d756848f050b"
    ],
    "installedShieldNames": [
      "SecureHyde"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.4,
        "max": -0.13
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_godi_s01_securehyde_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_godi_s01_securehyde_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Aurora MR",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s01_bulwark_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Constellation Andr.",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6"
    ],
    "installedShieldNames": [
      "5CA 'Akura'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s03_5ca_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Constellation Aqlla.",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6"
    ],
    "installedShieldNames": [
      "5CA 'Akura'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s03_5ca_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Constellation Phnx.",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6"
    ],
    "installedShieldNames": [
      "5CA 'Akura'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s03_5ca_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Constelltn. PhnxEmr.",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "51bf9a6e-0ad7-49d2-8d41-d1d5e69669e6"
    ],
    "installedShieldNames": [
      "5CA 'Akura'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_behr_s03_5ca_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Constellation Tau.",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 3,
    "installedShieldIds": [
      "3a2e37f0-dc95-4082-b74d-fe968ed64eb3"
    ],
    "installedShieldNames": [
      "Stronghold"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_basl_s03_stronghold_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":3,\"minSize\":3}"
    ]
  },
  {
    "shipName": "Hermes",
    "source": "ptu",
    "shieldCount": 4,
    "shieldSize": 2,
    "installedShieldIds": [
      "86bfeaef-e0e2-4373-9dca-47e193c0b203"
    ],
    "installedShieldNames": [
      "STOP"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_01_hermes\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02_hermes\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03_hermes\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_04_hermes\",\"localReference\":\"86bfeaef-e0e2-4373-9dca-47e193c0b203\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Mantis",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"339bd641-8dfb-4bc1-b273-5ffc5f702fbb\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"339bd641-8dfb-4bc1-b273-5ffc5f702fbb\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Unknown Ship",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localReference\":\"339bd641-8dfb-4bc1-b273-5ffc5f702fbb\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localReference\":\"339bd641-8dfb-4bc1-b273-5ffc5f702fbb\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Perseus",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 3,
    "installedShieldIds": [
      "925ec9df-cd0d-4c40-a5ad-6d22bdbfdeaa"
    ],
    "installedShieldNames": [
      "SureStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localReference\":\"925ec9df-cd0d-4c40-a5ad-6d22bdbfdeaa\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localReference\":\"925ec9df-cd0d-4c40-a5ad-6d22bdbfdeaa\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Polaris",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 4,
    "installedShieldIds": [
      "d9870a05-1a66-4a9a-bec6-30eb67e3a3ce"
    ],
    "installedShieldNames": [
      "Glacis"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": true,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.68,
        "max": -0.23
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_rsi_s04_polaris_scitem\",\"editable\":false,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Salvation",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "624e6c75-afd8-4606-a10e-45d12cb3c882"
    ],
    "installedShieldNames": [
      "Bulwark"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localReference\":\"624e6c75-afd8-4606-a10e-45d12cb3c882\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localReference\":\"624e6c75-afd8-4606-a10e-45d12cb3c882\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Scorpius",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Scorpius",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 2,
    "installedShieldIds": [
      "924e275a-d449-44f5-a8a8-6e0e93a9661e"
    ],
    "installedShieldNames": [
      "FullStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s02_fullstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":2,\"minSize\":2}"
    ]
  },
  {
    "shipName": "Zeus Mk II CL",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 2,
    "installedShieldIds": [
      "37ae6971-46d1-4021-bb9f-353813df8e9f"
    ],
    "installedShieldNames": [
      "Aspis"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localName\":\"shld_basl_s02_aspis_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localName\":\"shld_basl_s02_aspis_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_3\",\"localName\":\"shld_basl_s02_aspis_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Zeus Mk II ES",
    "source": "ptu",
    "shieldCount": 4,
    "shieldSize": 2,
    "installedShieldIds": [
      "8c2b0c60-881b-4163-9d72-b6b74806735a"
    ],
    "installedShieldNames": [
      "5MA 'Chimalli'"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.58,
        "max": -0.19
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_1\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_2\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_3\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}",
      "{\"itemPortName\":\"hardpoint_shield_generator_4\",\"localName\":\"shld_behr_s02_5ma_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}]}"
    ]
  },
  {
    "shipName": "Scythe",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 1,
    "installedShieldIds": [
      "339bd641-8dfb-4bc1-b273-5ffc5f702fbb"
    ],
    "installedShieldNames": [
      "AllStop"
    ],
    "installedShieldClass": [
      "Military"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.37,
        "max": -0.12
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localName\":\"shld_godi_s01_allstop_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":1,\"minSize\":1}"
    ]
  },
  {
    "shipName": "Ballista",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Ballista Dunestalker",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Ballista Snowblind",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Centurion",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 0,
    "installedShieldIds": [
      "e11f94ed-6a41-4960-b895-4a604ec98e97"
    ],
    "installedShieldNames": [
      "Castra"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s00_castra_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s00_castra_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Spartan",
    "source": "ptu",
    "shieldCount": 2,
    "shieldSize": 0,
    "installedShieldIds": [
      "e11f94ed-6a41-4960-b895-4a604ec98e97"
    ],
    "installedShieldNames": [
      "Castra"
    ],
    "installedShieldClass": [
      "Industrial"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.67,
        "max": -0.22
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_left\",\"localName\":\"shld_basl_s00_castra_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}",
      "{\"itemPortName\":\"hardpoint_shield_generator_right\",\"localName\":\"shld_basl_s00_castra_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "CSV-SM",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Unknown Ship",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_mdc\",\"localReference\":\"ffede9a8-3c50-4b9e-be0f-9d93e5a26f29\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Unknown Ship",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localReference\":\"ffede9a8-3c50-4b9e-be0f-9d93e5a26f29\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Lynx",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Ursa",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Ursa Fortuna",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Ursa Medivac",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Cyclone",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Cyclone AA",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Cyclone MT",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Cyclone RC",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Cyclone RN",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Cyclone",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Nova",
    "source": "ptu",
    "shieldCount": 3,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator_01\",\"localReference\":\"ffede9a8-3c50-4b9e-be0f-9d93e5a26f29\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}",
      "{\"itemPortName\":\"hardpoint_shield_generator_02\",\"localReference\":\"ffede9a8-3c50-4b9e-be0f-9d93e5a26f29\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}",
      "{\"itemPortName\":\"hardpoint_shield_generator_03\",\"localReference\":\"ffede9a8-3c50-4b9e-be0f-9d93e5a26f29\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Storm",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  },
  {
    "shipName": "Storm AA",
    "source": "ptu",
    "shieldCount": 1,
    "shieldSize": 0,
    "installedShieldIds": [
      "ffede9a8-3c50-4b9e-be0f-9d93e5a26f29"
    ],
    "installedShieldNames": [
      "PIN"
    ],
    "installedShieldClass": [
      "Civilian"
    ],
    "hasBespokeShield": false,
    "resistance": {
      "physical": {
        "min": 0,
        "max": 0.25
      },
      "energy": {
        "min": -0.86,
        "max": -0.29
      },
      "distortion": {
        "min": 0.75,
        "max": 0.95
      }
    },
    "absorption": {
      "physical": {
        "min": 0,
        "max": 0.45
      },
      "energy": {
        "min": 1,
        "max": 1
      }
    },
    "passThrough": {
      "physical": {
        "min": 1,
        "max": 0.41250000000000003
      },
      "energy": {
        "min": 0,
        "max": 0
      }
    },
    "rawShieldRecords": [
      "{\"itemPortName\":\"hardpoint_shield_generator\",\"localName\":\"shld_seco_s00_pin_scitem\",\"editable\":true,\"editableChildren\":true,\"itemTypes\":[{\"type\":\"Shield\"}],\"maxSize\":0,\"minSize\":0}"
    ]
  }
] as const
